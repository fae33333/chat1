try { require('dotenv').config(); } catch (e) { /* dotenv غير مثبت: نتجاهل */ }
// كثير من الاستضافات لا تملك مساراً IPv6 يعمل: نفضّل IPv4 كي لا تنتهي مهلة الاتصال بيوتيوب/جوجل
try { require('dns').setDefaultResultOrder('ipv4first'); } catch (e) {}
try { require('net').setDefaultAutoSelectFamilyAttemptTimeout(500); } catch (e) {}
const express = require('express');
const http = require('http');
const https = require('https');
const { Server } = require('socket.io');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const { v4: uuidv4 } = require('uuid');
const nodemailer = require('nodemailer');
const { OAuth2Client } = require('google-auth-library');
const { db, run, get, all, initDB } = require('./database');
// محرك عناوين العودة (redirect_uri) — يعالج خطأ Google الشائع: 400 redirect_uri_mismatch
const {
  CALLBACK_PATH, normalizeRedirectUri, parseRedirectList, requestOrigin, derivedRedirectUri, pickRedirectUri
} = require('./google-redirect');

const app = express();
const server = http.createServer(app);

// Initialize HTTPS Server on Port 2083 with cert.pem and key.pem
const certPath = path.join(__dirname, 'cert.pem');
const keyPath = path.join(__dirname, 'key.pem');
let httpsServer = null;

if (fs.existsSync(certPath) && fs.existsSync(keyPath)) {
  try {
    const sslOptions = {
      key: fs.readFileSync(keyPath),
      cert: fs.readFileSync(certPath)
    };
    httpsServer = https.createServer(sslOptions, app);
    console.log('✅ SSL certificates (cert.pem & key.pem) loaded successfully for HTTPS.');
  } catch (err) {
    console.error('⚠️ Error initializing HTTPS with cert.pem and key.pem:', err.message);
  }
}

const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

// Attach Socket.IO to HTTPS server as well so WebSockets work over port 2083
if (httpsServer) {
  io.attach(httpsServer);
}

const PORT = process.env.PORT || 3000;

// Setup Multer for media uploads (Voice notes & photos)
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, 'public', 'uploads');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname) || (file.mimetype.includes('audio') ? '.webm' : '.png');
    cb(null, `${Date.now()}-${uuidv4().slice(0, 8)}${ext}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 15 * 1024 * 1024 } // 15MB limit
});

// Middleware
app.use(cors());
app.use(express.json({ limit: '10mb' }));

// أي إضافة/تعديل/حذف من لوحة الإدارة يُبثّ فوراً لكل المتصلين ليتحدث التطبيق مباشرة بدون إعادة تحميل
const ADMIN_LIVE_SKIP = /^(login|logout|enter-as-user|change-credentials|smtp|youtube-key|paypal|settings\/paypal|settings\/google)/;
let adminLiveTimers = new Map();
app.use('/api/admin', (req, res, next) => {
  if (!['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) return next();
  res.on('finish', () => {
    try {
      if (res.statusCode >= 400) return;
      const rel = String(req.path || '').replace(/^\/+/, '');
      if (!rel || ADMIN_LIVE_SKIP.test(rel)) return;
      const parts = rel.split('/');
      const area = parts[0] === 'settings' ? `settings/${parts[1] || ''}` : parts[0];
      clearTimeout(adminLiveTimers.get(area));
      adminLiveTimers.set(area, setTimeout(() => {
        adminLiveTimers.delete(area);
        if (typeof io !== 'undefined') io.emit('admin_content_updated', { area, at: Date.now() });
      }, 150));
    } catch (e) {}
  });
  next();
});

app.use(express.urlencoded({ extended: true, limit: '10mb' }));
// ملفات HTML الخاصة بقوالب الدخول (يرفعها المشرف): تُقدَّم داخل sandbox دائماً حتى لو فُتحت مباشرة،
// فلا تستطيع الوصول إلى كوكيز/تخزين الموقع أو التحكم بالصفحة الأم.
app.use('/uploads', (req, res, next) => {
  if (/^\/(?:entry|frame|roomcard|rbg|store)-[\w.\-]+\.html?$/i.test(req.path)) {
    res.setHeader('Content-Security-Policy', 'sandbox allow-scripts');
    res.setHeader('X-Content-Type-Options', 'nosniff');
  }
  next();
});
// تخزين الجلسة/الجهاز في ملف JSON على الخادم (بدل localStorage)
require('./device-store').mount(app, express);
app.use(express.static(path.join(__dirname, 'public')));

// تحديد دولة المستخدم تلقائياً (مرة واحدة) من الـ IP عند أول طلب له، إن لم تكن محددة
const _countryChecked = new Set();
app.use((req, res, next) => {
  const uid = req.headers['x-user-id'];
  if (uid && !_countryChecked.has(uid)) {
    _countryChecked.add(uid);
    try {
      const geo = getCountryFromIp(getClientIp(req));
      const code = SUPPORTED_COUNTRIES.some(c => c.code === geo.country_code && !c.isGlobal) ? geo.country_code : 'JO';
      run(`UPDATE users SET country_code = ? WHERE id = ? AND (country_code IS NULL OR country_code = '')`, [code, uid]).catch(() => {});
    } catch (e) {}
  }
  next();
});

// In-memory active presence & room states
const onlineUsers = new Map(); // socketId -> userId
const userSockets = new Map(); // userId -> Set(socketIds)
const activeRoomStates = new Map(); // roomId -> { pkState, activeAudience: Set, speakers: Set, cohostRequests: Map }

// أول 5 متواجدين في الغرفة (مع إطاراتهم) — تُرسل للّوبي مع كل تغيير ليتحدّث كرت الغرفة مباشرة
function buildAudiencePreview(roomId) {
  const st = activeRoomStates.get(roomId);
  if (!st || !st.activeAudience) return [];
  return visibleAudienceList(st).slice(0, 5).map(u => ({
    id: u.id, avatar: u.avatar || '', frame: u.avatar_frame || ''
  }));
}
const roomMusicState = new Map(); // roomId -> Map(userId -> آخر room_music_started نشط) — كل شخص مستقل
// إزالة حالة الموسيقى من الخادم عند النزول/الخروج (بدلاً من انتظار أن يرسل
// العميل إشعار الإيقاف؛ هذا يمنع ظهور مؤشر أغنية قديمة للداخلين الجدد).
function clearRoomMusicState(roomId, userId, seatIndex) {
  if (!roomId || !userId) return false;
  const states = roomMusicState.get(roomId);
  if (!states || !states.has(String(userId))) return false;
  const old = states.get(String(userId));
  states.delete(String(userId));
  if (!states.size) roomMusicState.delete(roomId);
  io.to(`room:${roomId}`).emit('room_music_stopped', {
    roomId, userId: String(userId), seatIndex: seatIndex ?? old.seatIndex
  });
  return true;
}
const pkIntervals = new Map(); // roomId -> intervalId
const recentRoomWelcomes = new Map(); // `${roomId}:${userId}` -> آخر وقت ترحيب
setInterval(() => { const cutoff = Date.now() - 10 * 60 * 1000; for (const [k, t] of recentRoomWelcomes) if (t < cutoff) recentRoomWelcomes.delete(k); }, 5 * 60 * 1000);
const adminSessions = new Map(); // token -> { username, role, loginTime }

async function verifyAdminToken(req) {
  const token = req.headers['x-admin-token'] || (req.headers.authorization && req.headers.authorization.split(' ')[1]);
  if (!token) return null;
  if (adminSessions.has(token)) {
    const s = adminSessions.get(token);
    // Only owner, super_master, and super_admin are allowed in Admin Control Panel
    if (['owner', 'super_master', 'super_admin'].includes(s.role) || !s.role || s.role === 'admin_master') {
      return s;
    }
  }
  // Check if token belongs to an authorized user (owner, super_master, or super_admin ONLY)
  if (token.startsWith('token-')) {
    const parts = token.split('-');
    const userId = parts.slice(1, parts.length - 1).join('-');
    const user = await get('SELECT id, name, role FROM users WHERE id = ?', [userId]);
    if (user && ['owner', 'super_master', 'super_admin'].includes(user.role)) {
      return { username: user.name, role: user.role, userId: user.id };
    }
  }
  return null;
}

const SOULCHILL_PK_PENALTIES = [
  "🎤 غناء مقطع غنائي حماسي بصوت عالي بدون موسيقى أمام الجمهور!",
  "💪 عمل 15 تمرين ضغط (Push-ups) لايف أمام الكاميرا فوراً!",
  "🥤 شرب كوب ماء كامل دفعة واحدة خلال 5 ثوانٍ فقط!",
  "🦁 تقليد زئير الأسد القوي وصوت النمر 3 مرات متتالية!",
  "😂 تقليد ضحكة شريرة أو شخصية كرتونية مضحكة لمدة 30 ثانية!",
  "🕺 رقصة فكتوري مضحكة وطريفة لمدة 20 ثانية أمام الجميع!",
  "👑 مدح الفائز بـ 5 صفات ملوكية والاعتراف بقوته أمام المتابعين!"
];

// Gift definitions
const GIFTS = [
  // تبويب «المتداول»
  { id: 'rose', name: 'وردة الجوري', name_en: 'Red Rose', icon: '🌹', cost: 10, currency: 'coins', charm: 10, tab: 'popular' },
  { id: 'icecream', name: 'آيس كريم مثلج', name_en: 'Chill Ice Cream', icon: '🍦', cost: 50, currency: 'coins', charm: 50, tab: 'popular' },
  { id: 'heart', name: 'قلب مشع', name_en: 'Magic Heart', icon: '💖', cost: 100, currency: 'coins', charm: 100, tab: 'popular' },
  { id: 'magic_wand', name: 'عصا سحرية', name_en: 'Magic Wand', icon: '🪄', cost: 250, currency: 'coins', charm: 250, tab: 'popular' },
  { id: 'diamond_ring', name: 'خاتم ألماس', name_en: 'Diamond Ring', icon: '💍', cost: 500, currency: 'coins', charm: 500, tab: 'popular' },
  { id: 'chocolate', name: 'شوكولاتة', name_en: 'Chocolate', icon: '🍫', cost: 20, currency: 'coins', charm: 20, tab: 'popular' },
  { id: 'genie', name: 'علاء الدين', name_en: 'Aladdin', icon: '🧞', cost: 300, currency: 'coins', charm: 300, tab: 'popular' },
  // تبويب «الحظ»
  { id: 'lucky_clover', name: 'حظ سعيد', name_en: 'Good Luck', icon: '🍀', cost: 20, currency: 'coins', charm: 20, tab: 'luck' },
  { id: 'lucky_box', name: 'هدية قيمة', name_en: 'Lucky Box', icon: '🎁', cost: 200, currency: 'coins', charm: 200, tab: 'luck' },
  { id: 'lucky_ball', name: 'لولو الحظ', name_en: 'Lucky Ball', icon: '🔮', cost: 100, currency: 'coins', charm: 100, tab: 'luck' },
  { id: 'jackpot', name: 'JACKPOT', name_en: 'Jackpot', icon: '🎰', cost: 777, currency: 'coins', charm: 777, tab: 'luck' },
  // تبويب «الأنشطة»
  { id: 'love_arrow', name: 'سهم الحب', name_en: 'Love Arrow', icon: '💘', cost: 150, currency: 'coins', charm: 150, tab: 'events' },
  { id: 'love_key', name: 'مفتاح ماسي', name_en: 'Diamond Key', icon: '🗝️', cost: 300, currency: 'coins', charm: 300, tab: 'events' },
  { id: 'pulse_heart', name: 'نبض القلب', name_en: 'Heartbeat', icon: '💓', cost: 120, currency: 'coins', charm: 120, tab: 'events' },
  { id: 'love_garden', name: 'حديقة حب', name_en: 'Love Garden', icon: '💞', cost: 400, currency: 'coins', charm: 400, tab: 'events' },
  // تبويب «الامبراطورية» (فاخرة بالألماس)
  { id: 'sports_car', name: 'سيارة سوبر سبورت', name_en: 'Super Sports Car', icon: '🏎️', cost: 1000, currency: 'diamonds', charm: 2000, luxury: true, tab: 'empire' },
  { id: 'rocket', name: 'صاروخ المجرة', name_en: 'Galaxy Rocket', icon: '🚀', cost: 2500, currency: 'diamonds', charm: 5000, luxury: true, tab: 'empire' },
  { id: 'crown', name: 'تاج الملك الإمبراطوري', name_en: 'Imperial Crown', icon: '👑', cost: 5000, currency: 'diamonds', charm: 10000, luxury: true, tab: 'empire' },
  { id: 'castle', name: 'قصر الأحلام', name_en: 'Dream Palace', icon: '🏰', cost: 10000, currency: 'diamonds', charm: 25000, luxury: true, tab: 'empire' },
  // تبويب «المشاهير»
  { id: 'star', name: 'نجمة المشاهير', name_en: 'Star', icon: '🌟', cost: 200, currency: 'diamonds', charm: 400, tab: 'celebs' },
  { id: 'golden_mic', name: 'ميكروفون ذهبي', name_en: 'Golden Mic', icon: '🎤', cost: 400, currency: 'diamonds', charm: 800, tab: 'celebs' },
  { id: 'clapper', name: 'كلاكيت', name_en: 'Clapper', icon: '🎬', cost: 600, currency: 'diamonds', charm: 1200, tab: 'celebs' }
];

// ---- كتالوج الهدايا في قاعدة البيانات (يُزرع مرة واحدة من القائمة أعلاه ثم تُدار من الإدارة) ----
const GIFT_TAB_IDS = ['normal', 'luxury']; // قسمان فقط: هدية عادية / هدية فاخرة

function giftRowToObj(r) {
  return {
    id: r.id, name: r.name, name_en: r.name_en || '', icon: r.icon || '🎁', image_url: r.image_url || '',
    cost: r.cost, currency: r.currency, charm: r.charm || r.cost, luxury: !!(r.luxury || r.tab === 'luxury'), tab: (r.luxury || r.tab === 'luxury') ? 'luxury' : 'normal',
    burst_enabled: !!r.burst_enabled,
    burst_count: Math.min(60, Math.max(1, parseInt(r.burst_count, 10) || 20)),
    banner_enabled: !!r.banner_enabled,
    banner_frame_url: r.banner_frame_url || '',
    effect_url: r.effect_url || ''
  };
}

async function seedGiftsCatalog() {
  try {
    const row = await get('SELECT COUNT(*) AS n FROM gifts_catalog');
    if (row && row.n > 0) return;
    let i = 0;
    for (const g of GIFTS) {
      await run(`INSERT OR IGNORE INTO gifts_catalog (id, name, name_en, icon, image_url, cost, currency, charm, luxury, tab, sort_order, is_active)
                 VALUES (?, ?, ?, ?, '', ?, ?, ?, ?, ?, ?, 1)`,
        [g.id, g.name, g.name_en || '', g.icon, g.cost, g.currency, g.charm || g.cost, g.luxury ? 1 : 0, g.luxury ? 'luxury' : 'normal', i++]);
    }
    console.log('Seeded gifts catalog:', GIFTS.length);
  } catch (e) { console.error('seed gifts error:', e.message); }
}

async function getActiveGifts() {
  try {
    const rows = await all('SELECT * FROM gifts_catalog WHERE is_active = 1 ORDER BY sort_order ASC, rowid ASC');
    return rows.map(giftRowToObj);
  } catch (e) { return GIFTS; }
}

async function getGiftById(id) {
  if (!id) return null;
  try {
    const r = await get('SELECT * FROM gifts_catalog WHERE id = ? AND is_active = 1', [id]);
    return r ? giftRowToObj(r) : null;
  } catch (e) { return GIFTS.find(g => g.id === id) || null; }
}

// ==========================================
// API ROUTES
// ==========================================

// ==========================================
// تسجيل الدخول: Gmail + رمز تحقق ثم اسم مستعار وكلمة مرور
// ==========================================
const crypto = require('crypto');
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
// الاسم المستعار: 2–30 رمزاً، يسمح بالإيموجي والرموز، ويمنع محارف التحكم و < > & "
function isValidNickname(n) {
  const len = [...n].length;
  return len >= 2 && len <= 30 && n.trim().length > 0 && !/[\p{C}<>&"]/u.test(n);
}
const OTP_TTL_MS = 10 * 60 * 1000;
const OTP_RESEND_MS = 60 * 1000;
const OTP_MAX_ATTEMPTS = 5;
const TICKET_TTL_MS = 15 * 60 * 1000;

const otpSendLog = new Map();   // ip -> [timestamps] (حد الإرسال لكل IP)
const loginFailures = new Map(); // `${ip}|${nickname}` -> { count, until }

function hashPassword(password, salt) {
  salt = salt || crypto.randomBytes(16).toString('hex');
  return new Promise((resolve, reject) => {
    crypto.scrypt(password, salt, 64, (err, key) => err ? reject(err) : resolve({ salt, hash: key.toString('hex') }));
  });
}

async function checkPassword(password, salt, hashHex) {
  const { hash } = await hashPassword(password, salt);
  const a = Buffer.from(hash, 'hex');
  const b = Buffer.from(hashHex, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function cleanNickname(v) {
  return String(v || '').replace(/\s+/g, ' ').trim();
}

async function generateUserId() {
  for (let i = 0; i < 20; i++) {
    const id = `sc-user-${crypto.randomInt(10000000, 100000000)}`;
    if (!(await get('SELECT id FROM users WHERE id = ?', [id]))) return id;
  }
  return `sc-user-${Date.now()}`;
}

async function issueSession(user, nickname) {
  return { success: true, user, nickname: nickname || user.name, token: `token-${user.id}-${Date.now()}` };
}


// بعد إثبات ملكية البريد (رمز Gmail أو حساب Google): يُمنح تذكرة لإكمال الاسم المستعار وكلمة المرور والجنس والعمر
// opts.google = true: البريد موثّق عبر Google. تُمنح التذكرة بادئة g_ (لا يمكن تزويرها لأنها تُنشأ في السيرفر فقط)
// وهي تسمح بالدخول المباشر للحساب المسجّل، وبإكمال بيانات حساب جديد إلزامياً
// (اسم مستعار + كلمة مرور + جنس + عمر) كي يستطيع صاحبه الدخول من أي جهاز لاحقاً.
async function signupTicketFor(cleanEmail, opts = {}) {
  const existing = await get('SELECT id, name, is_banned FROM users WHERE email = ?', [cleanEmail]);
  if (existing && existing.is_banned) {
    return { status: 403, body: { error: 'هذا الحساب محظور من قبل الإدارة 🚫' } };
  }
  const cred = existing ? await get('SELECT nickname FROM user_credentials WHERE user_id = ?', [existing.id]) : null;
  const ticket = (opts.google ? 'g_' : '') + crypto.randomBytes(24).toString('hex');
  await run('DELETE FROM auth_tickets WHERE expires_at < ?', [Date.now()]);
  await run('INSERT INTO auth_tickets (id, email, expires_at) VALUES (?, ?, ?)', [ticket, cleanEmail, Date.now() + TICKET_TTL_MS]);
  return {
    status: 200,
    body: {
      success: true,
      ticket,
      email: cleanEmail,
      // new: بريد جديد | legacy: حساب قديم بلا كلمة مرور
      // existing: حساب مسجّل (يدخل مباشرة عبر Google فقط)
      account_status: cred ? 'existing' : (existing ? 'legacy' : 'new'),
      nickname: cred ? cred.nickname : (existing ? existing.name : '')
    }
  };
}
async function grantSignupTicket(res, cleanEmail, opts = {}) {
  const r = await signupTicketFor(cleanEmail, opts);
  return res.status(r.status).json(r.body);
}

// الحد الأدنى للعمر عند التسجيل (عدّله هنا إن لزم)
const MIN_SIGNUP_AGE = 13;
const MAX_SIGNUP_AGE = 99;
function parseSignupAge(v) {
  const n = Number(v);
  return Number.isInteger(n) && n >= MIN_SIGNUP_AGE && n <= MAX_SIGNUP_AGE ? n : null;
}

// 1) إرسال رمز التحقق إلى الجيميل
app.post('/api/auth/send-gmail-otp', async (req, res) => {
  try {
    const cleanEmail = String((req.body && req.body.email) || '').trim().toLowerCase();
    if (!EMAIL_RE.test(cleanEmail) || cleanEmail.length > 254) {
      return res.status(400).json({ error: 'يرجى إدخال عنوان Gmail صحيح' });
    }

    // البريد المسجّل مسبقاً لا يُسجَّل مرة ثانية: بعد التحقق من الرمز يدخل مباشرة بحسابه السابق
    const prior = await get('SELECT id, is_banned FROM users WHERE LOWER(email) = ?', [cleanEmail]);
    if (prior && prior.is_banned) {
      return res.status(403).json({ error: 'هذا الحساب محظور من قبل الإدارة 🚫' });
    }

    // حد الإرسال: 10 طلبات في الساعة لكل IP
    const ip = req.ip || 'unknown';
    const now = Date.now();
    const recent = (otpSendLog.get(ip) || []).filter(t => now - t < 3600 * 1000);
    if (recent.length >= 10) {
      return res.status(429).json({ error: 'محاولات كثيرة، حاول مرة أخرى بعد قليل' });
    }

    // فاصل 60 ثانية بين كل رمزين لنفس البريد
    const prev = await get('SELECT last_sent FROM email_verifications WHERE email = ?', [cleanEmail]);
    if (prev && now - Number(prev.last_sent || 0) < OTP_RESEND_MS) {
      const wait = Math.ceil((OTP_RESEND_MS - (now - Number(prev.last_sent))) / 1000);
      return res.status(429).json({ error: `انتظر ${wait} ثانية قبل طلب رمز جديد`, retryAfter: wait });
    }

    const smtp = await get('SELECT * FROM smtp_settings WHERE id = 1');
    if (!smtp || !smtp.is_enabled || !smtp.user || !smtp.pass) {
      return res.status(503).json({ error: 'خدمة إرسال البريد غير مفعّلة. اضبط إعدادات SMTP من لوحة الإدارة أو ملف .env' });
    }

    const code = String(crypto.randomInt(100000, 1000000));
    await run(`
      INSERT OR REPLACE INTO email_verifications (email, code, expires_at, attempts, last_sent)
      VALUES (?, ?, ?, 0, ?)
    `, [cleanEmail, code, now + OTP_TTL_MS, now]);

    try {
      const transporter = nodemailer.createTransport({
        host: smtp.host || 'smtp.gmail.com',
        port: parseInt(smtp.port) || 587,
        secure: parseInt(smtp.port) === 465,
        auth: { user: smtp.user, pass: smtp.pass }
      });
      const html = (smtp.html_template || '<p>رمز التحقق: <b>{{code}}</b></p>')
        .replace(/\{\{code\}\}/g, code)
        .replace(/\{\{email\}\}/g, cleanEmail)
        .replace(/\{\{app_name\}\}/g, 'SoulChill');
      const subject = (smtp.subject_template || 'رمز التحقق الخاص بك لتطبيق SoulChill 🪐').replace(/\{\{code\}\}/g, code);
      await transporter.sendMail({ from: smtp.from_email || `SoulChill<${smtp.user}>`, to: cleanEmail, subject, html });
    } catch (mailErr) {
      await run('DELETE FROM email_verifications WHERE email = ?', [cleanEmail]);
      console.warn('❌ [SMTP ERROR] تعذر إرسال رمز التحقق:', mailErr.message);
      return res.status(502).json({ error: 'تعذر إرسال الرسالة إلى بريدك. تأكد من العنوان أو من إعدادات SMTP' });
    }

    recent.push(now);
    otpSendLog.set(ip, recent);
    res.json({ success: true, message: `تم إرسال رمز التحقق إلى ${cleanEmail}`, resendAfter: OTP_RESEND_MS / 1000 });
  } catch (err) {
    console.error('Error sending OTP:', err);
    res.status(500).json({ error: 'فشل إرسال رمز التحقق' });
  }
});

// 2) التحقق من الرمز → تذكرة لإكمال الاسم المستعار وكلمة المرور والجنس والعمر
app.post('/api/auth/verify-gmail-otp', async (req, res) => {
  try {
    const cleanEmail = String((req.body && req.body.email) || '').trim().toLowerCase();
    const cleanCode = String((req.body && req.body.code) || '').trim();
    if (!cleanEmail || !cleanCode) {
      return res.status(400).json({ error: 'البريد الإلكتروني ورمز التحقق مطلوبان' });
    }

    const record = await get('SELECT * FROM email_verifications WHERE email = ?', [cleanEmail]);
    if (!record || Date.now() > Number(record.expires_at)) {
      if (record) await run('DELETE FROM email_verifications WHERE email = ?', [cleanEmail]);
      return res.status(400).json({ error: 'انتهت صلاحية الرمز، اطلب رمزاً جديداً' });
    }
    if (Number(record.attempts || 0) >= OTP_MAX_ATTEMPTS) {
      await run('DELETE FROM email_verifications WHERE email = ?', [cleanEmail]);
      return res.status(429).json({ error: 'تجاوزت عدد المحاولات، اطلب رمزاً جديداً' });
    }

    const a = Buffer.from(String(record.code));
    const b = Buffer.from(cleanCode);
    const ok = a.length === b.length && crypto.timingSafeEqual(a, b);
    if (!ok) {
      await run('UPDATE email_verifications SET attempts = attempts + 1 WHERE email = ?', [cleanEmail]);
      const left = OTP_MAX_ATTEMPTS - (Number(record.attempts || 0) + 1);
      return res.status(400).json({ error: left > 0 ? `رمز التحقق غير صحيح (تبقّى ${left} محاولات)` : 'رمز التحقق غير صحيح، اطلب رمزاً جديداً' });
    }
    await run('DELETE FROM email_verifications WHERE email = ?', [cleanEmail]);
    await grantSignupTicket(res, cleanEmail);
  } catch (err) {
    console.error('Verify OTP error:', err);
    res.status(500).json({ error: 'فشل التحقق' });
  }
});

// 2b) رفع الصورة الشخصية أثناء التسجيل (إلزامية): تتطلب تذكرة تحقق صالحة (رأس x-signup-ticket)
const SIGNUP_IMG_EXT = new Set(['.png', '.jpg', '.jpeg', '.gif', '.webp']);
async function requireSignupTicket(req, res, next) {
  try {
    const tk = String(req.headers['x-signup-ticket'] || '');
    const t = tk ? await get('SELECT * FROM auth_tickets WHERE id = ?', [tk]) : null;
    if (!t || Date.now() > Number(t.expires_at)) return res.status(400).json({ error: 'انتهت جلسة التحقق، أعد إدخال بريدك' });
    next();
  } catch (e) { res.status(500).json({ error: 'فشل رفع الصورة' }); }
}
app.post('/api/auth/upload-avatar', requireSignupTicket, upload.single('avatar'), (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'اختر صورة شخصية — إلزامية' });
    const ext = path.extname(req.file.filename).toLowerCase();
    if (!String(req.file.mimetype || '').startsWith('image/') || !SIGNUP_IMG_EXT.has(ext)) {
      try { fs.unlinkSync(req.file.path); } catch (e) {}
      return res.status(400).json({ error: 'الملف يجب أن يكون صورة (png / jpg / webp / gif)' });
    }
    res.json({ success: true, url: `/uploads/${req.file.filename}` });
  } catch (err) {
    res.status(500).json({ error: 'فشل رفع الصورة' });
  }
});

// 3) إنشاء الاسم المستعار وكلمة المرور (والجنس والعمر — إلزاميين لكل حساب جديد) ثم الدخول
app.post('/api/auth/complete-signup', async (req, res) => {
  try {
    const { ticket } = req.body || {};
    const password = typeof (req.body || {}).password === 'string' ? req.body.password : '';
    const t = ticket ? await get('SELECT * FROM auth_tickets WHERE id = ?', [String(ticket)]) : null;
    if (!t || Date.now() > Number(t.expires_at)) {
      if (t) await run('DELETE FROM auth_tickets WHERE id = ?', [t.id]);
      return res.status(400).json({ error: 'انتهت جلسة التحقق، أعد إدخال بريدك واطلب رمزاً جديداً' });
    }
    const email = t.email;
    const viaGoogle = String(t.id).startsWith('g_');
    const existing = await get('SELECT * FROM users WHERE email = ?', [email]);
    if (existing && existing.is_banned) {
      return res.status(403).json({ error: 'هذا الحساب محظور من قبل الإدارة 🚫' });
    }
    const cred = existing ? await get('SELECT * FROM user_credentials WHERE user_id = ?', [existing.id]) : null;

    if (password && (password.length < 6 || password.length > 64)) {
      return res.status(400).json({ error: 'كلمة المرور يجب أن تكون بين 6 و 64 حرفاً' });
    }

    // البريد مسجّل بالفعل باسم مستعار: لا يُسمح بإعادة استخدامه للتسجيل أو الدخول، فقط بالاسم وكلمة المرور
    if (existing && cred) {
      await run('DELETE FROM auth_tickets WHERE id = ?', [t.id]);
      // حساب مسجّل + بريد موثّق عبر Google: دخول مباشر بدون اسم مستعار أو كلمة مرور
      // (البريد موثّق دائماً هنا: عبر Google أو عبر رمز Gmail) — دخول مباشر بالحساب المسجّل مسبقاً
      return res.json(await issueSession(existing, cred.nickname));
    }

    // حساب جديد أو قديم بلا كلمة مرور: الاسم المستعار وكلمة المرور والجنس والعمر إلزاميين
    // (حتى التسجيل عبر Google: تُضبط كلمة المرور هنا كي يدخل صاحب الحساب من أي جهاز
    //  بالاسم المستعار وكلمة المرور، وليس عبر Google فقط)
    // الاسم الظاهر في الدردشة (displayName) مختلف عن اسم الحساب للدخول (username)
    const displayName = cleanNickname(req.body.nickname);
    if (!isValidNickname(displayName)) {
      return res.status(400).json({ error: 'اسم الدردشة من 2 إلى 30 حرفاً، بدون الرموز < > & "' });
    }
    const username = String(req.body.username || '').trim();
    if (!/^[\p{L}\p{N}_.\-]{3,30}$/u.test(username)) {
      return res.status(400).json({ error: 'اسم الحساب للدخول من 3 إلى 30 حرفاً (حروف وأرقام و _ . - فقط، بدون مسافات)' });
    }
    const effectivePassword = password;
    if (!effectivePassword) {
      return res.status(400).json({ error: 'كلمة المرور مطلوبة (6 أحرف على الأقل)' });
    }
    const age = parseSignupAge(req.body.age);
    if (age === null) {
      return res.status(400).json({ error: `اختر عمرك (من ${MIN_SIGNUP_AGE} إلى ${MAX_SIGNUP_AGE} سنة)` });
    }
    const gender = String((req.body && req.body.gender) || '').toLowerCase().trim();
    if (gender !== 'male' && gender !== 'female' && gender !== 'other') {
      return res.status(400).json({ error: 'اختر نوع الجنس (ذكر / أنثى / أخرى)' });
    }
    // الصورة الشخصية إلزامية: مسار ملف مرفوع فعلاً على الخادم عبر /api/auth/upload-avatar
    const avatarUrl = String(req.body.avatar || '');
    if (!/^\/uploads\/[\w.\-]+$/.test(avatarUrl) || !SIGNUP_IMG_EXT.has(path.extname(avatarUrl).toLowerCase())
        || !fs.existsSync(path.join(__dirname, 'public', avatarUrl))) {
      return res.status(400).json({ error: 'ارفع صورتك الشخصية — إلزامية' });
    }
    const selfId = existing ? existing.id : '';
    const takenUser = await get(
      'SELECT user_id AS id FROM user_credentials WHERE LOWER(nickname) = LOWER(?) AND user_id != ?',
      [username, selfId]
    );
    if (takenUser) {
      return res.status(409).json({ error: 'اسم الحساب هذا مستخدم، اختر اسماً آخر للدخول' });
    }
    const takenDisplay = await get('SELECT id FROM users WHERE LOWER(name) = LOWER(?) AND id != ?', [displayName, selfId]);
    if (takenDisplay) {
      return res.status(409).json({ error: 'اسم الدردشة هذا مستخدم، اختر اسماً آخر' });
    }

    const { salt, hash } = await hashPassword(effectivePassword);
    let user = existing;
    let isNew = false;
    if (!user) {
      isNew = true;
      const newId = await generateUserId();
      let welcomeCoins = 0, welcomeDiamonds = 0;
      try { const w = await getWalletSettings(); welcomeCoins = w.new_user_coins; welcomeDiamonds = w.new_user_diamonds; } catch (e) {}
      const planets = ['كوكب الرومانسي الحالم 🌌', 'كوكب المغامر الشغوف 🚀', 'كوكب الفنان الملهم 🎨', 'كوكب الفيلسوف الحكيم 🔮', 'كوكب النسمة الهادئة 🍃'];
      await run(`
        INSERT INTO users (id, google_id, email, name, avatar, bio, gender, age, soul_planet, soul_score, soul_tags, coins, diamonds, level, wealth_level, charm_level)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        newId, `google-${email}`, email, displayName,
        avatarUrl,
        'عضو موثق عبر Gmail في SoulChill 🪐✨',
        gender,
        age,
        planets[crypto.randomInt(0, planets.length)],
        88 + crypto.randomInt(0, 11),
        'بثوث,طرب,شات,ألعاب',
        welcomeCoins, welcomeDiamonds, 1, 1, 1
      ]);
      user = await get('SELECT * FROM users WHERE id = ?', [newId]);
    } else {
      isNew = true; // حساب قديم بلا كلمة مرور يُكمل بياناته: نعاملها كتسجيل جديد (يمر على شاشة الاهتمامات)
      await run('UPDATE users SET name = ?, gender = ?, age = ?, avatar = ? WHERE id = ?', [displayName, gender, age, avatarUrl, existing.id]);
    }

    try {
      await run('INSERT INTO user_credentials (user_id, nickname, password_hash, password_salt) VALUES (?, ?, ?, ?)', [user.id, username, hash, salt]);
    } catch (credErr) {
      // فشل حفظ بيانات الدخول (مثل اسم مأخوذ بالتزامن): لا نترك حساباً يتيماً يحجز البريد
      if (!existing) { try { await run('DELETE FROM users WHERE id = ?', [user.id]); } catch (e) {} }
      throw credErr;
    }
    // لا تُنشأ غرفة تلقائياً: الفتاة تنشئ غرفتها بنفسها (وهي إحدى مهامها اليومية)
    await run('DELETE FROM auth_tickets WHERE id = ?', [t.id]);
    user = await get('SELECT * FROM users WHERE id = ?', [user.id]);
    res.json({ ...(await issueSession(user, username)), is_new: isNew });
  } catch (err) {
    if (String(err.message || '').includes('UNIQUE')) {
      return res.status(409).json({ error: 'اسم الحساب مستخدم، اختر اسماً آخر' });
    }
    console.error('Complete signup error:', err);
    res.status(500).json({ error: 'فشل إنشاء الحساب' });
  }
});

// 4) الدخول من أي جهاز بالاسم المستعار وكلمة المرور
app.post('/api/auth/login-nickname', async (req, res) => {
  try {
    const nickname = cleanNickname(req.body && req.body.nickname);
    const password = typeof (req.body || {}).password === 'string' ? req.body.password : '';
    if (!nickname || !password) {
      return res.status(400).json({ error: 'أدخل الاسم المستعار وكلمة المرور' });
    }

    const key = `${req.ip || 'unknown'}|${nickname.toLowerCase()}`;
    const fail = loginFailures.get(key);
    if (fail && fail.until > Date.now()) {
      return res.status(429).json({ error: 'محاولات خاطئة كثيرة، حاول بعد بضع دقائق' });
    }

    let cred = await get('SELECT * FROM user_credentials WHERE LOWER(nickname) = LOWER(?)', [nickname]);
    // يقبل أيضاً بريد Gmail كاسم دخول: يُطابَق البريد مع حسابه ثم يُتحقق من كلمة مروره
    if (!cred && EMAIL_RE.test(nickname)) {
      const byEmail = await get('SELECT id FROM users WHERE LOWER(email) = LOWER(?)', [nickname]);
      if (byEmail) cred = await get('SELECT * FROM user_credentials WHERE user_id = ?', [byEmail.id]);
    }
    const ok = cred
      ? await checkPassword(password, cred.password_salt, cred.password_hash)
      : (await hashPassword(password, '00000000000000000000000000000000'), false); // تقريب زمن الرد
    if (!ok) {
      const nowTs = Date.now();
      // نافذة 10 دقائق لعدّ المحاولات الخاطئة؛ بعد 8 محاولات يُقفل الدخول 10 دقائق
      const f = fail && nowTs - fail.first < 10 * 60 * 1000 ? fail : { count: 0, first: nowTs, until: 0 };
      f.count += 1;
      if (f.count >= 8) { f.until = nowTs + 10 * 60 * 1000; }
      loginFailures.set(key, f);
      return res.status(401).json({ error: 'الاسم المستعار أو كلمة المرور غير صحيحة' });
    }
    loginFailures.delete(key);

    const user = await get('SELECT * FROM users WHERE id = ?', [cred.user_id]);
    if (!user) return res.status(401).json({ error: 'الاسم المستعار أو كلمة المرور غير صحيحة' });
    if (user.is_banned) return res.status(403).json({ error: 'هذا الحساب محظور من قبل الإدارة 🚫' });
    res.json(await issueSession(user, cred.nickname));
  } catch (err) {
    console.error('Nickname login error:', err);
    res.status(500).json({ error: 'فشل تسجيل الدخول' });
  }
});

// 5) التسجيل عبر حساب Google: نتحقق من توقيع الـID Token لدى Google (وأنه صادر لتطبيقنا والبريد موثّق)
//    ثم نمنح التذكرة نفسها لإكمال الاسم المستعار وكلمة المرور والجنس والعمر.
// إعدادات Google OAuth: الأولوية لما تحفظه الإدارة من لوحة التحكم (app_settings)، ثم ملف .env كاحتياط
async function getGoogleConfig() {
  let rows = [];
  try {
    rows = await all(`SELECT key, value FROM app_settings WHERE key IN ('google_client_id','google_client_secret','google_redirect_uri')`);
  } catch (e) {}
  const m = {};
  rows.forEach(r => { m[r.key] = String(r.value || '').trim(); });
  const clientId = m.google_client_id || String(process.env.GOOGLE_CLIENT_ID || '').trim();
  const clientSecret = m.google_client_id ? (m.google_client_secret || '') : String(process.env.GOOGLE_CLIENT_SECRET || '').trim();
  // قد يحتوي الإعداد على عنوان واحد أو عدة عناوين (سطر لكل عنوان أو مفصولة بفاصلة)
  const rawRedirect = m.google_redirect_uri || String(process.env.GOOGLE_REDIRECT_URI || '');
  const redirectUris = parseRedirectList(rawRedirect);
  return {
    clientId, clientSecret,
    redirectUris,
    redirectUri: redirectUris[0] || '', // للتوافق مع الاستدعاءات القديمة
    enabled: !!(clientId && clientSecret),
    source: m.google_client_id ? 'admin' : (process.env.GOOGLE_CLIENT_ID ? 'env' : 'none')
  };
}

app.get('/api/auth/google-config', async (req, res) => {
  const cfg = await getGoogleConfig();
  res.json({ enabled: cfg.enabled, clientId: cfg.clientId });
});

// ---- تدفق «اختيار حساب» الكامل من Google (إعادة توجيه OAuth) ----
// ملاحظة: يجب أن يطابق redirect_uri أحد العناوين المسجّلة في
// Google Console ← Credentials ← Authorized redirect URIs حرفياً،
// وإلا ظهر الخطأ: 400 redirect_uri_mismatch.
const googleOAuthStates = new Map(); // state -> { exp, redirectUri } — نحفظ العنوان المستخدم فعلياً لنتابع به عند تبادل الرمز
function googleRedirectUri(req, cfg) {
  return pickRedirectUri(req, { redirectUris: (cfg && cfg.redirectUris) || [] });
}
function googleOAuthClient(redirectUri, cfg) {
  return new OAuth2Client(cfg.clientId, cfg.clientSecret, redirectUri);
}

app.get('/api/auth/google/start', async (req, res) => {
  const cfg = await getGoogleConfig();
  if (!cfg.enabled) {
    return res.redirect('/#google_error=not_configured');
  }
  const redirectUri = googleRedirectUri(req, cfg);
  if (!redirectUri) {
    console.warn('[Google OAuth] تعذّر تحديد redirect_uri من الطلب (لا يوجد Host صالح)');
    return res.redirect('/#google_error=not_configured');
  }
  const now = Date.now();
  for (const [k, rec] of googleOAuthStates) if (!rec || rec.exp < now) googleOAuthStates.delete(k);
  const state = crypto.randomBytes(24).toString('hex');
  googleOAuthStates.set(state, { exp: now + 10 * 60 * 1000, redirectUri });
  const url = googleOAuthClient(redirectUri, cfg).generateAuthUrl({
    scope: ['openid', 'email', 'profile'],
    state,
    prompt: 'select_account', // يعرض دائماً شاشة «اختيار حساب»
    access_type: 'online'
  });
  console.log(`[Google OAuth] بدء التسجيل → redirect_uri=${redirectUri}` +
    (cfg.redirectUris.length ? '' : ' (محسوب تلقائياً — تأكد من تسجيله في Google Console)'));
  res.redirect(url);
});

app.get('/api/auth/google/callback', async (req, res) => {
  const back = (frag) => res.redirect('/#' + frag);
  try {
    const cfg = await getGoogleConfig();
    if (!cfg.enabled) return back('google_error=not_configured');
    const { code, state, error } = req.query || {};
    const rec = state ? googleOAuthStates.get(String(state)) : null;
    if (state) googleOAuthStates.delete(String(state)); // استخدام واحد فقط
    if (error) return back('google_error=cancelled');
    if (!rec || rec.exp < Date.now() || !code) return back('google_error=expired');

    // نستخدم العنوان نفسه الذي بدأنا به الرحلة حرفياً (مطابقة تامة عند تبادل الرمز مع Google)
    const redirectUri = rec.redirectUri || googleRedirectUri(req, cfg);
    const client = googleOAuthClient(redirectUri, cfg);
    const { tokens } = await client.getToken(String(code));
    const loginTicket = await client.verifyIdToken({ idToken: tokens.id_token, audience: cfg.clientId });
    const payload = loginTicket.getPayload() || {};
    const cleanEmail = String(payload.email || '').trim().toLowerCase();
    if (!payload.email_verified || !EMAIL_RE.test(cleanEmail)) return back('google_error=unverified');

    const r = await signupTicketFor(cleanEmail, { google: true });
    if (r.status === 200) {
      // نمرّر التذكرة في الـfragment (#) كي لا تصل إلى سجلات الخوادم
      const b = r.body;
      return back(`google_ticket=${encodeURIComponent(b.ticket)}&gs=${b.account_status}&gn=${encodeURIComponent(b.nickname || '')}`);
    }
    if (r.body.code === 'email_registered') return back('google_error=email_registered');
    return back('google_error=banned');
  } catch (err) {
    console.error('Google callback error:', err && err.message);
    return back('google_error=failed');
  }
});

// ---- إعدادات Google من لوحة الإدارة ----
function maskSecret(v) { return v ? (v.length > 8 ? v.slice(0, 4) + '••••••••' + v.slice(-3) : '••••••••') : ''; }

app.get('/api/admin/settings/google', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const cfg = await getGoogleConfig();
    res.json({
      success: true,
      enabled: cfg.enabled,
      source: cfg.source,
      client_id: cfg.clientId,
      has_secret: !!cfg.clientSecret,
      secret_preview: maskSecret(cfg.clientSecret),
      // النص الخام المحفوظ (سطر لكل عنوان إن كان متعدداً) لتعبئة الحقل في اللوحة
      redirect_uri: cfg.redirectUris.join('\n'),
      redirect_uris: cfg.redirectUris,
      // العنوان الذي يشتقه الخادم من طلب الإدارة الحالي (المرجع لإضافته في Google Console)
      suggested_redirect_uri: derivedRedirectUri(req),
      // العنوان الذي سيُرسل فعلياً إلى Google الآن لو بدأ الدخول من هذه الصفحة
      active_redirect_uri: googleRedirectUri(req, cfg),
      // أصل الموقع الحالي — يُسجَّل في Google Console ← Authorized JavaScript origins (لزر Google المنبثق)
      javascript_origin: requestOrigin(req)
    });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/admin/settings/google', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const b = req.body || {};
    const clientId = String(b.client_id || '').trim();
    const secret = String(b.client_secret || '').trim();   // فارغ = إبقاء السر المحفوظ كما هو
    const rawRedirect = String(b.redirect_uri || '').trim(); // عنوان واحد أو عدة عناوين (سطر لكل عنوان)
    if (clientId && !/^[0-9A-Za-z\-_.]+\.apps\.googleusercontent\.com$/.test(clientId)) {
      return res.status(400).json({ error: 'Client ID غير صالح (يجب أن ينتهي بـ .apps.googleusercontent.com)' });
    }
    if (secret && secret.length < 10) return res.status(400).json({ error: 'Client Secret غير صالح' });
    let redirectList = [];
    if (rawRedirect) {
      const parts = rawRedirect.split(/[\r\n,;]+/).map(p => p.trim()).filter(Boolean);
      const bad = parts.filter(p => !normalizeRedirectUri(p));
      if (bad.length) {
        return res.status(400).json({
          error: `عنوان العودة غير صالح: «${bad[0]}» — يجب أن يبدأ بـ http(s):// وينتهي بـ ${CALLBACK_PATH} تماماً (بدون أسئلة أو فواصل)`
        });
      }
      redirectList = parseRedirectList(rawRedirect);
    }
    const upsert = (k, v) => run(`INSERT INTO app_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value`, [k, v]);
    const del = (k) => run(`DELETE FROM app_settings WHERE key = ?`, [k]);
    if (clientId) await upsert('google_client_id', clientId); else { await del('google_client_id'); await del('google_client_secret'); }
    if (clientId && secret) await upsert('google_client_secret', secret);
    if (redirectList.length) await upsert('google_redirect_uri', redirectList.join('\n')); else await del('google_redirect_uri');
    const cfg = await getGoogleConfig();
    if (clientId && !cfg.clientSecret) {
      return res.json({ success: true, enabled: false, warning: 'تم حفظ Client ID لكن Client Secret ما زال فارغاً' });
    }
    res.json({ success: true, enabled: cfg.enabled });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/admin/settings/google', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    await run(`DELETE FROM app_settings WHERE key IN ('google_client_id','google_client_secret','google_redirect_uri')`);
    res.json({ success: true });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post(['/api/auth/google', '/api/auth/google-token'], async (req, res) => {
  try {
    const gcfg = await getGoogleConfig();
    if (!gcfg.clientId) {
      return res.status(503).json({ error: 'الدخول عبر Google غير مفعّل بعد (أضف Client ID من لوحة الإدارة)' });
    }
    const credential = String((req.body && (req.body.credential || req.body.idToken)) || '');
    if (!credential || credential.length > 4096) {
      return res.status(400).json({ error: 'بيانات حساب Google غير صالحة' });
    }
    let payload;
    try {
      const ticket = await new OAuth2Client(gcfg.clientId).verifyIdToken({ idToken: credential, audience: gcfg.clientId });
      payload = ticket.getPayload();
    } catch (e) {
      return res.status(401).json({ error: 'تعذّر التحقق من حساب Google، حاول مجدداً' });
    }
    const cleanEmail = String((payload && payload.email) || '').trim().toLowerCase();
    if (!payload || !payload.email_verified || !EMAIL_RE.test(cleanEmail)) {
      return res.status(401).json({ error: 'بريد Google غير موثّق' });
    }
    await grantSignupTicket(res, cleanEmail, { google: true });
  } catch (err) {
    console.error('Google auth error:', err);
    res.status(500).json({ error: 'فشل التسجيل عبر Google' });
  }
});

// 2. Get Current User Profile
app.get('/api/users/me', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'] || req.query.userId || req.query.id;
    if (!userId || userId === 'null' || userId === 'undefined') {
      return res.status(401).json({ error: 'User ID missing', clearAuth: true });
    }

    let user = await get('SELECT * FROM users WHERE id = ?', [userId]);
    if (!user) {
      return res.status(401).json({ error: 'الحساب غير مسجّل. سجّل حساباً جديداً أو ادخل بحسابك', clearAuth: true });
    }

    res.json(user);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


// ===== LiveKit: البث الصوتي والمرئي المباشر (الراديو والكاميرا والميكروفون) =====
// إعدادات الخادم فقط: app_settings (لوحة الإدارة) مع احتياط متغيرات البيئة LIVEKIT_*.
// لا تُحفظ هذه الإعدادات في متصفح المستخدم إطلاقًا (قيود الخصوصية).
async function getLiveKitSettings() {
  let stored = {};
  try {
    const rows = await all(`SELECT key, value FROM app_settings WHERE key IN ('livekit_url','livekit_api_key','livekit_api_secret')`);
    (rows || []).forEach(r => { stored[r.key] = r.value; });
  } catch (e) {}
  const url = String(stored.livekit_url || process.env.LIVEKIT_URL || '').trim();
  const apiKey = String(stored.livekit_api_key || process.env.LIVEKIT_API_KEY || '').trim();
  const apiSecret = String(stored.livekit_api_secret || process.env.LIVEKIT_API_SECRET || '').trim();
  return { url, apiKey, apiSecret, configured: !!(url && apiKey && apiSecret) };
}

// توقيع JWT (HS256) لرمز انضمام LiveKit مباشرةً بـ node:crypto — بلا أي مكتبة خارجية
function signLiveKitJwt(apiKey, apiSecret, grants) {
  const b64 = (obj) => Buffer.from(JSON.stringify(obj)).toString('base64url');
  const header = b64({ alg: 'HS256', typ: 'JWT' });
  const payload = b64(grants);
  const sig = crypto.createHmac('sha256', apiSecret).update(`${header}.${payload}`).digest('base64url');
  return `${header}.${payload}.${sig}`;
}

// إصدار رمز انضمام مشارك إلى غرفة LiveKit (يتحقق من المستخدم عبر x-user-id كبقية الواجهات)
app.post('/api/livekit/token', async (req, res) => {
  try {
    // المعرّف من x-user-id؛ الزائر بلا معرّف يحصل على هوية مؤقتة للمشاهدة فقط
    const rawUser = String(req.headers['x-user-id'] || '').replace(/[^A-Za-z0-9_\-.]/g, '').slice(0, 64);
    const isGuest = !rawUser;
    // لاحقة عشوائية لكل رمز: تمنع دفع جلسة واحدة عند انضمام علبة تبويبين لنفس الحساب
    const identity = isGuest
      ? 'guest~' + crypto.randomBytes(4).toString('hex')
      : rawUser + '~' + crypto.randomBytes(3).toString('hex');
    const room = String((req.body && req.body.room) || '');
    if (!/^[A-Za-z0-9_\-.]{3,64}$/.test(room)) return res.status(400).json({ error: 'اسم غرفة LiveKit غير صالح' });
    const cfg = await getLiveKitSettings();
    if (!cfg.configured) {
      return res.status(503).json({ error: 'خدمة LiveKit غير مهيأة بعد — افتح لوحة الإدارة ← تبويب «البث» وأدخل رابط LiveKit ومفتاح API وسرّه لتفعيل البث الصوتي والمرئي المباشر (الراديو والكاميرا والميكروفون).' });
    }
    const canPublish = !isGuest && !(req.body && req.body.canPublish === false); // الزائر للمشاهدة فقط
    const now = Math.floor(Date.now() / 1000);
    const token = signLiveKitJwt(cfg.apiKey, cfg.apiSecret, {
      iss: cfg.apiKey,
      sub: identity,
      nbf: now - 10,
      exp: now + 6 * 3600, // رمز صالح 6 ساعات — يُجدد مع كل انضمام
      video: {
        room,
        roomJoin: true,
        canPublish,
        canSubscribe: true,
        canPublishData: true,
        canUpdateOwnMetadata: true
      }
    });
    res.json({ token, url: cfg.url, room, expiresIn: 6 * 3600 });
  } catch (err) {
    console.error('livekit token error:', err);
    res.status(500).json({ error: 'تعذر إصدار رمز LiveKit' });
  }
});

// حالة الإعدادات للواجهة العامة (لا تكشف الأسرار أبدًا)
app.get('/api/livekit/config', async (req, res) => {
  try {
    const cfg = await getLiveKitSettings();
    res.json({ configured: cfg.configured, url: cfg.configured ? cfg.url : null });
  } catch (err) {
    res.status(500).json({ error: 'خطأ داخلي في الخادم' });
  }
});

// قراءة/حفظ إعدادات LiveKit من لوحة الإدارة
app.get('/api/admin/settings/livekit', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const cfg = await getLiveKitSettings();
    res.json({ url: cfg.url, api_key: cfg.apiKey, has_secret: !!cfg.apiSecret, configured: cfg.configured });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/admin/settings/livekit', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const url = String(req.body?.url ?? '').trim();
    const apiKey = String(req.body?.api_key ?? '').trim();
    const apiSecret = String(req.body?.api_secret ?? '').trim();
    if (url && !/^https?:\/\//i.test(url) && !/^wss?:\/\//i.test(url)) {
      return res.status(400).json({ error: 'رابط LiveKit يجب أن يبدأ بـ ws:// أو wss:// أو http(s)://' });
    }
    const upsert = (k, v) => run(`INSERT INTO app_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value`, [k, v]);
    await upsert('livekit_url', url);
    await upsert('livekit_api_key', apiKey);
    if (apiSecret !== '') await upsert('livekit_api_secret', apiSecret); // اتركه فارغاً للإبقاء على المحفوظ
    const cfg = await getLiveKitSettings();
    // تطبيق فوري على كل الغرف: يُخطر العملاء المتصلين لإعادة الانضمام والحصول على رمز جديد
    try { if (typeof io !== 'undefined') io.emit('livekit_settings_updated', { configured: cfg.configured }); } catch (e) {}
    res.json({ ok: true, configured: cfg.configured, url: cfg.url });
  } catch (err) {
    console.error('livekit settings save error:', err);
    res.status(500).json({ error: 'تعذر حفظ إعدادات LiveKit' });
  }
});

// ===== رسالة الإدارة الثابتة التي تظهر لكل من يدخل أي غرفة (يضبطها الأدمن) =====
app.get('/api/settings/room-system-message', async (req, res) => {
  try {
    const row = await get(`SELECT value FROM app_settings WHERE key = 'room_system_message'`);
    res.json({ success: true, message: row ? (row.value || '') : '' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/admin/settings/room-system-message', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const row = await get(`SELECT value FROM app_settings WHERE key = 'room_system_message'`);
    res.json({ success: true, message: row ? (row.value || '') : '' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/admin/settings/room-system-message', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const message = String(req.body?.message ?? '').trim().slice(0, 1000);
    await run(`INSERT INTO app_settings (key, value) VALUES ('room_system_message', ?)
      ON CONFLICT(key) DO UPDATE SET value = excluded.value`, [message]);
    res.json({ success: true, message });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ===== إعدادات المحفظة والمكافأة اليومية (تضبطها الإدارة) =====
const WALLET_DEFAULTS = {
  daily_bonus_enabled: '1',
  daily_bonus_coins: '500',
  daily_bonus_diamonds: '50',
  daily_bonus_text: '',
  user_recharge_enabled: '0',
  new_user_coins: '0',
  new_user_diamonds: '0'
};
async function getWalletSettings() {
  const rows = await all(`SELECT key, value FROM app_settings WHERE key IN (${Object.keys(WALLET_DEFAULTS).map(() => '?').join(',')})`, Object.keys(WALLET_DEFAULTS));
  const m = { ...WALLET_DEFAULTS };
  rows.forEach(r => { m[r.key] = r.value; });
  const num = (v, d) => { const n = Math.floor(Number(v)); return Number.isFinite(n) && n >= 0 ? n : d; };
  return {
    daily_bonus_enabled: m.daily_bonus_enabled === '1',
    daily_bonus_coins: num(m.daily_bonus_coins, 500),
    daily_bonus_diamonds: num(m.daily_bonus_diamonds, 50),
    daily_bonus_text: String(m.daily_bonus_text || ''),
    user_recharge_enabled: m.user_recharge_enabled === '1',
    // رصيد الترحيب للعضو الجديد (تضبطه الإدارة، الافتراضي 0 = بلا رصيد)
    new_user_coins: num(m.new_user_coins, 0),
    new_user_diamonds: num(m.new_user_diamonds, 0)
  };
}
app.get('/api/settings/wallet', async (req, res) => {
  try {
    res.json({ success: true, settings: await getWalletSettings() });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
app.get('/api/admin/settings/wallet', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    res.json({ success: true, settings: await getWalletSettings() });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
app.post('/api/admin/settings/wallet', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const b = req.body || {};
    const clampInt = (v) => String(Math.min(1000000, Math.max(0, Math.floor(Number(v)) || 0)));
    const entries = {
      daily_bonus_enabled: b.daily_bonus_enabled ? '1' : '0',
      daily_bonus_coins: clampInt(b.daily_bonus_coins),
      daily_bonus_diamonds: clampInt(b.daily_bonus_diamonds),
      daily_bonus_text: String(b.daily_bonus_text ?? '').trim().slice(0, 200),
      user_recharge_enabled: b.user_recharge_enabled ? '1' : '0',
      new_user_coins: clampInt(b.new_user_coins),
      new_user_diamonds: clampInt(b.new_user_diamonds)
    };
    for (const [k, v] of Object.entries(entries)) {
      await run(`INSERT INTO app_settings (key, value) VALUES (?, ?)
        ON CONFLICT(key) DO UPDATE SET value = excluded.value`, [k, v]);
    }
    res.json({ success: true, settings: await getWalletSettings() });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 2b. Get User Profile by ID
// قواعد رفع المنشورات: تظهر مرة واحدة فقط لكل حساب (محفوظة في قاعدة البيانات)
app.get('/api/moment-rules/status', async (req, res) => {
  try {
    const uid = req.headers['x-user-id'];
    if (!uid) return res.json({ seen: false });
    const u = await get('SELECT moment_rules_seen FROM users WHERE id = ?', [uid]);
    res.json({ seen: !!(u && u.moment_rules_seen) });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
app.post('/api/moment-rules/seen', async (req, res) => {
  try {
    const uid = req.headers['x-user-id'];
    if (!uid) return res.status(401).json({ error: 'Unauthorized' });
    await run('UPDATE users SET moment_rules_seen = 1 WHERE id = ?', [uid]);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/users/:id', async (req, res) => {
  try {
    const user = await get('SELECT * FROM users WHERE id = ?', [req.params.id]);
    if (!user) return res.status(404).json({ error: 'User not found' });
    // VIP المنتهي يظهر VIP0 دائماً + بطاقات العرض (الثروة / الرواج / VIP)
    user.vip_level = require('./member-levels').activeVipLevel(user);
    user.cards = require('./member-levels').buildCards(user);
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 3. Update User Profile
// صور خلفية الملف الشخصي: حتى 6 صور، والصورة الأولى هي صورة الغلاف
app.put('/api/users/covers', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    if (!userId) return res.status(401).json({ error: 'Unauthorized' });
    if (!Array.isArray(req.body.images)) return res.status(400).json({ error: 'قائمة الصور غير صالحة' });
    const clean = req.body.images
      .filter(u => typeof u === 'string' && (u.startsWith('/uploads/') || /^https:\/\//i.test(u)))
      .map(u => u.slice(0, 500))
      .slice(0, 6);
    const exists = await get('SELECT id FROM users WHERE id = ?', [userId]);
    if (!exists) return res.status(404).json({ error: 'User not found' });
    await run('UPDATE users SET cover_images = ? WHERE id = ?', [JSON.stringify(clean), userId]);
    const user = await get('SELECT * FROM users WHERE id = ?', [userId]);
    res.json({ success: true, images: clean, user });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/users/profile', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    if (!userId) return res.status(401).json({ error: 'Unauthorized' });

    const { bio, gender, age, avatar, avatar_frame, chat_frame, soul_planet, soul_tags } = req.body;
    // الصورة الشخصية المتحركة (GIF): ميزة VIP3+ (أو امتياز الثروة المقابل). لا نمنع من يحتفظ بصورته الحالية.
    if (typeof avatar === 'string' && /\.gif(\?|#|$)|^data:image\/gif/i.test(avatar)) {
      const cur = await get('SELECT avatar, role, wealth_level, vip_level, vip_until FROM users WHERE id = ?', [userId]);
      if (cur && cur.avatar !== avatar && !PLATFORM_ADMIN_ROLES.includes(cur.role)
          && !vipPerks.hasPerk(cur, 'animated_avatar') && !userHasPerkSync(cur, 'animated_avatar', 141)) {
        return res.status(403).json({ error: `الصورة الشخصية المتحركة تتطلب VIP${vipPerks.perkLevel('animated_avatar')} أو أعلى 👑`, perk: 'animated_avatar' });
      }
    }
    // الاسم لا يتكرر: يُرفض أي اسم يستخدمه حساب آخر (حتى باختلاف حالة الأحرف)
    let name = req.body.name;
    let nameChanged = false;
    if (typeof name === 'string' && name.trim()) {
      name = name.replace(/\s+/g, ' ').trim();
      const cur = await get('SELECT name FROM users WHERE id = ?', [userId]);
      if (cur && cur.name.toLowerCase() !== name.toLowerCase()) {
        if (!isValidNickname(name)) return res.status(400).json({ error: 'الاسم من 2 إلى 30 حرفاً، بدون الرموز < > & "' });
        const clash = await get(
          `SELECT user_id AS id FROM user_credentials WHERE nickname = ? AND user_id != ?
           UNION SELECT id FROM users WHERE LOWER(name) = LOWER(?) AND id != ?`,
          [name, userId, name, userId]
        );
        if (clash) return res.status(409).json({ error: 'هذا الاسم مستخدم من قبل، اختر اسماً آخر' });
        nameChanged = true;
      } else if (cur) {
        name = cur.name; // نفس الاسم الحالي: لا تغيير
      }
    } else {
      name = undefined;
    }
    const country_code = SUPPORTED_COUNTRIES.some(c => c.code === req.body.country_code && !c.isGlobal) ? req.body.country_code : undefined;
    let entry_effect = req.body.entry_effect;
    // لا يُسمح بتفعيل قالب دخول إلا لمن يملكه
    if (entry_effect && !(await getOwnedEntryTemplate(userId, entry_effect))) entry_effect = undefined;
    // لا يُسمح بتفعيل إطار مرفوع من الإدارة إلا لمن اشتراه
    let pfFrame = avatar_frame;
    if (pfFrame && String(pfFrame).startsWith('cf-') && !(await getOwnedAvatarFrame(userId, pfFrame))) pfFrame = undefined;

    await run(`
      UPDATE users SET
        name = COALESCE(?, name),
        bio = COALESCE(?, bio),
        gender = COALESCE(?, gender),
        age = COALESCE(?, age),
        avatar = COALESCE(?, avatar),
        avatar_frame = COALESCE(?, avatar_frame),
        chat_frame = COALESCE(?, chat_frame),
        entry_effect = COALESCE(?, entry_effect),
        soul_planet = COALESCE(?, soul_planet),
        soul_tags = COALESCE(?, soul_tags),
        country_code = COALESCE(?, country_code)
      WHERE id = ?
    `, [name, bio, gender, age, avatar, pfFrame, chat_frame, entry_effect, soul_planet, soul_tags, country_code, userId]);
    pushUserAccessories(userId);

    if (nameChanged) {
      // اسم الدخول يتبع الاسم الظاهر ليبقى واحداً
      await run('UPDATE user_credentials SET nickname = ?, updated_at = CURRENT_TIMESTAMP WHERE user_id = ?', [name, userId]);
    }
    const updatedUser = await get('SELECT * FROM users WHERE id = ?', [userId]);
    res.json({ success: true, user: updatedUser });
  } catch (err) {
    if (String(err.message || '').includes('UNIQUE')) return res.status(409).json({ error: 'هذا الاسم مستخدم من قبل، اختر اسماً آخر' });
    res.status(500).json({ error: err.message });
  }
});

// 3a. Equip User Accessories (Chat Bubble Frame, Entry Effect, Avatar Frame)
// بثّ تغيير الإكسسوارات (إطار الصورة/الرسالة/قالب الدخول) فوراً لكل من في نفس الغرفة بدون إعادة تحميل
async function pushUserAccessories(userId) {
  try {
    const u = await get('SELECT id, avatar, avatar_frame, chat_frame, entry_effect, room_card FROM users WHERE id = ?', [userId]);
    if (!u) return;
    for (const [roomId, st] of activeRoomStates.entries()) {
      const a = st && st.activeAudience && st.activeAudience.get(userId);
      if (!a) continue;
      a.avatar = u.avatar; a.avatar_frame = u.avatar_frame; a.chat_frame = u.chat_frame; a.entry_effect = u.entry_effect;
      io.to(`room:${roomId}`).emit('user_accessories_updated', {
        userId, avatar: u.avatar, avatar_frame: u.avatar_frame, chat_frame: u.chat_frame, entry_effect: u.entry_effect, room_card: u.room_card
      });
    }
  } catch (e) { console.error('pushUserAccessories error:', e); }
}

app.post('/api/users/accessories', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'] || req.body?.userId;
    if (!userId) return res.status(401).json({ error: 'Unauthorized' });

    const { chat_frame, avatar_frame } = req.body;
    let entry_effect = req.body.entry_effect;
    // لا يُسمح بتفعيل قالب دخول إلا لمن يملكه
    if (entry_effect && !(await getOwnedEntryTemplate(userId, entry_effect))) {
      return res.status(403).json({ error: 'لا تملك قالب الدخول هذا، اشترِه أولاً بالكرستالات' });
    }

    if (avatar_frame && String(avatar_frame).startsWith('cf-') && !(await getOwnedAvatarFrame(userId, avatar_frame))) {
      return res.status(403).json({ error: 'لا تملك هذا الإطار، اشتره أولاً بالكرستالات' });
    }

    // اختيار إطار رسالة مدمج يلغي فقاعة الدردشة المفعّلة من المتجر (واحد فقط مفعّل)
    if (typeof chat_frame === 'string') {
      const su = await get('SELECT store_equipped FROM users WHERE id = ?', [userId]);
      const seq = parseEquipped(su && su.store_equipped);
      if (seq.chatbubble) {
        delete seq.chatbubble;
        await run('UPDATE users SET store_equipped = ? WHERE id = ?', [JSON.stringify(seq), userId]);
      }
    }
    await run(`
      UPDATE users SET
        chat_frame = COALESCE(?, chat_frame),
        entry_effect = COALESCE(?, entry_effect),
        avatar_frame = COALESCE(?, avatar_frame)
      WHERE id = ?
    `, [chat_frame, entry_effect, avatar_frame, userId]);
    pushUserAccessories(userId);

    const updatedUser = await get('SELECT * FROM users WHERE id = ?', [userId]);
    res.json({ success: true, user: updatedUser });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ===================== مدد الصلاحية + شراء عناصر المخزن =====================
const DURATION_OPTIONS = [0, 7, 14, 30]; // 0 = دائم
// فقاعات الدردشة ومقاعد المايك: دائمة، لا تنتهي ولا تختفي إلا بإلغاء المستخدم لها بنفسه
const PERMANENT_STORE_CATS = ['bubble', 'chatbubble', 'mic'];
function parseDuration(v, fallback) {
  const n = parseInt(v, 10);
  return DURATION_OPTIONS.includes(n) ? n : (fallback || 0);
}
// شراء/تجديد عنصر من المخزن: يخصم الكرستالات ثم يمنح العنصر (مع تاريخ انتهاء إن وُجدت مدة)
async function buyInventoryItem(userId, type, item, label) {
  if (item && Number(item.vip_only) === 1) return { ok: false, status: 403, error: 'هذا العنصر خاص بأعضاء VIP فقط ويُمنح تلقائياً مع العضوية' };
  const price = Math.max(0, parseInt(item.price, 10) || 0);
  const days = (type === 'store_item' && PERMANENT_STORE_CATS.includes(item.category)) ? 0 : parseDuration(item.duration_days, 0);
  const existing = await get(
    `SELECT id, (expires_at IS NULL OR expires_at > datetime('now')) AS active FROM user_inventory WHERE user_id = ? AND item_type = ? AND item_id = ?`,
    [userId, type, item.id]);
  if (existing && existing.active) return { status: 400, error: `تملك ${label} بالفعل` };
  const paid = await run('UPDATE users SET diamonds = diamonds - ? WHERE id = ? AND diamonds >= ?', [price, userId, price]);
  if (!paid.changes) return { status: 400, error: `رصيدك من الكرستالات غير كافٍ (السعر ${price} 💎)` };
  const expr = days > 0 ? `datetime('now', '+${days} days')` : 'NULL';
  try {
    if (existing) {
      await run(`UPDATE user_inventory SET expires_at = ${expr}, item_name = ?, created_at = CURRENT_TIMESTAMP WHERE id = ?`, [item.name, existing.id]);
    } else {
      await run(`INSERT INTO user_inventory (id, user_id, item_type, item_id, item_name, expires_at) VALUES (?, ?, ?, ?, ?, ${expr})`,
        [uuidv4(), userId, type, item.id, item.name]);
    }
  } catch (e) {
    await run('UPDATE users SET diamonds = diamonds + ? WHERE id = ?', [price, userId]);
    return { status: 400, error: `تملك ${label} بالفعل` };
  }
  // الشراء يرفع نقاط المستوى (حسب سعر العنصر بالكريستالات)
  if (price > 0) {
    try {
      const ps = await getPointSettings();
      await addLevelPoints(userId, memberLevels.pointsForAmount(price, 'diamonds', ps));
    } catch (e) {}
  }
  return { ok: true };
}
// إزالة العناصر المنتهية: تُفكّ من الحساب إن كانت مفعّلة ثم تُحذف من المخزن
let _lastPurge = 0;
async function purgeExpiredInventory(force) {
  const now = Date.now();
  if (!force && now - _lastPurge < 30000) return;
  _lastPurge = now;
  try {
    // عناصر الفقاعات والمقاعد دائمة: أزل أي تاريخ انتهاء قديم عنها قبل التنظيف
    await run(`UPDATE store_items SET duration_days = 0 WHERE category IN ('bubble', 'chatbubble', 'mic') AND duration_days != 0`);
    // (يُستثنى ما مُنح كمكافأة مستوى بمدة محددة: يبقى مؤقتاً ويُسحب عند انتهائه)
    await run(`UPDATE user_inventory SET expires_at = NULL WHERE item_type = 'store_item' AND expires_at IS NOT NULL AND item_id IN (SELECT id FROM store_items WHERE category IN ('bubble', 'chatbubble', 'mic'))
      AND item_id NOT IN (SELECT item_id FROM level_reward_items WHERE item_type = 'store_item' AND item_days > 0)`);
    const rows = await all(`SELECT id, user_id, item_type, item_id FROM user_inventory WHERE expires_at IS NOT NULL AND expires_at <= datetime('now')`);
    let cardsChanged = false;
    for (const r of rows) {
      if (r.item_type === 'entry_effect') await run(`UPDATE users SET entry_effect = '' WHERE id = ? AND entry_effect = ?`, [r.user_id, r.item_id]);
      else if (r.item_type === 'avatar_frame') {
        await run('UPDATE users SET avatar_frame = ? WHERE id = ? AND avatar_frame = ?', [DEFAULT_AVATAR_FRAME, r.user_id, r.item_id]);
      }
      else if (r.item_type === 'store_item') await unequipStoreItemEverywhere(r.user_id, r.item_id);
      else if (r.item_type === 'room_card') { const ch = await run(`UPDATE users SET room_card = '' WHERE id = ? AND room_card = ?`, [r.user_id, r.item_id]); if (ch.changes) cardsChanged = true; }
      await run('DELETE FROM user_inventory WHERE id = ?', [r.id]);
    }
    if (cardsChanged) io.emit('rooms_refresh', {});
    await purgeUnauthorizedVipItems();
  } catch (e) { console.error('purge expired inventory error:', e.message); }
}

// عناصر VIP الخاصة (vip_only) لا يملكها ولا يرتديها إلا صاحب عضوية فعّالة تتضمن العنصر في مستواه أو أدنى.
// يسحب ما أُخذ سابقاً بالخطأ كـ«مجاني» أو بقي بعد انتهاء العضوية، ويعيد الإطار/المؤثر الافتراضي. (ما يُمنح كمكافأة مستوى ثروة/رواج مستثنى)
async function purgeUnauthorizedVipItems() {
  try {
    // إطار VIP مرتدى دون أي سجل ملكية: يُعاد للافتراضي
    await run(`UPDATE users SET avatar_frame = ? WHERE avatar_frame IN (SELECT id FROM avatar_frames WHERE vip_only = 1)
      AND NOT EXISTS (SELECT 1 FROM user_inventory i WHERE i.user_id = users.id AND i.item_type = 'avatar_frame' AND i.item_id = users.avatar_frame AND (i.expires_at IS NULL OR i.expires_at > datetime('now')))`, [DEFAULT_AVATAR_FRAME]);
    const rows = await all(`
      SELECT i.id, i.user_id, i.item_type, i.item_id FROM user_inventory i
      WHERE ((i.item_type = 'avatar_frame' AND i.item_id IN (SELECT id FROM avatar_frames WHERE vip_only = 1))
         OR (i.item_type = 'entry_effect' AND i.item_id IN (SELECT id FROM entry_templates WHERE vip_only = 1))
         OR (i.item_type = 'room_card' AND i.item_id IN (SELECT id FROM room_cards WHERE vip_only = 1))
         OR (i.item_type = 'store_item' AND i.item_id IN (SELECT id FROM store_items WHERE vip_only = 1)))
        AND NOT EXISTS (SELECT 1 FROM level_rewards lr WHERE lr.item_type = i.item_type AND lr.item_id = i.item_id)
        AND NOT EXISTS (SELECT 1 FROM level_reward_items lri WHERE lri.item_type = i.item_type AND lri.item_id = i.item_id)`);
    if (!rows.length) return;
    const users = new Map();
    const touched = new Set();
    let cardsChanged = false;
    for (const r of rows) {
      if (!users.has(r.user_id)) users.set(r.user_id, await get('SELECT id, vip_level, vip_until FROM users WHERE id = ?', [r.user_id]));
      const u = users.get(r.user_id);
      const lvl = u ? memberLevels.activeVipLevel(u) : 0;
      if (lvl > 0 && await get('SELECT 1 AS x FROM vip_level_items WHERE item_type = ? AND item_id = ? AND level <= ?', [r.item_type, r.item_id, lvl])) continue;
      if (r.item_type === 'entry_effect') await run(`UPDATE users SET entry_effect = '' WHERE id = ? AND entry_effect = ?`, [r.user_id, r.item_id]);
      else if (r.item_type === 'avatar_frame') await run('UPDATE users SET avatar_frame = ? WHERE id = ? AND avatar_frame = ?', [DEFAULT_AVATAR_FRAME, r.user_id, r.item_id]);
      else if (r.item_type === 'store_item') await unequipStoreItemEverywhere(r.user_id, r.item_id);
      else if (r.item_type === 'room_card') { const ch = await run(`UPDATE users SET room_card = '' WHERE id = ? AND room_card = ?`, [r.user_id, r.item_id]); if (ch.changes) cardsChanged = true; }
      await run('DELETE FROM user_inventory WHERE id = ?', [r.id]);
      await run('DELETE FROM vip_granted_items WHERE user_id = ? AND item_type = ? AND item_id = ?', [r.user_id, r.item_type, r.item_id]);
      touched.add(r.user_id);
    }
    for (const uid of touched) { try { pushUserAccessories(uid); } catch (e) {} }
    if (cardsChanged) io.emit('rooms_refresh', {});
  } catch (e) { console.error('purgeUnauthorizedVipItems error:', e.message); }
}
setInterval(() => purgeExpiredInventory(true), 60 * 1000);
setTimeout(() => purgeExpiredInventory(true), 5000);

// ===================== قوالب الدخول (تُشترى بالكرستالات) =====================
// يرجع القالب فقط إذا كان المستخدم يملكه (وإلا null)
async function getOwnedEntryTemplate(userId, templateId) {
  if (!userId || !templateId) return null;
  const row = await get(`
    SELECT t.id, t.name, t.image_url
    FROM entry_templates t
    JOIN user_inventory i ON i.item_id = t.id AND i.user_id = ? AND i.item_type = 'entry_effect' AND (i.expires_at IS NULL OR i.expires_at > datetime('now'))
    WHERE t.id = ?
  `, [userId, templateId]);
  return row || null;
}

function safeDeleteEntryImage(imageUrl) {
  try {
    if (!imageUrl || !imageUrl.startsWith('/uploads/entry-')) return;
    const uploadsDir = path.join(__dirname, 'public', 'uploads');
    const full = path.join(__dirname, 'public', imageUrl);
    if (path.dirname(full) === uploadsDir && fs.existsSync(full)) fs.unlinkSync(full);
  } catch (e) { console.error('delete entry image error:', e.message); }
}

const ENTRY_IMAGE_EXT = { 'image/png': '.png', 'image/jpeg': '.jpg', 'image/gif': '.gif', 'image/webp': '.webp' };
// قوالب الدخول تقبل أيضاً مقاطع الفيديو (MP4 / WEBM / MOV) بالإضافة إلى الصور وGIF
const ENTRY_MEDIA_EXT = Object.assign({}, ENTRY_IMAGE_EXT, { 'video/mp4': '.mp4', 'video/webm': '.webm', 'video/quicktime': '.mp4' });
// قوالب الدخول تقبل أيضاً ملف HTML (.html/.htm) بحد أقصى 15MB (الصور والفيديو تبقى حتى 25MB)
const ENTRY_HTML_MAX_BYTES = 15 * 1024 * 1024;
// الحد الأقصى لصور لوحة الإدارة (هدايا، إيموجي، إطارات، بطاقات، متجر، خلفيات...) — الافتراضي 25MB ويمكن تغييره بمتغير البيئة ADMIN_IMAGE_MAX_MB
const ADMIN_IMAGE_MAX_MB = Math.max(1, parseInt(process.env.ADMIN_IMAGE_MAX_MB, 10) || 25);
const ADMIN_IMAGE_MAX_BYTES = ADMIN_IMAGE_MAX_MB * 1024 * 1024;
const ENTRY_HTML_RE = /\.html?(\?|#|$)/i;
const isEntryHtmlFile = (file) => file.mimetype === 'text/html' || /\.html?$/i.test(file.originalname || '');

// ===== دعم ملفات HTML في عناصر الإدارة (الإطارات، بطاقات الغرف، خلفيات الغرف، عناصر المتجر) =====
// الحد الأقصى لملف HTML = 15MB، أما الصور فتبقى على حدّها الأصلي لكل قسم.
const ASSET_HTML_MAX_BYTES = 15 * 1024 * 1024;
const assetFileOk = (file) => !!ENTRY_IMAGE_EXT[file.mimetype] || isEntryHtmlFile(file);
const assetExt = (file, fallback) => isEntryHtmlFile(file) ? '.html' : (ENTRY_IMAGE_EXT[file.mimetype] || fallback);
// يرجع نص الخطأ إن كان الملف غير صالح، وإلا نصاً فارغاً
function validateAssetUpload(file, imageMaxBytes) {
  if (!file) return '';
  if (isEntryHtmlFile(file)) {
    if (file.size > ASSET_HTML_MAX_BYTES) return 'حجم ملف HTML أكبر من 15MB';
    let head = Buffer.alloc(0);
    try {
      const fd = fs.openSync(file.path, 'r');
      head = Buffer.alloc(Math.min(4096, file.size));
      fs.readSync(fd, head, 0, head.length, 0);
      fs.closeSync(fd);
    } catch (e) { head = Buffer.alloc(0); }
    if (!head.length || head.includes(0) || !head.toString('utf8').includes('<')) return 'الملف ليس HTML صالحاً';
    return '';
  }
  if (file.size > imageMaxBytes) return `حجم الصورة أكبر من ${Math.round(imageMaxBytes / 1048576)}MB`;
  return '';
}
const entryImageUpload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      const uploadDir = path.join(__dirname, 'public', 'uploads');
      if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });
      cb(null, uploadDir);
    },
    filename: (req, file, cb) => cb(null, `entry-${Date.now()}-${uuidv4().slice(0, 8)}${isEntryHtmlFile(file) ? '.html' : (ENTRY_MEDIA_EXT[file.mimetype] || '.png')}`)
  }),
  limits: { fileSize: Math.max(25 * 1024 * 1024, ADMIN_IMAGE_MAX_BYTES) },
  fileFilter: (req, file, cb) => {
    if (ENTRY_MEDIA_EXT[file.mimetype] || isEntryHtmlFile(file)) cb(null, true);
    else cb(new Error('يُسمح فقط بصور PNG/JPG/GIF/WEBP أو فيديو MP4/WEBM أو ملف HTML'));
  }
});

// حذف ما رُفع في الطلب الحالي (عند فشل التحقق)
function entryDiscardUploads(req) {
  if (req.file) safeDeleteEntryImage(`/uploads/${req.file.filename}`);
  if (req.posterFile) safeDeleteEntryImage(`/uploads/${req.posterFile.filename}`);
}

// توليد صورة ثابتة من أول لقطة في الفيديو عبر ffmpeg (اختياري؛ إن لم يتوفر ffmpeg يُتجاهل بصمت)
function generateEntryVideoPoster(videoFilename) {
  return new Promise((resolve) => {
    try {
      const { execFile } = require('child_process');
      const uploadsDir = path.join(__dirname, 'public', 'uploads');
      const input = path.join(uploadsDir, videoFilename);
      const outName = `entry-${Date.now()}-${uuidv4().slice(0, 8)}-poster.jpg`;
      const output = path.join(uploadsDir, outName);
      execFile(process.env.FFMPEG_PATH || 'ffmpeg', ['-y', '-ss', '0.5', '-i', input, '-frames:v', '1', '-q:v', '3', output], { timeout: 20000 }, (err) => {
        if (!err && fs.existsSync(output)) return resolve(`/uploads/${outName}`);
        // الفيديو قد يكون أقصر من 0.5 ثانية: نحاول من البداية
        execFile(process.env.FFMPEG_PATH || 'ffmpeg', ['-y', '-i', input, '-frames:v', '1', '-q:v', '3', output], { timeout: 20000 }, (err2) => {
          resolve(!err2 && fs.existsSync(output) ? `/uploads/${outName}` : '');
        });
      });
    } catch (e) { resolve(''); }
  });
}

const ENTRY_VIDEO_RE = /\.(mp4|webm|mov|m4v)(\?|#|$)/i;

// التحقق من صلاحية الإدارة قبل استقبال الملف، ثم رفع الصورة
async function adminEntryImageUpload(req, res, next) {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  entryImageUpload.fields([{ name: 'image', maxCount: 1 }, { name: 'poster', maxCount: 1 }])(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.code === 'LIMIT_FILE_SIZE' ? 'حجم الملف أكبر من الحد المسموح (الصور/الفيديو 25MB، HTML 15MB)' : err.message });
    const f = req.files || {};
    req.file = (f.image && f.image[0]) || null;
    req.posterFile = (f.poster && f.poster[0]) || null;
    // ملف HTML: حد أقصى 15MB + يجب أن يكون نصاً (وليس ملفاً ثنائياً مُعاد تسميته)
    if (req.file && ENTRY_HTML_RE.test(req.file.filename)) {
      if (req.file.size > ENTRY_HTML_MAX_BYTES) {
        entryDiscardUploads(req);
        return res.status(400).json({ error: 'حجم ملف HTML أكبر من 15MB' });
      }
      let head = Buffer.alloc(0);
      try {
        const fd = fs.openSync(req.file.path, 'r');
        head = Buffer.alloc(Math.min(4096, req.file.size));
        fs.readSync(fd, head, 0, head.length, 0);
        fs.closeSync(fd);
      } catch (e) { head = Buffer.alloc(0); }
      if (!head.length || head.includes(0) || !head.toString('utf8').includes('<')) {
        entryDiscardUploads(req);
        return res.status(400).json({ error: 'الملف ليس HTML صالحاً' });
      }
    }
    // الصورة الثابتة يجب أن تكون صورة فقط
    if (req.posterFile && !ENTRY_IMAGE_EXT[req.posterFile.mimetype]) {
      entryDiscardUploads(req);
      return res.status(400).json({ error: 'الصورة الثابتة يجب أن تكون PNG/JPG/GIF/WEBP' });
    }
    next();
  });
}

// قائمة القوالب للمستخدم (المتاحة للبيع + ما يملكه)
app.get('/api/entry-templates', async (req, res) => {
  try {
    await purgeExpiredInventory();
    const userId = req.headers['x-user-id'] || '';
    const rows = await all(`
      SELECT t.id, t.name, t.image_url, t.poster_url, t.price, t.is_active, t.duration_days,
             CASE WHEN i.id IS NULL THEN 0 ELSE 1 END AS owned, i.created_at AS owned_at, i.expires_at AS expires_at
      FROM entry_templates t
      LEFT JOIN user_inventory i ON i.item_id = t.id AND i.user_id = ? AND i.item_type = 'entry_effect' AND (i.expires_at IS NULL OR i.expires_at > datetime('now'))
      WHERE (t.is_active = 1 AND t.vip_only = 0) OR i.id IS NOT NULL
      ORDER BY t.created_at DESC, t.rowid DESC
    `, [userId]);
    const u = userId ? await get('SELECT entry_effect FROM users WHERE id = ?', [userId]) : null;
    res.json({
      templates: rows.map(r => ({ id: r.id, name: r.name, image_url: r.image_url, poster_url: r.poster_url || '', price: r.price, duration_days: r.duration_days || 0, owned: !!r.owned, owned_at: r.owned_at || null, expires_at: r.expires_at || null })),
      equipped: (u && u.entry_effect) || ''
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// مؤثرات الدخول التي اشتراها مستخدم معيّن (عامة: تظهر في ملفه الشخصي لأي زائر)
app.get('/api/users/:id/entry-effects', async (req, res) => {
  try {
    await purgeExpiredInventory();
    const id = req.params.id;
    const rows = await all(`
      SELECT t.id, t.name, t.image_url, t.poster_url
      FROM user_inventory i
      JOIN entry_templates t ON t.id = i.item_id
      WHERE i.user_id = ? AND i.item_type = 'entry_effect' AND (i.expires_at IS NULL OR i.expires_at > datetime('now'))
      ORDER BY i.created_at DESC
    `, [id]);
    const u = await get('SELECT entry_effect FROM users WHERE id = ?', [id]);
    res.json({ effects: rows, equipped: (u && u.entry_effect) || '' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// شراء قالب دخول بالكرستالات (الألماس)
app.post('/api/entry-templates/:id/buy', async (req, res) => {
  const userId = req.headers['x-user-id'];
  if (!userId) return res.status(401).json({ error: 'سجّل الدخول أولاً' });
  try {
    const tpl = await get('SELECT * FROM entry_templates WHERE id = ? AND is_active = 1', [req.params.id]);
    if (!tpl) return res.status(404).json({ error: 'هذا القالب غير متاح للشراء' });
    const user = await get('SELECT id FROM users WHERE id = ?', [userId]);
    if (!user) return res.status(404).json({ error: 'المستخدم غير موجود' });

    const bought = await buyInventoryItem(userId, 'entry_effect', tpl, 'هذا القالب');
    if (!bought.ok) return res.status(bought.status).json({ error: bought.error });

    const updatedUser = await get('SELECT * FROM users WHERE id = ?', [userId]);
    res.json({ success: true, user: updatedUser });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// تفعيل قالب دخول يملكه المستخدم (أو إلغاء التفعيل بإرسال templateId فارغ)
app.post('/api/entry-templates/equip', async (req, res) => {
  const userId = req.headers['x-user-id'];
  if (!userId) return res.status(401).json({ error: 'سجّل الدخول أولاً' });
  try {
    const templateId = req.body && req.body.templateId ? String(req.body.templateId) : '';
    if (templateId && !(await getOwnedEntryTemplate(userId, templateId))) {
      return res.status(403).json({ error: 'لا تملك قالب الدخول هذا، اشترِه أولاً بالكرستالات' });
    }
    await run('UPDATE users SET entry_effect = ? WHERE id = ?', [templateId, userId]);
    pushUserAccessories(userId);
    const updatedUser = await get('SELECT * FROM users WHERE id = ?', [userId]);
    res.json({ success: true, user: updatedUser });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ---- إدارة القوالب من لوحة الإدارة ----
app.get('/api/admin/entry-templates', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const rows = await all(`
      SELECT t.*, (SELECT COUNT(*) FROM user_inventory i WHERE i.item_type = 'entry_effect' AND i.item_id = t.id) AS owners_count
      FROM entry_templates t WHERE t.vip_only = 0 ORDER BY t.created_at DESC, t.rowid DESC
    `);
    res.json({ templates: rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/admin/entry-templates', adminEntryImageUpload, async (req, res) => {
  try {
    const name = String(req.body.name || '').trim();
    const price = parseInt(req.body.price, 10);
    if (!name) { entryDiscardUploads(req); return res.status(400).json({ error: 'يرجى كتابة اسم القالب' }); }
    if (!Number.isFinite(price) || price < 0) { entryDiscardUploads(req); return res.status(400).json({ error: 'يرجى إدخال سعر صحيح بالكرستالات' }); }
    if (!req.file) { entryDiscardUploads(req); return res.status(400).json({ error: 'يرجى اختيار صورة أو فيديو أو ملف HTML للقالب' }); }

    // الفيديو: نستخدم الصورة الثابتة المرسلة من لوحة الإدارة، وإلا نحاول توليدها بـ ffmpeg
    let posterUrl = '';
    if (ENTRY_VIDEO_RE.test(req.file.filename)) {
      posterUrl = req.posterFile ? `/uploads/${req.posterFile.filename}` : await generateEntryVideoPoster(req.file.filename);
    } else if (ENTRY_HTML_RE.test(req.file.filename)) {
      // HTML: لا يمكن توليد لقطة تلقائياً؛ نستخدم الصورة الثابتة التي يرفعها المشرف (اختيارية) للمصغّرات
      posterUrl = req.posterFile ? `/uploads/${req.posterFile.filename}` : '';
    } else if (req.posterFile) {
      safeDeleteEntryImage(`/uploads/${req.posterFile.filename}`);
    }

    const id = `entry-${uuidv4().slice(0, 8)}`;
    const vipOnly = String(req.body.vip_only) === '1';   // رفع من قسم مزايا VIP: مخفي عن المتجر
    await run('INSERT INTO entry_templates (id, name, image_url, poster_url, price, duration_days, is_active, vip_only) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [id, name, `/uploads/${req.file.filename}`, posterUrl, vipOnly ? 0 : price, parseDuration(req.body.duration_days, 0), vipOnly ? 0 : 1, vipOnly ? 1 : 0]);
    io.emit('charge_agents_updated', { at: Date.now() });
    res.json({ success: true, id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/admin/entry-templates/:id', adminEntryImageUpload, async (req, res) => {
  try {
    const tpl = await get('SELECT * FROM entry_templates WHERE id = ?', [req.params.id]);
    if (!tpl) { entryDiscardUploads(req); return res.status(404).json({ error: 'القالب غير موجود' }); }

    const name = req.body.name !== undefined ? String(req.body.name).trim() : tpl.name;
    const price = req.body.price !== undefined ? parseInt(req.body.price, 10) : tpl.price;
    const isActive = req.body.is_active !== undefined ? (String(req.body.is_active) === '1' || req.body.is_active === 'true' ? 1 : 0) : tpl.is_active;
    if (!name || !Number.isFinite(price) || price < 0) {
      entryDiscardUploads(req);
      return res.status(400).json({ error: 'يرجى التأكد من الاسم والسعر' });
    }

    let imageUrl = tpl.image_url;
    let posterUrl = tpl.poster_url || '';
    if (req.file) {
      // ملف جديد: نستبدل الملف القديم وصورته الثابتة
      imageUrl = `/uploads/${req.file.filename}`;
      safeDeleteEntryImage(tpl.image_url);
      safeDeleteEntryImage(posterUrl);
      posterUrl = '';
      if (ENTRY_VIDEO_RE.test(req.file.filename)) {
        posterUrl = req.posterFile ? `/uploads/${req.posterFile.filename}` : await generateEntryVideoPoster(req.file.filename);
      } else if (ENTRY_HTML_RE.test(req.file.filename)) {
        posterUrl = req.posterFile ? `/uploads/${req.posterFile.filename}` : '';
      } else if (req.posterFile) {
        safeDeleteEntryImage(`/uploads/${req.posterFile.filename}`);
      }
    } else if (req.posterFile && (ENTRY_VIDEO_RE.test(tpl.image_url || '') || ENTRY_HTML_RE.test(tpl.image_url || ''))) {
      // تحديث الصورة الثابتة فقط (أو إنشاؤها لقالب فيديو قديم)
      safeDeleteEntryImage(posterUrl);
      posterUrl = `/uploads/${req.posterFile.filename}`;
    } else if (!posterUrl && ENTRY_VIDEO_RE.test(tpl.image_url || '')) {
      // قالب فيديو قديم بلا صورة ثابتة: نحاول توليدها
      posterUrl = await generateEntryVideoPoster(path.basename(tpl.image_url));
    } else if (req.posterFile) {
      safeDeleteEntryImage(`/uploads/${req.posterFile.filename}`);
    }
    await run('UPDATE entry_templates SET name = ?, price = ?, is_active = ?, image_url = ?, poster_url = ?, duration_days = ? WHERE id = ?',
      [name, price, isActive, imageUrl, posterUrl, req.body.duration_days !== undefined ? parseDuration(req.body.duration_days, 0) : (tpl.duration_days || 0), tpl.id]);
    await run(`UPDATE user_inventory SET item_name = ? WHERE item_type = 'entry_effect' AND item_id = ?`, [name, tpl.id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/admin/entry-templates/:id', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const tpl = await get('SELECT * FROM entry_templates WHERE id = ?', [req.params.id]);
    if (!tpl) return res.status(404).json({ error: 'القالب غير موجود' });
    await run(`DELETE FROM user_inventory WHERE item_type = 'entry_effect' AND item_id = ?`, [tpl.id]);
    await run(`UPDATE users SET entry_effect = '' WHERE entry_effect = ?`, [tpl.id]);
    await run('DELETE FROM entry_templates WHERE id = ?', [tpl.id]);
    safeDeleteEntryImage(tpl.image_url);
    safeDeleteEntryImage(tpl.poster_url);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ===================== إطارات الأفاتار (تُرفع من الإدارة وتُشترى بالكرستالات) =====================
const DEFAULT_AVATAR_FRAME = 'cosmic_ring';

async function getOwnedAvatarFrame(userId, frameId) {
  if (!userId || !frameId) return null;
  const row = await get(`
    SELECT f.id, f.name, f.image_url, f.scale
    FROM avatar_frames f
    JOIN user_inventory i ON i.item_id = f.id AND i.user_id = ? AND i.item_type = 'avatar_frame' AND (i.expires_at IS NULL OR i.expires_at > datetime('now'))
    WHERE f.id = ?
  `, [userId, frameId]);
  return row || null;
}

function safeDeleteFrameImage(imageUrl) {
  try {
    if (!imageUrl || !imageUrl.startsWith('/uploads/frame-')) return;
    const uploadsDir = path.join(__dirname, 'public', 'uploads');
    const full = path.join(__dirname, 'public', imageUrl);
    if (path.dirname(full) === uploadsDir && fs.existsSync(full)) fs.unlinkSync(full);
  } catch (e) { console.error('delete frame image error:', e.message); }
}

const frameImageUpload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      const uploadDir = path.join(__dirname, 'public', 'uploads');
      if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });
      cb(null, uploadDir);
    },
    filename: (req, file, cb) => cb(null, `frame-${Date.now()}-${uuidv4().slice(0, 8)}${assetExt(file, '.png')}`)
  }),
  limits: { fileSize: Math.max(ASSET_HTML_MAX_BYTES, ADMIN_IMAGE_MAX_BYTES) },
  fileFilter: (req, file, cb) => {
    if (assetFileOk(file)) cb(null, true);
    else cb(new Error('يُسمح فقط بصور PNG أو GIF أو WEBP أو JPG أو ملف HTML'));
  }
});

async function adminFrameImageUpload(req, res, next) {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  frameImageUpload.single('image')(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.code === 'LIMIT_FILE_SIZE' ? `حجم الملف أكبر من الحد المسموح (الصور ${ADMIN_IMAGE_MAX_MB}MB، HTML 15MB)` : err.message });
    const bad = validateAssetUpload(req.file, ADMIN_IMAGE_MAX_BYTES);
    if (bad) { safeDeleteFrameImage(`/uploads/${req.file.filename}`); return res.status(400).json({ error: bad }); }
    next();
  });
}

function parseFrameScale(v, fallback) {
  const n = parseFloat(v);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(2, Math.max(1, n));
}

// قائمة الإطارات: يحتاجها الجميع لرسم إطارات الآخرين، والمالك فقط يرى owned
app.get('/api/avatar-frames', async (req, res) => {
  try {
    await purgeExpiredInventory();
    const userId = req.headers['x-user-id'] || '';
    const rows = await all(`
      SELECT f.id, f.name, f.image_url, f.price, f.scale, f.is_active, f.duration_days, f.vip_only,
             CASE WHEN i.id IS NULL THEN 0 ELSE 1 END AS owned, i.created_at AS owned_at, i.expires_at AS expires_at
      FROM avatar_frames f
      LEFT JOIN user_inventory i ON i.item_id = f.id AND i.user_id = ? AND i.item_type = 'avatar_frame' AND (i.expires_at IS NULL OR i.expires_at > datetime('now'))
      ORDER BY f.created_at DESC, f.rowid DESC
    `, [userId]);
    const u = userId ? await get('SELECT avatar_frame FROM users WHERE id = ?', [userId]) : null;
    res.json({
      frames: rows.map(r => ({
        id: r.id, name: r.name, image_url: r.image_url, price: r.price, scale: r.scale,
        is_active: !!r.is_active, vip_only: !!r.vip_only, duration_days: r.duration_days || 0, owned: !!r.owned, owned_at: r.owned_at || null, expires_at: r.expires_at || null
      })),
      equipped: (u && u.avatar_frame) || ''
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/avatar-frames/:id/buy', async (req, res) => {
  const userId = req.headers['x-user-id'];
  if (!userId) return res.status(401).json({ error: 'سجّل الدخول أولاً' });
  try {
    const frame = await get('SELECT * FROM avatar_frames WHERE id = ? AND is_active = 1', [req.params.id]);
    if (!frame) return res.status(404).json({ error: 'هذا الإطار غير متاح للشراء' });
    const user = await get('SELECT id FROM users WHERE id = ?', [userId]);
    if (!user) return res.status(404).json({ error: 'المستخدم غير موجود' });

    const bought = await buyInventoryItem(userId, 'avatar_frame', frame, 'هذا الإطار');
    if (!bought.ok) return res.status(bought.status).json({ error: bought.error });

    const updatedUser = await get('SELECT * FROM users WHERE id = ?', [userId]);
    res.json({ success: true, user: updatedUser });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ---- إدارة الإطارات من لوحة الإدارة ----
app.get('/api/admin/avatar-frames', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const rows = await all(`
      SELECT f.*, (SELECT COUNT(*) FROM user_inventory i WHERE i.item_type = 'avatar_frame' AND i.item_id = f.id) AS owners_count
      FROM avatar_frames f WHERE f.vip_only = 0 ORDER BY f.created_at DESC, f.rowid DESC
    `);
    res.json({ frames: rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/admin/avatar-frames', adminFrameImageUpload, async (req, res) => {
  try {
    const name = String(req.body.name || '').trim();
    const price = parseInt(req.body.price, 10);
    const scale = parseFrameScale(req.body.scale, 1.3);
    const drop = () => { if (req.file) safeDeleteFrameImage(`/uploads/${req.file.filename}`); };
    if (!name) { drop(); return res.status(400).json({ error: 'يرجى كتابة اسم الإطار' }); }
    if (!Number.isFinite(price) || price < 0) { drop(); return res.status(400).json({ error: 'يرجى إدخال سعر صحيح بالكرستالات' }); }
    if (!req.file) return res.status(400).json({ error: 'يرجى اختيار صورة أو ملف HTML للإطار' });

    const id = `cf-${uuidv4().slice(0, 8)}`;
    const vipOnly = String(req.body.vip_only) === '1';   // رفع من قسم مزايا VIP: مخفي عن المتجر
    await run('INSERT INTO avatar_frames (id, name, image_url, price, scale, duration_days, is_active, vip_only) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [id, name, `/uploads/${req.file.filename}`, vipOnly ? 0 : price, scale, parseDuration(req.body.duration_days, 0), vipOnly ? 0 : 1, vipOnly ? 1 : 0]);
    res.json({ success: true, id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/admin/avatar-frames/:id', adminFrameImageUpload, async (req, res) => {
  try {
    const frame = await get('SELECT * FROM avatar_frames WHERE id = ?', [req.params.id]);
    const drop = () => { if (req.file) safeDeleteFrameImage(`/uploads/${req.file.filename}`); };
    if (!frame) { drop(); return res.status(404).json({ error: 'الإطار غير موجود' }); }

    const name = req.body.name !== undefined ? String(req.body.name).trim() : frame.name;
    const price = req.body.price !== undefined ? parseInt(req.body.price, 10) : frame.price;
    const scale = req.body.scale !== undefined ? parseFrameScale(req.body.scale, frame.scale) : frame.scale;
    const isActive = req.body.is_active !== undefined ? (String(req.body.is_active) === '1' || req.body.is_active === 'true' ? 1 : 0) : frame.is_active;
    if (!name || !Number.isFinite(price) || price < 0) { drop(); return res.status(400).json({ error: 'يرجى التأكد من الاسم والسعر' }); }

    let imageUrl = frame.image_url;
    if (req.file) {
      imageUrl = `/uploads/${req.file.filename}`;
      safeDeleteFrameImage(frame.image_url);
    }
    await run('UPDATE avatar_frames SET name = ?, price = ?, scale = ?, is_active = ?, image_url = ?, duration_days = ? WHERE id = ?',
      [name, price, scale, isActive, imageUrl, req.body.duration_days !== undefined ? parseDuration(req.body.duration_days, 0) : (frame.duration_days || 0), frame.id]);
    await run(`UPDATE user_inventory SET item_name = ? WHERE item_type = 'avatar_frame' AND item_id = ?`, [name, frame.id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/admin/avatar-frames/:id', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const frame = await get('SELECT * FROM avatar_frames WHERE id = ?', [req.params.id]);
    if (!frame) return res.status(404).json({ error: 'الإطار غير موجود' });
    await run(`DELETE FROM user_inventory WHERE item_type = 'avatar_frame' AND item_id = ?`, [frame.id]);
    await run('UPDATE users SET avatar_frame = ? WHERE avatar_frame = ?', [DEFAULT_AVATAR_FRAME, frame.id]);
    await run('DELETE FROM avatar_frames WHERE id = ?', [frame.id]);
    safeDeleteFrameImage(frame.image_url);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ===================== بطاقات الغرف (شكل غرفة المستخدم من الخارج في قائمة الغرف) =====================
async function getOwnedRoomCard(userId, cardId) {
  if (!userId || !cardId) return null;
  const row = await get(`
    SELECT c.id, c.name, c.image_url
    FROM room_cards c
    JOIN user_inventory i ON i.item_id = c.id AND i.user_id = ? AND i.item_type = 'room_card' AND (i.expires_at IS NULL OR i.expires_at > datetime('now'))
    WHERE c.id = ?
  `, [userId, cardId]);
  return row || null;
}

function safeDeleteRoomCardImage(imageUrl) {
  try {
    if (!imageUrl || !imageUrl.startsWith('/uploads/roomcard-')) return;
    const uploadsDir = path.join(__dirname, 'public', 'uploads');
    const full = path.join(__dirname, 'public', imageUrl);
    if (path.dirname(full) === uploadsDir && fs.existsSync(full)) fs.unlinkSync(full);
  } catch (e) { console.error('delete room card image error:', e.message); }
}

const roomCardImageUpload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      const uploadDir = path.join(__dirname, 'public', 'uploads');
      if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });
      cb(null, uploadDir);
    },
    filename: (req, file, cb) => cb(null, `roomcard-${Date.now()}-${uuidv4().slice(0, 8)}${assetExt(file, '.png')}`)
  }),
  limits: { fileSize: Math.max(ASSET_HTML_MAX_BYTES, ADMIN_IMAGE_MAX_BYTES) },
  fileFilter: (req, file, cb) => {
    if (assetFileOk(file)) cb(null, true);
    else cb(new Error('يُسمح فقط بصور PNG أو JPG أو GIF أو WEBP أو ملف HTML'));
  }
});

async function adminRoomCardImageUpload(req, res, next) {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  roomCardImageUpload.single('image')(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.code === 'LIMIT_FILE_SIZE' ? `حجم الملف أكبر من الحد المسموح (الصور ${ADMIN_IMAGE_MAX_MB}MB، HTML 15MB)` : err.message });
    const bad = validateAssetUpload(req.file, ADMIN_IMAGE_MAX_BYTES);
    if (bad) { safeDeleteRoomCardImage(`/uploads/${req.file.filename}`); return res.status(400).json({ error: bad }); }
    next();
  });
}

// قائمة البطاقات للمستخدم (المتاحة للبيع + ما يملكه) مع البطاقة المفعّلة
app.get('/api/room-cards', async (req, res) => {
  try {
    await purgeExpiredInventory();
    const userId = req.headers['x-user-id'] || '';
    const rows = await all(`
      SELECT c.id, c.name, c.image_url, c.price, c.is_active, c.duration_days,
             CASE WHEN i.id IS NULL THEN 0 ELSE 1 END AS owned, i.created_at AS owned_at, i.expires_at AS expires_at
      FROM room_cards c
      LEFT JOIN user_inventory i ON i.item_id = c.id AND i.user_id = ? AND i.item_type = 'room_card' AND (i.expires_at IS NULL OR i.expires_at > datetime('now'))
      WHERE c.is_active = 1 OR i.id IS NOT NULL
      ORDER BY c.created_at DESC, c.rowid DESC
    `, [userId]);
    const u = userId ? await get('SELECT room_card FROM users WHERE id = ?', [userId]) : null;
    res.json({
      cards: rows.map(r => ({ id: r.id, name: r.name, image_url: r.image_url, price: r.price, duration_days: r.duration_days || 0, owned: !!r.owned, owned_at: r.owned_at || null, expires_at: r.expires_at || null })),
      equipped: (u && u.room_card) || ''
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/room-cards/:id/buy', async (req, res) => {
  const userId = req.headers['x-user-id'];
  if (!userId) return res.status(401).json({ error: 'سجّل الدخول أولاً' });
  try {
    const card = await get('SELECT * FROM room_cards WHERE id = ? AND is_active = 1', [req.params.id]);
    if (!card) return res.status(404).json({ error: 'هذه البطاقة غير متاحة للشراء' });
    const user = await get('SELECT id FROM users WHERE id = ?', [userId]);
    if (!user) return res.status(404).json({ error: 'المستخدم غير موجود' });

    const bought = await buyInventoryItem(userId, 'room_card', card, 'هذه البطاقة');
    if (!bought.ok) return res.status(bought.status).json({ error: bought.error });

    const updatedUser = await get('SELECT * FROM users WHERE id = ?', [userId]);
    res.json({ success: true, user: updatedUser });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// تفعيل بطاقة يملكها المستخدم على غرفته (أو إلغاء التفعيل بإرسال cardId فارغ)
app.post('/api/room-cards/equip', async (req, res) => {
  const userId = req.headers['x-user-id'];
  if (!userId) return res.status(401).json({ error: 'سجّل الدخول أولاً' });
  try {
    const cardId = req.body && req.body.cardId ? String(req.body.cardId) : '';
    if (cardId && !(await getOwnedRoomCard(userId, cardId))) {
      return res.status(403).json({ error: 'لا تملك بطاقة الغرفة هذه، اشترِها أولاً بالكرستالات' });
    }
    await run('UPDATE users SET room_card = ? WHERE id = ?', [cardId, userId]);
    io.emit('rooms_refresh', { host_id: userId });
    pushUserAccessories(userId);
    const updatedUser = await get('SELECT * FROM users WHERE id = ?', [userId]);
    res.json({ success: true, user: updatedUser });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ---- إدارة بطاقات الغرف من لوحة الإدارة ----
app.get('/api/admin/room-cards', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const rows = await all(`
      SELECT c.*, (SELECT COUNT(*) FROM user_inventory i WHERE i.item_type = 'room_card' AND i.item_id = c.id) AS owners_count
      FROM room_cards c WHERE c.vip_only = 0 ORDER BY c.created_at DESC, c.rowid DESC
    `);
    res.json({ cards: rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/admin/room-cards', adminRoomCardImageUpload, async (req, res) => {
  try {
    const name = String(req.body.name || '').trim();
    const price = parseInt(req.body.price, 10);
    const drop = () => { if (req.file) safeDeleteRoomCardImage(`/uploads/${req.file.filename}`); };
    if (!name) { drop(); return res.status(400).json({ error: 'يرجى كتابة اسم البطاقة' }); }
    if (!Number.isFinite(price) || price < 0) { drop(); return res.status(400).json({ error: 'يرجى إدخال سعر صحيح بالكرستالات' }); }
    if (!req.file) return res.status(400).json({ error: 'يرجى اختيار صورة أو ملف HTML للبطاقة' });

    const id = `rc-${uuidv4().slice(0, 8)}`;
    const vipOnly = String(req.body.vip_only) === '1';   // رفع من قسم مزايا VIP: مخفي عن المتجر
    await run('INSERT INTO room_cards (id, name, image_url, price, duration_days, is_active, vip_only) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [id, name, `/uploads/${req.file.filename}`, vipOnly ? 0 : price, parseDuration(req.body.duration_days, 0), vipOnly ? 0 : 1, vipOnly ? 1 : 0]);
    res.json({ success: true, id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/admin/room-cards/:id', adminRoomCardImageUpload, async (req, res) => {
  try {
    const card = await get('SELECT * FROM room_cards WHERE id = ?', [req.params.id]);
    const drop = () => { if (req.file) safeDeleteRoomCardImage(`/uploads/${req.file.filename}`); };
    if (!card) { drop(); return res.status(404).json({ error: 'البطاقة غير موجودة' }); }

    const name = req.body.name !== undefined ? String(req.body.name).trim() : card.name;
    const price = req.body.price !== undefined ? parseInt(req.body.price, 10) : card.price;
    const isActive = req.body.is_active !== undefined ? (String(req.body.is_active) === '1' || req.body.is_active === 'true' ? 1 : 0) : card.is_active;
    if (!name || !Number.isFinite(price) || price < 0) { drop(); return res.status(400).json({ error: 'يرجى التأكد من الاسم والسعر' }); }

    let imageUrl = card.image_url;
    if (req.file) {
      imageUrl = `/uploads/${req.file.filename}`;
      safeDeleteRoomCardImage(card.image_url);
    }
    await run('UPDATE room_cards SET name = ?, price = ?, is_active = ?, image_url = ?, duration_days = ? WHERE id = ?',
      [name, price, isActive, imageUrl, req.body.duration_days !== undefined ? parseDuration(req.body.duration_days, 0) : (card.duration_days || 0), card.id]);
    await run(`UPDATE user_inventory SET item_name = ? WHERE item_type = 'room_card' AND item_id = ?`, [name, card.id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/admin/room-cards/:id', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const card = await get('SELECT * FROM room_cards WHERE id = ?', [req.params.id]);
    if (!card) return res.status(404).json({ error: 'البطاقة غير موجودة' });
    await run(`DELETE FROM user_inventory WHERE item_type = 'room_card' AND item_id = ?`, [card.id]);
    await run(`UPDATE users SET room_card = '' WHERE room_card = ?`, [card.id]);
    await run('DELETE FROM room_cards WHERE id = ?', [card.id]);
    safeDeleteRoomCardImage(card.image_url);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


// ===================== عناصر المتجر العامة (تُدار من الإدارة) =====================
// الأقسام: بطاقات الصوت · فقاعات الدخول (شريط join-banner-host) · فقاعات الدردشة (رسائل الغرفة) · مقاعد المايك
const STORE_CATEGORIES = {
  idcard:     'بطاقات الصوت',
  bubble:     'فقاعات الدخول',
  chatbubble: 'فقاعات الدردشة',
  mic:        'مقاعد المايك'
};

function safeDeleteStoreImage(imageUrl) {
  try {
    if (!imageUrl || !imageUrl.startsWith('/uploads/store-')) return;
    const uploadsDir = path.join(__dirname, 'public', 'uploads');
    const full = path.join(__dirname, 'public', imageUrl);
    if (path.dirname(full) === uploadsDir && fs.existsSync(full)) fs.unlinkSync(full);
  } catch (e) { console.error('delete store image error:', e.message); }
}

const storeImageUpload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      const uploadDir = path.join(__dirname, 'public', 'uploads');
      if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });
      cb(null, uploadDir);
    },
    filename: (req, file, cb) => cb(null, `store-${Date.now()}-${uuidv4().slice(0, 8)}${assetExt(file, '.png')}`)
  }),
  limits: { fileSize: Math.max(ASSET_HTML_MAX_BYTES, ADMIN_IMAGE_MAX_BYTES) },
  fileFilter: (req, file, cb) => {
    if (assetFileOk(file)) cb(null, true);
    else cb(new Error('يُسمح فقط بصور PNG أو JPG أو GIF أو WEBP أو ملف HTML'));
  }
});

async function adminStoreImageUpload(req, res, next) {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  storeImageUpload.single('image')(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.code === 'LIMIT_FILE_SIZE' ? `حجم الملف أكبر من الحد المسموح (الصور ${ADMIN_IMAGE_MAX_MB}MB، HTML 15MB)` : err.message });
    const bad = validateAssetUpload(req.file, ADMIN_IMAGE_MAX_BYTES);
    if (bad) { safeDeleteStoreImage(`/uploads/${req.file.filename}`); return res.status(400).json({ error: bad }); }
    next();
  });
}

function parseEquipped(raw) {
  try { const o = JSON.parse(raw || '{}'); return (o && typeof o === 'object') ? o : {}; } catch (e) { return {}; }
}

// فك تفعيل عنصر عند انتهاء مدته أو حذفه
async function unequipStoreItemEverywhere(userId, itemId) {
  try {
    const where = userId ? 'WHERE id = ?' : `WHERE store_equipped LIKE ?`;
    const args = userId ? [userId] : [`%${itemId}%`];
    const rows = await all(`SELECT id, store_equipped FROM users ${where}`, args);
    for (const u of rows) {
      const eq = parseEquipped(u.store_equipped);
      let changed = false;
      for (const k of Object.keys(eq)) if (eq[k] === itemId) { delete eq[k]; changed = true; }
      if (changed) await run('UPDATE users SET store_equipped = ? WHERE id = ?', [JSON.stringify(eq), u.id]);
    }
  } catch (e) { console.error('unequip store item error:', e.message); }
}

// عنصر المتجر المفعّل لقسم معيّن (bubble / mic ...): ترجع رابط الملف إن كان المستخدم يملكه وهو ساري
async function getEquippedStoreUrl(userId, category) {
  try {
    if (!userId) return '';
    const u = await get('SELECT store_equipped FROM users WHERE id = ?', [userId]);
    const itemId = parseEquipped(u && u.store_equipped)[category];
    if (!itemId) return '';
    const row = await get(`
      SELECT s.image_url FROM store_items s
      JOIN user_inventory i ON i.item_id = s.id AND i.user_id = ? AND i.item_type = 'store_item' AND (i.expires_at IS NULL OR i.expires_at > datetime('now'))
      WHERE s.id = ? AND s.category = ?`, [userId, itemId, category]);
    return (row && row.image_url) || '';
  } catch (e) { return ''; }
}

// فقاعة الدردشة المفعّلة من المتجر (قسم «فقاعات الدردشة») — تُستعمل خلفية لرسائل الغرفة
async function getEquippedBubbleUrl(userId) { return getEquippedStoreUrl(userId, 'chatbubble'); }
// فقاعة الدخول المفعّلة من المتجر (قسم «فقاعات الدخول») — تُستعمل في شريط الدخول join-banner-host وسطر «دخل فلان الغرفة»
async function getEquippedJoinBubbleUrl(userId) { return getEquippedStoreUrl(userId, 'bubble'); }

// إطار/شكل المقعد المفعّل من المتجر (قسم «مقاعد المايك») — يظهر لكل من في الغرفة على مقعد صاحبه فقط
async function getEquippedMicSeatUrl(userId) { return getEquippedStoreUrl(userId, 'mic'); }

// بطاقة الصوت المفعّلة (قسم «بطاقات الصوت»): تظهر على مقعد صاحبها عندما يتكلم فقط
async function getEquippedVoiceCardUrl(userId) { return getEquippedStoreUrl(userId, 'idcard'); }

// قائمة العناصر للمستخدم: المعروضة للبيع + ما يملكه، مع المفعّل
app.get('/api/store-items', async (req, res) => {
  try {
    await purgeExpiredInventory();
    const userId = req.headers['x-user-id'] || '';
    const category = String(req.query.category || '');
    if (category && !STORE_CATEGORIES[category]) return res.status(400).json({ error: 'قسم غير معروف' });
    const rows = await all(`
      SELECT s.id, s.category, s.name, s.image_url, s.price, s.duration_days, s.badge, s.is_active,
             CASE WHEN i.id IS NULL THEN 0 ELSE 1 END AS owned, i.expires_at AS expires_at
      FROM store_items s
      LEFT JOIN user_inventory i ON i.item_id = s.id AND i.user_id = ? AND i.item_type = 'store_item' AND (i.expires_at IS NULL OR i.expires_at > datetime('now'))
      WHERE (s.is_active = 1 OR i.id IS NOT NULL) ${category ? 'AND s.category = ?' : ''}
      ORDER BY s.sort_order ASC, s.created_at DESC, s.rowid DESC
    `, category ? [userId, category] : [userId]);
    const u = userId ? await get('SELECT store_equipped FROM users WHERE id = ?', [userId]) : null;
    res.json({
      items: rows.map(r => ({ id: r.id, category: r.category, name: r.name, image_url: r.image_url, price: r.price, duration_days: r.duration_days || 0, badge: r.badge || '', owned: !!r.owned, expires_at: r.expires_at || null })),
      equipped: parseEquipped(u && u.store_equipped)
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/store-items/:id/buy', async (req, res) => {
  const userId = req.headers['x-user-id'];
  if (!userId) return res.status(401).json({ error: 'سجّل الدخول أولاً' });
  try {
    const item = await get('SELECT * FROM store_items WHERE id = ? AND is_active = 1', [req.params.id]);
    if (!item) return res.status(404).json({ error: 'هذا العنصر غير متاح للشراء' });
    const user = await get('SELECT id FROM users WHERE id = ?', [userId]);
    if (!user) return res.status(404).json({ error: 'المستخدم غير موجود' });
    const bought = await buyInventoryItem(userId, 'store_item', item, 'هذا العنصر');
    if (!bought.ok) return res.status(bought.status).json({ error: bought.error });
    const updatedUser = await get('SELECT * FROM users WHERE id = ?', [userId]);
    res.json({ success: true, user: updatedUser });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// تفعيل عنصر يملكه المستخدم (أو إلغاء التفعيل بإرسال itemId فارغ مع category)
app.post('/api/store-items/equip', async (req, res) => {
  const userId = req.headers['x-user-id'];
  if (!userId) return res.status(401).json({ error: 'سجّل الدخول أولاً' });
  try {
    const itemId = req.body && req.body.itemId ? String(req.body.itemId) : '';
    let category = req.body && req.body.category ? String(req.body.category) : '';
    if (itemId) {
      const row = await get(`
        SELECT s.id, s.category FROM store_items s
        JOIN user_inventory i ON i.item_id = s.id AND i.user_id = ? AND i.item_type = 'store_item' AND (i.expires_at IS NULL OR i.expires_at > datetime('now'))
        WHERE s.id = ?`, [userId, itemId]);
      if (!row) return res.status(403).json({ error: 'لا تملك هذا العنصر، اشتريه أولاً بالكرستالات' });
      category = row.category;
    }
    if (!STORE_CATEGORIES[category]) return res.status(400).json({ error: 'قسم غير معروف' });
    const u = await get('SELECT store_equipped FROM users WHERE id = ?', [userId]);
    const eq = parseEquipped(u && u.store_equipped);
    if (itemId) eq[category] = itemId; else delete eq[category];
    await run('UPDATE users SET store_equipped = ? WHERE id = ?', [JSON.stringify(eq), userId]);
    // تفعيل فقاعة دردشة من المتجر يلغي إطار الرسالة الافتراضي (واحد فقط مفعّل)
    if (itemId && category === 'chatbubble') {
      await run(`UPDATE users SET chat_frame = '' WHERE id = ?`, [userId]);
      pushUserAccessories(userId);
    }
    const updatedUser = await get('SELECT * FROM users WHERE id = ?', [userId]);
    // تغيير مقعد المايك يُبثّ فوراً لمن في غرف هذا المستخدم (يغيّر شكل مقاعد غرفته فقط)
    if (category === 'mic') {
      try {
        const micUrl = await getEquippedMicSeatUrl(userId);
        const myRooms = await all('SELECT id FROM rooms WHERE host_id = ?', [userId]);
        for (const r of myRooms) io.to(`room:${r.id}`).emit('room_seat_skin_updated', { roomId: r.id, mic_seat: micUrl });
      } catch (e) { console.error('seat skin broadcast error:', e.message); }
    }
    // بطاقة الصوت: تُبثّ فوراً للجميع ليحدّثوا ما يظهر على مقعد هذا المستخدم عند كلامه
    if (category === 'idcard') {
      try {
        const cardUrl = await getEquippedVoiceCardUrl(userId);
        io.emit('voice_card_updated', { userId: String(userId), url: cardUrl });
      } catch (e) { console.error('voice card broadcast error:', e.message); }
    }
    res.json({ success: true, user: updatedUser, equipped: eq });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// بطاقة الصوت المفعّلة لمستخدم (يستعلم عنها من في الغرفة لعرضها على مقعد المتحدث)
app.get('/api/users/:id/voice-card', async (req, res) => {
  try {
    res.json({ url: await getEquippedVoiceCardUrl(req.params.id) });
  } catch (e) { res.json({ url: '' }); }
});

// ---- إدارة عناصر المتجر من لوحة الإدارة ----
app.get('/api/admin/store-items', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const rows = await all(`
      SELECT s.*, (SELECT COUNT(*) FROM user_inventory i WHERE i.item_type = 'store_item' AND i.item_id = s.id) AS owners_count
      FROM store_items s WHERE s.vip_only = 0 ORDER BY s.category ASC, s.sort_order ASC, s.created_at DESC, s.rowid DESC
    `);
    res.json({ items: rows, categories: STORE_CATEGORIES });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/admin/store-items', adminStoreImageUpload, async (req, res) => {
  const drop = () => { if (req.file) safeDeleteStoreImage(`/uploads/${req.file.filename}`); };
  try {
    const category = String(req.body.category || '');
    const name = String(req.body.name || '').trim();
    const price = parseInt(req.body.price, 10);
    if (!STORE_CATEGORIES[category]) { drop(); return res.status(400).json({ error: 'يرجى اختيار القسم' }); }
    if (!name) { drop(); return res.status(400).json({ error: 'يرجى كتابة اسم العنصر' }); }
    if (!Number.isFinite(price) || price < 0) { drop(); return res.status(400).json({ error: 'يرجى إدخال سعر صحيح بالكرستالات' }); }
    if (!req.file) return res.status(400).json({ error: 'يرجى اختيار صورة أو ملف HTML للعنصر' });
    const id = `si-${uuidv4().slice(0, 8)}`;
    const sort = parseInt(req.body.sort_order, 10);
    const vipOnly = String(req.body.vip_only) === '1';   // رفع من قسم مزايا VIP: مخفي عن المتجر
    await run('INSERT INTO store_items (id, category, name, image_url, price, duration_days, badge, sort_order, is_active, vip_only) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [id, category, name, `/uploads/${req.file.filename}`, vipOnly ? 0 : price, PERMANENT_STORE_CATS.includes(category) ? 0 : parseDuration(req.body.duration_days, 0),
       String(req.body.badge || '').trim().slice(0, 20), Number.isFinite(sort) ? sort : 0, vipOnly ? 0 : 1, vipOnly ? 1 : 0]);
    res.json({ success: true, id });
  } catch (err) {
    drop();
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/admin/store-items/:id', adminStoreImageUpload, async (req, res) => {
  const drop = () => { if (req.file) safeDeleteStoreImage(`/uploads/${req.file.filename}`); };
  try {
    const item = await get('SELECT * FROM store_items WHERE id = ?', [req.params.id]);
    if (!item) { drop(); return res.status(404).json({ error: 'العنصر غير موجود' }); }
    const b = req.body || {};
    const name = b.name !== undefined ? String(b.name).trim() : item.name;
    const price = b.price !== undefined ? parseInt(b.price, 10) : item.price;
    const category = b.category !== undefined ? String(b.category) : item.category;
    const isActive = b.is_active !== undefined ? ((String(b.is_active) === '1' || b.is_active === 'true') ? 1 : 0) : item.is_active;
    const badge = b.badge !== undefined ? String(b.badge).trim().slice(0, 20) : item.badge;
    const sortN = b.sort_order !== undefined ? parseInt(b.sort_order, 10) : item.sort_order;
    if (!name || !Number.isFinite(price) || price < 0 || !STORE_CATEGORIES[category]) { drop(); return res.status(400).json({ error: 'يرجى التأكد من القسم والاسم والسعر' }); }
    let imageUrl = item.image_url;
    if (req.file) { imageUrl = `/uploads/${req.file.filename}`; safeDeleteStoreImage(item.image_url); }
    await run('UPDATE store_items SET category = ?, name = ?, price = ?, is_active = ?, image_url = ?, duration_days = ?, badge = ?, sort_order = ? WHERE id = ?',
      [category, name, price, isActive, imageUrl,
       PERMANENT_STORE_CATS.includes(category) ? 0 : (b.duration_days !== undefined ? parseDuration(b.duration_days, 0) : (item.duration_days || 0)),
       badge, Number.isFinite(sortN) ? sortN : 0, item.id]);
    await run(`UPDATE user_inventory SET item_name = ? WHERE item_type = 'store_item' AND item_id = ?`, [name, item.id]);
    res.json({ success: true });
  } catch (err) {
    drop();
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/admin/store-items/:id', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const item = await get('SELECT * FROM store_items WHERE id = ?', [req.params.id]);
    if (!item) return res.status(404).json({ error: 'العنصر غير موجود' });
    await run(`DELETE FROM user_inventory WHERE item_type = 'store_item' AND item_id = ?`, [item.id]);
    await unequipStoreItemEverywhere(null, item.id);
    await run('DELETE FROM store_items WHERE id = ?', [item.id]);
    safeDeleteStoreImage(item.image_url);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ===================== إدارة الهدايا من لوحة الإدارة =====================
function safeDeleteGiftImage(imageUrl) {
  try {
    if (!imageUrl || !imageUrl.startsWith('/uploads/gift-')) return;
    const uploadsDir = path.join(__dirname, 'public', 'uploads');
    const full = path.join(__dirname, 'public', imageUrl);
    if (path.dirname(full) === uploadsDir && fs.existsSync(full)) fs.unlinkSync(full);
  } catch (e) { console.error('delete gift image error:', e.message); }
}

const giftImageUpload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      const uploadDir = path.join(__dirname, 'public', 'uploads');
      if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });
      cb(null, uploadDir);
    },
    filename: (req, file, cb) => cb(null, `gift-${Date.now()}-${uuidv4().slice(0, 8)}${file.fieldname === 'effect' ? (isEntryHtmlFile(file) ? '.html' : (ENTRY_MEDIA_EXT[file.mimetype] || '.png')) : (ENTRY_IMAGE_EXT[file.mimetype] || '.png')}`)
  }),
  limits: { fileSize: ADMIN_IMAGE_MAX_BYTES },
  fileFilter: (req, file, cb) => {
    // مؤثر الهدية يقبل أيضاً MP4/WEBM/MOV وHTML (مثل قوالب الدخول)
    if (file.fieldname === 'effect' && (ENTRY_MEDIA_EXT[file.mimetype] || isEntryHtmlFile(file))) return cb(null, true);
    if (ENTRY_IMAGE_EXT[file.mimetype]) cb(null, true);
    else cb(new Error('يُسمح فقط بصور PNG أو JPG أو GIF أو WEBP (ومؤثر الهدية يقبل MP4 وHTML أيضاً)'));
  }
});

async function adminGiftImageUpload(req, res, next) {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  giftImageUpload.fields([{ name: 'image', maxCount: 1 }, { name: 'frame', maxCount: 1 }, { name: 'effect', maxCount: 1 }])(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.code === 'LIMIT_FILE_SIZE' ? `حجم الصورة أكبر من ${ADMIN_IMAGE_MAX_MB}MB` : err.message });
    req.file = (req.files && req.files.image && req.files.image[0]) || undefined;
    req.frameFile = (req.files && req.files.frame && req.files.frame[0]) || undefined;
    req.effectFile = (req.files && req.files.effect && req.files.effect[0]) || undefined;
    next();
  });
}

const adminFlag = (v) => (String(v) === '1' || String(v) === 'true') ? 1 : 0;
const adminBurstCount = (v, def) => {
  const n = parseInt(v, 10);
  return Number.isFinite(n) ? Math.min(60, Math.max(1, n)) : def;
};

app.get('/api/admin/gifts', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const rows = await all(`
      SELECT g.*, (SELECT COUNT(*) FROM gifts_history h WHERE h.gift_id = g.id) AS sent_count
      FROM gifts_catalog g ORDER BY g.sort_order ASC, g.rowid ASC
    `);
    res.json({ gifts: rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/admin/gifts', adminGiftImageUpload, async (req, res) => {
  try {
    const drop = () => {
      if (req.file) safeDeleteGiftImage(`/uploads/${req.file.filename}`);
      if (req.frameFile) safeDeleteGiftImage(`/uploads/${req.frameFile.filename}`);
      if (req.effectFile) safeDeleteGiftImage(`/uploads/${req.effectFile.filename}`);
    };
    const name = String(req.body.name || '').trim();
    const cost = parseInt(req.body.cost, 10);
    const currency = req.body.currency === 'diamonds' ? 'diamonds' : 'coins';
    const tab = GIFT_TAB_IDS.includes(req.body.tab) ? req.body.tab : 'normal';
    const icon = String(req.body.icon || '').trim().slice(0, 8) || '🎁';
    const luxury = tab === 'luxury' ? 1 : 0;
    if (!name) { drop(); return res.status(400).json({ error: 'يرجى كتابة اسم الهدية' }); }
    if (!Number.isFinite(cost) || cost < 0) { drop(); return res.status(400).json({ error: 'يرجى إدخال سعر صحيح' }); }
    if (!req.file && !String(req.body.icon || '').trim()) { drop(); return res.status(400).json({ error: 'ارفع صورة للهدية أو اكتب إيموجي' }); }

    const maxRow = await get('SELECT COALESCE(MAX(sort_order), 0) AS m FROM gifts_catalog');
    const id = `cg-${uuidv4().slice(0, 8)}`;
    await run(`INSERT INTO gifts_catalog (id, name, name_en, icon, image_url, cost, currency, charm, luxury, tab, sort_order, is_active,
                                          burst_enabled, burst_count, burst_image_url, banner_enabled, banner_frame_url, effect_url)
               VALUES (?, ?, '', ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?)`,
      [id, name, icon, req.file ? `/uploads/${req.file.filename}` : '', cost, currency, cost, luxury, tab, (maxRow ? maxRow.m : 0) + 1,
       adminFlag(req.body.burst_enabled), adminBurstCount(req.body.burst_count, 20),
       '', adminFlag(req.body.banner_enabled), req.frameFile ? `/uploads/${req.frameFile.filename}` : '', req.effectFile ? `/uploads/${req.effectFile.filename}` : '']);
    io.emit('gifts_catalog_updated', { at: Date.now() });
    res.json({ success: true, id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/admin/gifts/:id', adminGiftImageUpload, async (req, res) => {
  try {
    const g = await get('SELECT * FROM gifts_catalog WHERE id = ?', [req.params.id]);
    const drop = () => {
      if (req.file) safeDeleteGiftImage(`/uploads/${req.file.filename}`);
      if (req.frameFile) safeDeleteGiftImage(`/uploads/${req.frameFile.filename}`);
      if (req.effectFile) safeDeleteGiftImage(`/uploads/${req.effectFile.filename}`);
    };
    if (!g) { drop(); return res.status(404).json({ error: 'الهدية غير موجودة' }); }

    const name = req.body.name !== undefined ? String(req.body.name).trim() : g.name;
    const cost = req.body.cost !== undefined ? parseInt(req.body.cost, 10) : g.cost;
    const currency = req.body.currency !== undefined ? (req.body.currency === 'diamonds' ? 'diamonds' : 'coins') : g.currency;
    const tab = req.body.tab !== undefined ? (GIFT_TAB_IDS.includes(req.body.tab) ? req.body.tab : (g.luxury ? 'luxury' : 'normal')) : (g.luxury ? 'luxury' : 'normal');
    const icon = req.body.icon !== undefined ? (String(req.body.icon).trim().slice(0, 8) || '🎁') : g.icon;
    const luxury = tab === 'luxury' ? 1 : 0;
    const isActive = req.body.is_active !== undefined ? (String(req.body.is_active) === '1' || req.body.is_active === 'true' ? 1 : 0) : g.is_active;
    if (!name || !Number.isFinite(cost) || cost < 0) { drop(); return res.status(400).json({ error: 'يرجى التأكد من الاسم والسعر' }); }

    let imageUrl = g.image_url || '';
    if (req.file) {
      // نبقي الصورة القديمة إن كانت مستخدمة في خزائن هدايا المستخدمين
      const used = imageUrl ? await get('SELECT COUNT(*) AS n FROM gifts_history WHERE gift_icon = ?', [imageUrl]) : null;
      if (!used || !used.n) safeDeleteGiftImage(imageUrl);
      imageUrl = `/uploads/${req.file.filename}`;
    }
    const burstEnabled = req.body.burst_enabled !== undefined ? adminFlag(req.body.burst_enabled) : (g.burst_enabled ? 1 : 0);
    const burstCount = req.body.burst_count !== undefined ? adminBurstCount(req.body.burst_count, g.burst_count || 20) : (g.burst_count || 20);
    const bannerEnabled = req.body.banner_enabled !== undefined ? adminFlag(req.body.banner_enabled) : (g.banner_enabled ? 1 : 0);
    const burstImageUrl = '';
    let frameUrl = g.banner_frame_url || '';
    if (req.frameFile) { safeDeleteGiftImage(frameUrl); frameUrl = `/uploads/${req.frameFile.filename}`; }
    else if (String(req.body.remove_frame) === '1') { safeDeleteGiftImage(frameUrl); frameUrl = ''; }
    let effectUrl = g.effect_url || '';
    if (req.effectFile) { safeDeleteGiftImage(effectUrl); effectUrl = `/uploads/${req.effectFile.filename}`; }
    else if (String(req.body.remove_effect) === '1') { safeDeleteGiftImage(effectUrl); effectUrl = ''; }
    await run(`UPDATE gifts_catalog SET name = ?, icon = ?, image_url = ?, cost = ?, currency = ?, charm = ?, luxury = ?, tab = ?, is_active = ?,
                      burst_enabled = ?, burst_count = ?, burst_image_url = ?, banner_enabled = ?, banner_frame_url = ?, effect_url = ? WHERE id = ?`,
      [name, icon, imageUrl, cost, currency, cost, luxury, tab, isActive, burstEnabled, burstCount, burstImageUrl, bannerEnabled, frameUrl, effectUrl, g.id]);
    io.emit('gifts_catalog_updated', { at: Date.now() });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/admin/gifts/:id', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const g = await get('SELECT * FROM gifts_catalog WHERE id = ?', [req.params.id]);
    if (!g) return res.status(404).json({ error: 'الهدية غير موجودة' });
    await run('DELETE FROM gifts_catalog WHERE id = ?', [g.id]);
    safeDeleteGiftImage(g.banner_frame_url);
    safeDeleteGiftImage(g.effect_url);
    if (g.image_url) {
      const used = await get('SELECT COUNT(*) AS n FROM gifts_history WHERE gift_icon = ?', [g.image_url]);
      if (!used || !used.n) safeDeleteGiftImage(g.image_url);
    }
    io.emit('gifts_catalog_updated', { at: Date.now() });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ===================== إيموجي الغرفة (تُرفع من الإدارة) =====================
function safeDeleteEmojiImage(imageUrl) {
  try {
    if (!imageUrl || !imageUrl.startsWith('/uploads/emoji-')) return;
    const uploadsDir = path.join(__dirname, 'public', 'uploads');
    const full = path.join(__dirname, 'public', imageUrl);
    if (path.dirname(full) === uploadsDir && fs.existsSync(full)) fs.unlinkSync(full);
  } catch (e) { console.error('delete emoji image error:', e.message); }
}

const emojiImageUpload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      const uploadDir = path.join(__dirname, 'public', 'uploads');
      if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });
      cb(null, uploadDir);
    },
    filename: (req, file, cb) => cb(null, `emoji-${Date.now()}-${uuidv4().slice(0, 8)}${ENTRY_IMAGE_EXT[file.mimetype] || '.png'}`)
  }),
  limits: { fileSize: ADMIN_IMAGE_MAX_BYTES },
  fileFilter: (req, file, cb) => {
    if (ENTRY_IMAGE_EXT[file.mimetype]) cb(null, true);
    else cb(new Error('يُسمح فقط بصور PNG أو JPG أو GIF أو WEBP'));
  }
});

async function adminEmojiImageUpload(req, res, next) {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  emojiImageUpload.single('image')(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.code === 'LIMIT_FILE_SIZE' ? `حجم الصورة أكبر من ${ADMIN_IMAGE_MAX_MB}MB` : err.message });
    next();
  });
}

// رفع عدّة صور دفعة واحدة (الحقل: images) — مع دعم الحقل القديم image
async function adminEmojiImagesUpload(req, res, next) {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  emojiImageUpload.fields([{ name: 'images', maxCount: 100 }, { name: 'image', maxCount: 1 }])(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.code === 'LIMIT_FILE_SIZE' ? `حجم إحدى الصور أكبر من ${ADMIN_IMAGE_MAX_MB}MB` : (err.code === 'LIMIT_UNEXPECTED_FILE' ? 'الحد الأقصى 100 صورة في الدفعة' : err.message) });
    next();
  });
}

// القائمة التي تظهر للمستخدمين داخل الغرفة
app.get('/api/room-emojis', async (req, res) => {
  try {
    const rows = await all('SELECT id, name, image_url FROM room_emojis WHERE is_active = 1 ORDER BY sort_order ASC, rowid ASC');
    res.json({ emojis: rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/admin/room-emojis', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const rows = await all('SELECT * FROM room_emojis ORDER BY sort_order ASC, rowid ASC');
    res.json({ emojis: rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/admin/room-emojis', adminEmojiImagesUpload, async (req, res) => {
  try {
    const files = [].concat((req.files && req.files.images) || [], (req.files && req.files.image) || []);
    if (!files.length) return res.status(400).json({ error: 'يرجى اختيار صورة الإيموجي' });
    const maxRow = await get('SELECT COALESCE(MAX(sort_order), 0) AS m FROM room_emojis');
    let order = maxRow ? maxRow.m : 0;
    const ids = [];
    for (const f of files) {
      const id = `em-${uuidv4().slice(0, 8)}`;
      order += 1;
      await run('INSERT INTO room_emojis (id, name, image_url, sort_order, is_active) VALUES (?, ?, ?, ?, 1)',
        [id, '', `/uploads/${f.filename}`, order]);
      ids.push(id);
    }
    res.json({ success: true, id: ids[0], ids, count: ids.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/admin/room-emojis/:id', adminEmojiImageUpload, async (req, res) => {
  try {
    const em = await get('SELECT * FROM room_emojis WHERE id = ?', [req.params.id]);
    const drop = () => { if (req.file) safeDeleteEmojiImage(`/uploads/${req.file.filename}`); };
    if (!em) { drop(); return res.status(404).json({ error: 'الإيموجي غير موجود' }); }
    const isActive = req.body.is_active !== undefined ? (String(req.body.is_active) === '1' || req.body.is_active === 'true' ? 1 : 0) : em.is_active;
    let imageUrl = em.image_url;
    if (req.file) {
      // الرسائل القديمة في الدردشة قد تشير للصورة القديمة، لذلك لا نحذفها إن كانت مستخدمة
      const used = await get(`SELECT COUNT(*) AS n FROM messages WHERE message_type = 'emoji' AND content = ?`, [imageUrl]);
      if (!used || !used.n) safeDeleteEmojiImage(imageUrl);
      imageUrl = `/uploads/${req.file.filename}`;
    }
    await run('UPDATE room_emojis SET image_url = ?, is_active = ? WHERE id = ?', [imageUrl, isActive, em.id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/admin/room-emojis/:id', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const em = await get('SELECT * FROM room_emojis WHERE id = ?', [req.params.id]);
    if (!em) return res.status(404).json({ error: 'الإيموجي غير موجود' });
    await run('DELETE FROM room_emojis WHERE id = ?', [em.id]);
    const used = await get(`SELECT COUNT(*) AS n FROM messages WHERE message_type = 'emoji' AND content = ?`, [em.image_url]);
    if (!used || !used.n) safeDeleteEmojiImage(em.image_url);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 3b. Upload and Update User Avatar
app.post('/api/users/avatar', upload.single('avatar'), async (req, res) => {
  try {
    const userId = req.headers['x-user-id'] || req.body.userId;
    if (!userId) return res.status(401).json({ error: 'Unauthorized: User ID required' });

    let avatarUrl = null;
    if (req.file) {
      avatarUrl = `/uploads/${req.file.filename}`;
    } else if (req.body.avatar_url) {
      avatarUrl = req.body.avatar_url;
    } else {
      return res.status(400).json({ error: 'لم يتم تحديد أي صورة شخصية' });
    }

    await run('UPDATE users SET avatar = ? WHERE id = ?', [avatarUrl, userId]);
    const updatedUser = await get('SELECT * FROM users WHERE id = ?', [userId]);

    // Broadcast avatar update to all online clients and room occupants
    io.emit('user_avatar_changed', { userId, avatar: avatarUrl });

    res.json({
      success: true,
      avatar: avatarUrl,
      user: updatedUser,
      message: 'تم تحديث صورتك الشخصية بنجاح! 📸✨'
    });
  } catch (err) {
    console.error('Avatar update error:', err);
    res.status(500).json({ error: err.message });
  }
});

// 4. Daily Check-in (+500 coins)
app.post('/api/users/checkin', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    if (!userId) return res.status(401).json({ error: 'Unauthorized' });

    const user = await get('SELECT * FROM users WHERE id = ?', [userId]);
    if (!user) return res.status(404).json({ error: 'User not found' });

    // المكافأة كل 24 ساعة من وقت الاستلام (وليس بتغيّر اليوم)
    const wallet = await getWalletSettings();
    if (!wallet.daily_bonus_enabled) {
      return res.json({ success: false, message: 'المكافأة اليومية متوقفة حالياً من الإدارة' });
    }
    const DAY_MS = 24 * 60 * 60 * 1000;
    const lastClaim = user.last_checkin ? Date.parse(user.last_checkin) : NaN;
    if (Number.isFinite(lastClaim) && Date.now() - lastClaim < DAY_MS) {
      const hoursLeft = Math.ceil((DAY_MS - (Date.now() - lastClaim)) / (60 * 60 * 1000));
      return res.json({ success: false, message: `لقد استلمت مكافأتك بالفعل! عُد بعد ${hoursLeft} ساعة للحصول على مكافأة جديدة 🎁` });
    }
    const today = new Date().toISOString(); // وقت الاستلام الدقيق

    // دورة حضور من 7 أيام: تبدأ من أول استلام، وتُعاد بعد انتهائها
    const CYCLE_MS = 7 * DAY_MS;
    const cycleStartMs = user.checkin_cycle_start ? Date.parse(user.checkin_cycle_start) : NaN;
    let streak = parseInt(user.checkin_streak, 10) || 0;
    let cycleStart = user.checkin_cycle_start;
    if (!Number.isFinite(cycleStartMs) || Date.now() >= cycleStartMs + CYCLE_MS || streak >= 7) {
      streak = 0;
      cycleStart = today;
    }
    streak += 1;

    // اليوم السابع بمكافأة مضاعفة + مكافآت تراكمية (الألماس) عند اليوم 5 و7
    const CUMULATIVE = { 5: 10, 7: 20 };
    const mult = streak === 7 ? 2 : 1;
    const bonusCoins = wallet.daily_bonus_coins * mult;
    const bonusDiamonds = wallet.daily_bonus_diamonds * mult + (CUMULATIVE[streak] || 0);

    await run(`
      UPDATE users SET
        coins = coins + ?,
        diamonds = diamonds + ?,
        last_checkin = ?,
        checkin_streak = ?,
        checkin_cycle_start = ?
      WHERE id = ?
    `, [bonusCoins, bonusDiamonds, today, streak, cycleStart, userId]);

    const updatedUser = await get('SELECT * FROM users WHERE id = ?', [userId]);
    res.json({
      success: true,
      message: `مبروك! حصلت على ${bonusCoins} عملة سول و ${bonusDiamonds} ألماسة! 💎🪙`,
      user: updatedUser
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 5. Soul Test Submission
app.post('/api/users/soul-test', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    if (!userId) return res.status(401).json({ error: 'Unauthorized' });

    const { answers } = req.body; // array of answers
    const planetTypes = [
      { name: 'كوكب الرومانسي الحالم 🌌', score: 96, tags: 'شعر,موسيقى,هدوء,عاطفة' },
      { name: 'كوكب المغامر الشغوف 🚀', score: 92, tags: 'سفر,استكشاف,طاقة,حماس' },
      { name: 'كوكب الفيلسوف الحكيم 🔮', score: 94, tags: 'تأمل,قراءة,فلك,عمق' },
      { name: 'كوكب الفنان الملهم 🎨', score: 89, tags: 'رسم,إبداع,جمال,تصميم' },
      { name: 'كوكب المحارب الرقمي ⚡', score: 91, tags: 'ألعاب,تحدي,ستريم,سرعة' }
    ];

    const chosen = planetTypes[Math.floor(Math.random() * planetTypes.length)];

    await run(`
      UPDATE users SET
        soul_planet = ?,
        soul_score = ?,
        soul_tags = ?
      WHERE id = ?
    `, [chosen.name, chosen.score, chosen.tags, userId]);

    const updatedUser = await get('SELECT * FROM users WHERE id = ?', [userId]);
    res.json({
      success: true,
      planet: chosen.name,
      score: chosen.score,
      tags: chosen.tags,
      user: updatedUser
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// حالة التوافق الصوتي (المحاولات المتبقية من 3 كل 24 ساعة)
app.get('/api/voice-match/status', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    if (!userId) return res.status(401).json({ error: 'Unauthorized' });
    const used = await getVoiceMatchUsageCount(userId);
    const row = await get(`SELECT MAX(created_at) AS last_used FROM voice_match_usage WHERE user_id = ?`, [userId]);
    const vmLimit = await getVoiceMatchLimit(userId);
    res.json({
      limit: vmLimit,
      used,
      remaining: Math.max(0, vmLimit - used),
      last_used: row ? row.last_used : null
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 6. Recharge / Top-up simulated
app.post(['/api/users/recharge', '/api/wallet/recharge'], async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    if (!userId) return res.status(401).json({ error: 'Unauthorized' });

    const wallet = await getWalletSettings();
    if (!wallet.user_recharge_enabled) {
      return res.status(403).json({ success: false, message: 'الشحن يتم عن طريق الإدارة فقط' });
    }

    const { amountCoins, amountDiamonds, coins, diamonds } = req.body;
    const addCoins = Number(amountCoins ?? coins ?? 0);
    const addDiamonds = Number(amountDiamonds ?? diamonds ?? 0);
    await run(`
      UPDATE users SET
        coins = coins + ?,
        diamonds = diamonds + ?
      WHERE id = ?
    `, [addCoins, addDiamonds, userId]);

    // الشحن يضيف نقاط الثروة حسب الكريستالات المضافة (والمستوى كنوع من الشراء)
    if (addDiamonds > 0) {
      try {
        const ps = await getPointSettings();
        const pts = memberLevels.pointsForAmount(addDiamonds, 'diamonds', ps);
        await addMemberPoints(userId, 'wealth', pts);
        await addLevelPoints(userId, pts);
        notifyMemberStats(userId);
      } catch (e) {}
    }

    const updated = await get('SELECT * FROM users WHERE id = ?', [userId]);
    res.json({ success: true, user: updated });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ==========================================
// بوابة دفع PayPal الحقيقية (Orders v2) — الدفع بالبطاقة (Visa/Master/Amex) بدون حساب PayPal للمشتري
// - مفاتيح PayPal تضعها الإدارة من لوحة التحكم (تبويب المحفظة) وتُحفظ في app_settings
// - الأسعار والكميات تُحدَّد في الخادم فقط (لا يُصدَّق أي سعر قادم من المتصفح)
// - الرصيد يُشحن بعد أن يؤكد الخادم نفسه مع PayPal أن العملية COMPLETED وأن المبلغ والعملة مطابقان، ومرة واحدة فقط لكل طلب
// ==========================================
const DEFAULT_CRYSTAL_PACKS = [
  { id: 'p1', crystals: 504,   base: 84,   bonus: 420,   price: '0.99' },
  { id: 'p2', crystals: 2561,  base: 461,  bonus: 2100,  price: '4.99' },
  { id: 'p3', crystals: 5162,  base: 962,  bonus: 4200,  price: '9.99' },
  { id: 'p4', crystals: 15526, base: 2926, bonus: 12600, price: '29.99' },
  { id: 'p5', crystals: 25910, base: 4310, bonus: 21600, price: '49.99' }
];
// الباقات تُدار من لوحة الإدارة (تُحفظ في app_settings) وتتحدث عند المستخدمين مباشرة
async function getCrystalPacks() {
  try {
    const row = await get(`SELECT value FROM app_settings WHERE key = 'crystal_packs'`);
    if (row && row.value) {
      const arr = JSON.parse(row.value);
      if (Array.isArray(arr) && arr.length) return arr;
    }
  } catch (e) {}
  return DEFAULT_CRYSTAL_PACKS;
}
function cleanPacks(input) {
  const arr = Array.isArray(input) ? input.slice(0, 12) : [];
  const out = [];
  for (const p of arr) {
    const base = Math.floor(Number(p.base)), bonus = Math.floor(Number(p.bonus || 0));
    const price = Number(p.price);
    if (!(base > 0) || !(bonus >= 0) || !(price > 0) || price > 100000) continue;
    out.push({ id: 'p' + (out.length + 1), crystals: base + bonus, base, bonus, price: price.toFixed(2) });
  }
  return out;
}
app.get('/api/wallet/packs', async (req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json({ success: true, packs: await getCrystalPacks() });
});
app.get('/api/admin/crystal-packs', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  res.json({ success: true, packs: await getCrystalPacks() });
});
app.post('/api/admin/crystal-packs', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const packs = cleanPacks((req.body || {}).packs);
    if (!packs.length) return res.status(400).json({ success: false, message: 'أضف باقة واحدة صحيحة على الأقل' });
    await run(`INSERT INTO app_settings (key, value) VALUES ('crystal_packs', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value`, [JSON.stringify(packs)]);
    io.emit('wallet_packs_updated', { at: Date.now() });
    res.json({ success: true, packs });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
const PAYPAL_KEYS = ['paypal_enabled', 'paypal_mode', 'paypal_client_id', 'paypal_client_secret', 'paypal_currency'];

async function getPaypalSettings() {
  const rows = await all(`SELECT key, value FROM app_settings WHERE key IN (${PAYPAL_KEYS.map(() => '?').join(',')})`, PAYPAL_KEYS);
  const m = {};
  rows.forEach(r => { m[r.key] = r.value; });
  return {
    enabled: m.paypal_enabled !== '0', // مفعّلة افتراضياً بمجرد حفظ المفاتيح، وتتعطل فقط إذا أُلغي التفعيل صراحةً
    mode: m.paypal_mode === 'live' ? 'live' : 'sandbox',
    clientId: String(m.paypal_client_id || '').trim(),
    clientSecret: String(m.paypal_client_secret || '').trim(),
    currency: /^[A-Z]{3}$/.test(m.paypal_currency || '') ? m.paypal_currency : 'USD'
  };
}
function paypalReady(cfg) { return !!(cfg.enabled && cfg.clientId && cfg.clientSecret); }
function paypalBase(cfg) { return cfg.mode === 'live' ? 'https://api-m.paypal.com' : 'https://api-m.sandbox.paypal.com'; }

let paypalTokenCache = { key: '', token: '', exp: 0 };
async function paypalAccessToken(cfg) {
  const key = `${cfg.mode}:${cfg.clientId}:${cfg.clientSecret.slice(-6)}`;
  if (paypalTokenCache.key === key && paypalTokenCache.exp > Date.now() + 30000) return paypalTokenCache.token;
  const r = await fetch(`${paypalBase(cfg)}/v1/oauth2/token`, {
    method: 'POST',
    headers: {
      Authorization: 'Basic ' + Buffer.from(`${cfg.clientId}:${cfg.clientSecret}`).toString('base64'),
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: 'grant_type=client_credentials',
    signal: AbortSignal.timeout(20000)
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok || !j.access_token) {
    const e = new Error(j.error_description || 'فشل التوثيق مع PayPal، تحقق من Client ID و Secret ومن وضع (Sandbox/Live)');
    e.paypal = j; throw e;
  }
  paypalTokenCache = { key, token: j.access_token, exp: Date.now() + (Number(j.expires_in) || 300) * 1000 };
  return j.access_token;
}
async function paypalApi(cfg, path, method, body, requestId) {
  const token = await paypalAccessToken(cfg);
  const headers = { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };
  if (requestId) headers['PayPal-Request-Id'] = requestId;
  const r = await fetch(`${paypalBase(cfg)}${path}`, {
    method, headers, body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(30000)
  });
  const j = await r.json().catch(() => ({}));
  return { ok: r.ok, status: r.status, data: j };
}

// إعدادات عامة يحتاجها المتصفح لعرض أزرار الدفع (لا تتضمن السر أبداً)
// بيانات الفوترة الحقيقية للمستخدم (الرمز البريدي والهاتف) لتعبئتها مسبقاً في نموذج الدفع
app.get('/api/paypal/billing', async (req, res) => {
  const userId = req.headers['x-user-id'];
  if (!userId) return res.status(401).json({ success: false });
  const u = await get('SELECT billing_postal, billing_phone FROM users WHERE id = ?', [userId]);
  if (!u) return res.status(404).json({ success: false });
  res.json({ success: true, postal: u.billing_postal || '', phone: u.billing_phone || '' });
});
app.post('/api/paypal/billing', async (req, res) => {
  const userId = req.headers['x-user-id'];
  if (!userId) return res.status(401).json({ success: false });
  const postal = String((req.body || {}).postal || '').trim().replace(/[^\w\s-]/g, '').slice(0, 20);
  const phone = String((req.body || {}).phone || '').replace(/\D/g, '').slice(0, 14);
  await run('UPDATE users SET billing_postal = ?, billing_phone = ? WHERE id = ?', [postal, phone, userId]);
  res.json({ success: true });
});

app.get('/api/paypal/config', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  try {
    const cfg = await getPaypalSettings();
    res.json({
      success: true,
      enabled: paypalReady(cfg),
      reason: paypalReady(cfg) ? null : (!cfg.enabled ? 'disabled' : 'missing_keys'),
      clientId: paypalReady(cfg) ? cfg.clientId : '',
      mode: cfg.mode,
      currency: cfg.currency,
      packs: await getCrystalPacks()
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// إنشاء طلب دفع (السعر من الخادم حسب الباقة)
app.post('/api/paypal/create-order', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    if (!userId) return res.status(401).json({ success: false, message: 'Unauthorized' });
    const user = await get('SELECT id, name, email, country_code, billing_postal, billing_phone FROM users WHERE id = ?', [userId]);
    if (!user) return res.status(404).json({ success: false, message: 'المستخدم غير موجود' });
    const cfg = await getPaypalSettings();
    if (!paypalReady(cfg)) return res.status(503).json({ success: false, message: 'بوابة الدفع غير مفعلة حالياً' });
    const pack = (await getCrystalPacks()).find(p => p.id === String((req.body || {}).packId));
    if (!pack) return res.status(400).json({ success: false, message: 'باقة غير صالحة' });

    // flow=card_fields: نموذج البطاقة المدمج → نطلب 3D Secure عند الحاجة فقط (SCA_WHEN_REQUIRED)
    const isCardFields = String((req.body || {}).flow) === 'card_fields';
    const orderBody = {
      intent: 'CAPTURE',
      purchase_units: [{
        reference_id: pack.id,
        custom_id: String(userId).slice(0, 120),
        description: `SoulChill ${pack.crystals} crystals`,
        amount: { currency_code: cfg.currency, value: pack.price }
      }]
    };
    if (isCardFields) {
      orderBody.payment_source = { card: { attributes: { verification: { method: 'SCA_WHEN_REQUIRED' } } } };
    } else {
      orderBody.application_context = { brand_name: 'SoulChill', shipping_preference: 'NO_SHIPPING', user_action: 'PAY_NOW' };
      // تعبئة مسبقة لنموذج PayPal: الاسم والبريد من حساب المستخدم، والدولة من موقعه (ترويسة CDN ثم لغة المتصفح)
      const hdrCountry = String(req.headers['cf-ipcountry'] || req.headers['x-vercel-ip-country'] || req.headers['x-appengine-country'] || req.headers['cloudfront-viewer-country'] || '').toUpperCase();
      const hintCountry = String((req.body || {}).country || '').toUpperCase();
      const country = [String(user.country_code || '').toUpperCase(), hdrCountry, hintCountry].find(c => /^[A-Z]{2}$/.test(c) && c !== 'XX' && c !== 'T1');
      const parts = String(user.name || '').replace(/[^\p{L}\s'.-]/gu, ' ').trim().split(/\s+/).filter(Boolean);
      const payer = {};
      if (parts.length) payer.name = { given_name: parts[0].slice(0, 100), surname: (parts.slice(1).join(' ') || parts[0]).slice(0, 100) };
      if (user.email && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(user.email)) payer.email_address = user.email;
      if (country) {
        payer.address = { country_code: country };
        if (user.billing_postal) payer.address.postal_code = String(user.billing_postal).slice(0, 20);
      }
      const phoneDigits = String(user.billing_phone || '').replace(/\D/g, '');
      if (phoneDigits.length >= 6 && phoneDigits.length <= 14) payer.phone = { phone_number: { national_number: phoneDigits } };
      if (Object.keys(payer).length) orderBody.payer = payer;
    }
    let r = await paypalApi(cfg, '/v2/checkout/orders', 'POST', orderBody, `soulchill-${uuidv4()}`);
    // إن رفضت PayPal بيانات التعبئة المسبقة نعيد المحاولة بدونها حتى لا يتعطل الدفع
    if ((!r.ok || !r.data.id) && orderBody.payer && !JSON.stringify(r.data).includes('PAYEE_ACCOUNT_RESTRICTED')) {
      delete orderBody.payer;
      r = await paypalApi(cfg, '/v2/checkout/orders', 'POST', orderBody, `soulchill-${uuidv4()}`);
    }
    if (!r.ok || !r.data.id) {
      console.error('PayPal create-order failed:', JSON.stringify(r.data));
      // حساب التاجر مقيَّد لدى PayPal: رسالة مفهومة للمستخدم، والتفاصيل في سجل الخادم
      if (JSON.stringify(r.data).includes('PAYEE_ACCOUNT_RESTRICTED')) {
        return res.status(503).json({ success: false, code: 'MERCHANT_RESTRICTED', message: 'الدفع بالبطاقة غير متاح مؤقتاً. يمكنك المحاولة لاحقاً أو الشحن عبر الدردشة.' });
      }
      return res.status(502).json({ success: false, message: 'تعذر إنشاء طلب الدفع، حاول مرة أخرى.' });
    }
    await run(`INSERT INTO paypal_orders (order_id, user_id, pack_id, amount, currency, crystals, status) VALUES (?, ?, ?, ?, ?, ?, 'CREATED')`,
      [r.data.id, userId, pack.id, pack.price, cfg.currency, pack.crystals]);
    res.json({ success: true, orderId: r.data.id });
  } catch (err) {
    console.error('paypal create-order error:', err);
    res.status(500).json({ success: false, message: 'خطأ في بوابة الدفع' });
  }
});

// تأكيد الدفع وشحن الكريستال (مرة واحدة فقط لكل طلب)
app.post('/api/paypal/capture-order', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    if (!userId) return res.status(401).json({ success: false, message: 'Unauthorized' });
    const orderId = String((req.body || {}).orderId || '');
    const row = orderId ? await get('SELECT * FROM paypal_orders WHERE order_id = ? AND user_id = ?', [orderId, userId]) : null;
    if (!row) return res.status(404).json({ success: false, message: 'طلب الدفع غير موجود' });

    const respondUser = async (extra = {}) => {
      const user = await get('SELECT * FROM users WHERE id = ?', [userId]);
      res.json({ success: true, user, crystals: row.crystals, ...extra });
    };
    if (row.status === 'COMPLETED') return respondUser({ already: true });

    const cfg = await getPaypalSettings();
    if (!paypalReady(cfg)) return res.status(503).json({ success: false, message: 'بوابة الدفع غير مفعلة حالياً' });

    let r = await paypalApi(cfg, `/v2/checkout/orders/${encodeURIComponent(orderId)}/capture`, 'POST', null, `soulchill-cap-${orderId}`);
    const alreadyCaptured = !r.ok && JSON.stringify(r.data).includes('ORDER_ALREADY_CAPTURED');
    if (alreadyCaptured) r = await paypalApi(cfg, `/v2/checkout/orders/${encodeURIComponent(orderId)}`, 'GET');
    if (!r.ok) {
      console.error('PayPal capture failed:', JSON.stringify(r.data));
      const declined = JSON.stringify(r.data).includes('INSTRUMENT_DECLINED');
      return res.status(402).json({ success: false, declined, message: declined ? 'تم رفض البطاقة، جرّب بطاقة أخرى' : 'تعذر إتمام الدفع' });
    }

    const pu = (r.data.purchase_units || [])[0] || {};
    const cap = ((pu.payments || {}).captures || [])[0] || {};
    const payerEmail = (r.data.payer && r.data.payer.email_address) || null;
    if (cap.status !== 'COMPLETED') {
      await run(`UPDATE paypal_orders SET status = ? WHERE order_id = ? AND status != 'COMPLETED'`, [String(cap.status || r.data.status || 'PENDING'), orderId]);
      return res.status(202).json({ success: false, pending: true, message: 'عملية الدفع قيد المراجعة لدى PayPal، سيُضاف الرصيد عند اكتمالها' });
    }
    // مطابقة المبلغ والعملة والمستخدم مع ما سجّله الخادم عند إنشاء الطلب
    const amt = cap.amount || {};
    // مع الدفع بنموذج البطاقة يضع PayPal custom_id داخل captures[0] وليس purchase_units[0]؛ والطلب مرتبط أصلاً بالمستخدم في قاعدة بياناتنا
    const capCustom = String(pu.custom_id || cap.custom_id || '');
    if (String(amt.value) !== String(row.amount) || amt.currency_code !== row.currency || (capCustom && capCustom !== String(userId))) {
      console.error('PayPal capture mismatch', { orderId, amt, expected: row.amount, custom: pu.custom_id });
      await run(`UPDATE paypal_orders SET status = 'MISMATCH' WHERE order_id = ?`, [orderId]);
      return res.status(409).json({ success: false, message: 'عدم تطابق في بيانات الدفع، تواصل مع الإدارة' });
    }

    // الشحن مرة واحدة: يفوز أول طلب يغيّر الحالة إلى COMPLETED
    const upd = await run(`UPDATE paypal_orders SET status = 'COMPLETED', capture_id = ?, payer_email = ?, completed_at = CURRENT_TIMESTAMP WHERE order_id = ? AND status != 'COMPLETED'`,
      [cap.id || null, payerEmail, orderId]);
    if (upd.changes === 1) {
      await run('UPDATE users SET diamonds = diamonds + ? WHERE id = ?', [row.crystals, userId]);
      // الشحن بالكريستالات يضيف نقاط الثروة (والمستوى كنوع من الشراء)
      try {
        const ps = await getPointSettings();
        const pts = memberLevels.pointsForAmount(row.crystals, 'diamonds', ps);
        await addMemberPoints(userId, 'wealth', pts);
        await addLevelPoints(userId, pts);
        notifyMemberStats(userId);
      } catch (e) {}
    }
    return respondUser({ already: upd.changes !== 1 });
  } catch (err) {
    console.error('paypal capture-order error:', err);
    res.status(500).json({ success: false, message: 'خطأ في بوابة الدفع' });
  }
});

// ===== إعدادات PayPal من لوحة الإدارة =====
app.get('/api/admin/settings/paypal', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const cfg = await getPaypalSettings();
    res.json({ success: true, settings: {
      enabled: cfg.enabled, mode: cfg.mode, client_id: cfg.clientId, currency: cfg.currency,
      client_secret_set: !!cfg.clientSecret, // السر لا يُرسل للمتصفح أبداً
      ready: paypalReady(cfg)
    }});
  } catch (err) { res.status(500).json({ error: err.message }); }
});
app.post('/api/admin/settings/paypal', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const b = req.body || {};
    const entries = {
      paypal_enabled: b.enabled ? '1' : '0',
      paypal_mode: b.mode === 'live' ? 'live' : 'sandbox',
      paypal_client_id: String(b.client_id || '').trim().slice(0, 200),
      paypal_currency: /^[A-Z]{3}$/.test(String(b.currency || '').toUpperCase()) ? String(b.currency).toUpperCase() : 'USD'
    };
    const secret = String(b.client_secret || '').trim();
    if (secret) entries.paypal_client_secret = secret.slice(0, 300); // فارغ = إبقاء السر الحالي
    for (const [k, v] of Object.entries(entries)) {
      await run(`INSERT INTO app_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value`, [k, v]);
    }
    paypalTokenCache = { key: '', token: '', exp: 0 };
    const cfg = await getPaypalSettings();
    if (cfg.enabled && !(cfg.clientId && cfg.clientSecret)) {
      return res.json({ success: true, warning: 'تم الحفظ لكن البوابة لن تعمل قبل إدخال Client ID و Secret' });
    }
    res.json({ success: true });
  } catch (err) { res.status(500).json({ error: err.message }); }
});
// اختبار الاتصال بـ PayPal بالمفاتيح المحفوظة
app.post('/api/admin/paypal/test', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const cfg = await getPaypalSettings();
    if (!cfg.clientId || !cfg.clientSecret) return res.json({ success: false, message: 'أدخل Client ID و Secret أولاً' });
    paypalTokenCache = { key: '', token: '', exp: 0 };
    await paypalAccessToken(cfg);
    res.json({ success: true, message: `نجح الاتصال بـ PayPal (${cfg.mode === 'live' ? 'Live' : 'Sandbox'}) ✅` + (cfg.enabled ? ' — البوابة مفعّلة' : ' — لكن البوابة معطّلة: فعّل الخيار واحفظ') });
  } catch (err) { res.json({ success: false, message: err.message }); }
});
// آخر عمليات الدفع
app.get('/api/admin/paypal/orders', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const rows = await all(`SELECT o.order_id, o.user_id, u.name AS user_name, o.crystals, o.amount, o.currency, o.status, o.payer_email, o.created_at, o.completed_at
      FROM paypal_orders o LEFT JOIN users u ON u.id = o.user_id ORDER BY o.created_at DESC LIMIT 50`);
    res.json({ success: true, orders: rows });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// تسوية طلب دُفع فعلاً لدى PayPal ولم يُشحن رصيده (مثلاً حالة MISMATCH): يتحقق من PayPal ثم يشحن مرة واحدة فقط
app.post('/api/admin/paypal/reconcile', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const orderId = String((req.body || {}).orderId || '');
    const row = orderId ? await get('SELECT * FROM paypal_orders WHERE order_id = ?', [orderId]) : null;
    if (!row) return res.status(404).json({ success: false, message: 'الطلب غير موجود' });
    if (row.status === 'COMPLETED') return res.json({ success: true, already: true, message: 'الطلب مشحون مسبقاً' });
    const cfg = await getPaypalSettings();
    const r = await paypalApi(cfg, `/v2/checkout/orders/${encodeURIComponent(orderId)}`, 'GET');
    if (!r.ok) return res.status(502).json({ success: false, message: 'تعذر جلب الطلب من PayPal' });
    const pu = (r.data.purchase_units || [])[0] || {};
    const cap = ((pu.payments || {}).captures || [])[0] || {};
    const amt = cap.amount || {};
    if (cap.status !== 'COMPLETED') return res.status(409).json({ success: false, message: 'الدفع غير مكتمل لدى PayPal: ' + (cap.status || r.data.status) });
    if (String(amt.value) !== String(row.amount) || amt.currency_code !== row.currency) return res.status(409).json({ success: false, message: 'المبلغ لا يطابق الطلب' });
    const upd = await run(`UPDATE paypal_orders SET status = 'COMPLETED', capture_id = ?, completed_at = CURRENT_TIMESTAMP WHERE order_id = ? AND status != 'COMPLETED'`, [cap.id || null, orderId]);
    if (upd.changes === 1) {
      await run('UPDATE users SET diamonds = diamonds + ? WHERE id = ?', [row.crystals, row.user_id]);
      try {
        const ps = await getPointSettings();
        const pts = memberLevels.pointsForAmount(row.crystals, 'diamonds', ps);
        await addMemberPoints(row.user_id, 'wealth', pts);
        await addLevelPoints(row.user_id, pts);
        notifyMemberStats(row.user_id);
      } catch (e) {}
    }
    res.json({ success: true, credited: upd.changes === 1, crystals: row.crystals, user_id: row.user_id });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});

// تبديل الكريستال (الألماس) إلى عملات الألعاب — 1 كريستال = 100 عملة
app.post('/api/wallet/exchange', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    if (!userId) return res.status(401).json({ error: 'Unauthorized' });
    const d = Math.floor(Number(req.body && req.body.diamonds));
    if (!Number.isFinite(d) || d <= 0 || d > 1000000) {
      return res.status(400).json({ success: false, message: 'كمية غير صالحة' });
    }
    const u = await get('SELECT diamonds FROM users WHERE id = ?', [userId]);
    if (!u) return res.status(404).json({ success: false, message: 'المستخدم غير موجود' });
    if (u.diamonds < d) return res.status(400).json({ success: false, message: 'رصيد الكريستال غير كافٍ' });
    await run('UPDATE users SET diamonds = diamonds - ?, coins = coins + ? WHERE id = ? AND diamonds >= ?', [d, d * 100, userId, d]);
    const updated = await get('SELECT * FROM users WHERE id = ?', [userId]);
    res.json({ success: true, user: updated });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ===== وكلاء الشحن (تعيّنهم الإدارة) =====
const AGENT_METHODS = ['visa','mastercard','amex','stcpay','zaincash','orange','vodafone','cliq','westernunion','usdt','bank','cash'];
function parseAgentRow(a) {
  let methods = [];
  try { methods = JSON.parse(a.methods || '[]'); } catch (e) {}
  return {
    id: a.id, user_id: a.user_id, display_name: a.display_name || '',
    methods: methods.filter(m => AGENT_METHODS.includes(m)),
    countries: String(a.countries || '').split(',').map(c => c.trim().toUpperCase()).filter(Boolean),
    sort_order: a.sort_order || 0, is_active: a.is_active ? 1 : 0
  };
}
function cleanAgentBody(b) {
  b = b || {};
  const methods = (Array.isArray(b.methods) ? b.methods : []).filter(m => AGENT_METHODS.includes(m));
  const countries = (Array.isArray(b.countries) ? b.countries : String(b.countries || '').split(','))
    .map(c => String(c).trim().toUpperCase()).filter(c => /^[A-Z]{2}$/.test(c));
  return {
    display_name: String(b.display_name || '').trim().slice(0, 40),
    methods: JSON.stringify(methods),
    countries: Array.from(new Set(countries)).join(','),
    sort_order: Math.max(0, Math.min(9999, Math.floor(Number(b.sort_order)) || 0)),
    is_active: b.is_active === 0 || b.is_active === false ? 0 : 1
  };
}

// للمستخدمين: الوكلاء المتاحون لمنطقتهم (المتصلون أولاً)
app.get('/api/wallet/charge-agents', async (req, res) => {
  res.set('Cache-Control', 'no-store');
  try {
    const cc = String(req.query.country || '').toUpperCase();
    const rows = await all(
      `SELECT a.*, u.name, u.avatar, u.avatar_frame
       FROM charge_agents a JOIN users u ON u.id = a.user_id
       WHERE a.is_active = 1 AND COALESCE(u.is_banned, 0) = 0
       ORDER BY a.sort_order ASC, a.created_at ASC`
    );
    const agents = rows.map(r => {
      const p = parseAgentRow(r);
      return {
        id: r.user_id, name: p.display_name || r.name, avatar: r.avatar || '', avatar_frame: r.avatar_frame || '',
        methods: p.methods, countries: p.countries, sort_order: p.sort_order,
        online: !!(userSockets.get(r.user_id) && userSockets.get(r.user_id).size)
      };
    }).filter(a => !cc || !a.countries.length || a.countries.includes(cc));
    agents.sort((x, y) => (y.online - x.online) || (x.sort_order - y.sort_order));
    res.json({ success: true, agents });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/admin/charge-agents', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const rows = await all(
      `SELECT a.*, u.name, u.email, u.avatar, u.coins, u.diamonds
       FROM charge_agents a JOIN users u ON u.id = a.user_id
       ORDER BY a.sort_order ASC, a.created_at ASC`
    );
    res.json({ success: true, methods: AGENT_METHODS, agents: rows.map(r => ({
      ...parseAgentRow(r), name: r.name, email: r.email, avatar: r.avatar, coins: r.coins, diamonds: r.diamonds,
      online: !!(userSockets.get(r.user_id) && userSockets.get(r.user_id).size)
    })) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/admin/charge-agents', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const userId = String((req.body || {}).user_id || '');
    const user = await get('SELECT id FROM users WHERE id = ?', [userId]);
    if (!user) return res.status(404).json({ success: false, message: 'المستخدم غير موجود' });
    const dup = await get('SELECT id FROM charge_agents WHERE user_id = ?', [userId]);
    if (dup) return res.status(409).json({ success: false, message: 'هذا المستخدم معيّن كوكيل شحن مسبقاً' });
    const c = cleanAgentBody(req.body);
    const id = 'agent-' + uuidv4().slice(0, 8);
    await run(
      `INSERT INTO charge_agents (id, user_id, display_name, methods, countries, sort_order, is_active) VALUES (?,?,?,?,?,?,?)`,
      [id, userId, c.display_name, c.methods, c.countries, c.sort_order, c.is_active]
    );
    res.json({ success: true, id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/admin/charge-agents/:id', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const c = cleanAgentBody(req.body);
    const r = await run(
      `UPDATE charge_agents SET display_name = ?, methods = ?, countries = ?, sort_order = ?, is_active = ? WHERE id = ?`,
      [c.display_name, c.methods, c.countries, c.sort_order, c.is_active, req.params.id]
    );
    io.emit('charge_agents_updated', { at: Date.now() });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/admin/charge-agents/:id', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    await run('DELETE FROM charge_agents WHERE id = ?', [req.params.id]);
    io.emit('charge_agents_updated', { at: Date.now() });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ===== الشحن عن طريق الدردشة =====
const CHAT_RECHARGE_ROLES = ['owner', 'super_master', 'super_admin'];

// حساب وكيل الشحن (أول مالك/مدير أعلى) ليتواصل معه المستخدم في الدردشة
app.get('/api/wallet/agent', async (req, res) => {
  try {
    const row = await get(
      `SELECT id, name, avatar, avatar_frame, role FROM users
       WHERE role IN ('owner','super_master','super_admin')
       ORDER BY CASE role WHEN 'owner' THEN 0 WHEN 'super_master' THEN 1 ELSE 2 END
       LIMIT 1`
    );
    if (!row) return res.status(404).json({ success: false, message: 'لا يوجد وكيل شحن متاح حالياً' });
    res.json({ success: true, agent: row });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// شحن رصيد مستخدم من داخل نافذة الدردشة (للإدارة فقط) — يضيف على الرصيد الحالي
app.post('/api/wallet/chat-credit', async (req, res) => {
  try {
    const staffId = req.headers['x-user-id'];
    if (!staffId) return res.status(401).json({ error: 'Unauthorized' });
    const staff = await get('SELECT id, name, role FROM users WHERE id = ?', [staffId]);
    if (!staff || !CHAT_RECHARGE_ROLES.includes(staff.role)) {
      return res.status(403).json({ success: false, message: 'الشحن من الدردشة متاح للإدارة فقط' });
    }

    const { target_id } = req.body;
    const coins = Math.floor(Number(req.body.coins || 0));
    const diamonds = Math.floor(Number(req.body.diamonds || 0));
    if (!target_id || target_id === staffId) {
      return res.status(400).json({ success: false, message: 'مستخدم غير صالح' });
    }
    if (!Number.isFinite(coins) || !Number.isFinite(diamonds) || coins < 0 || diamonds < 0 || (coins === 0 && diamonds === 0)) {
      return res.status(400).json({ success: false, message: 'أدخل كمية عملات أو ألماس صحيحة' });
    }
    if (coins > 1000000000 || diamonds > 1000000000) {
      return res.status(400).json({ success: false, message: 'الكمية كبيرة جداً' });
    }
    const target = await get('SELECT id, name FROM users WHERE id = ?', [target_id]);
    if (!target) return res.status(404).json({ success: false, message: 'المستخدم غير موجود' });

    await run('UPDATE users SET coins = coins + ?, diamonds = diamonds + ? WHERE id = ?', [coins, diamonds, target_id]);
    // الشحن من الإدارة يضيف نقاط الثروة حسب الألماس المضاف (والمستوى كنوع من الشراء)
    if (diamonds > 0) {
      try {
        const ps = await getPointSettings();
        const pts = memberLevels.pointsForAmount(diamonds, 'diamonds', ps);
        await addMemberPoints(target_id, 'wealth', pts);
        await addLevelPoints(target_id, pts);
        notifyMemberStats(target_id);
      } catch (e) {}
    }
    const updated = await get('SELECT id, name, coins, diamonds, level FROM users WHERE id = ?', [target_id]);

    // رسالة تأكيد داخل نفس المحادثة
    const parts = [];
    if (coins) parts.push(`${coins.toLocaleString('en-US')} 🪙 عملة`);
    if (diamonds) parts.push(`${diamonds.toLocaleString('en-US')} 💎 ألماس`);
    const msgId = `msg-${Date.now().toString()}-${uuidv4().slice(0, 4)}`;
    await run(
      `INSERT INTO messages (id, sender_id, receiver_id, message_type, content, metadata) VALUES (?, ?, ?, 'text', ?, ?)`,
      [msgId, staffId, target_id, `✅ تم شحن رصيدك: +${parts.join(' و +')}`, JSON.stringify({ kind: 'recharge', coins, diamonds })]
    );
    const createdMsg = await get(
      `SELECT m.*, u.name as sender_name, u.avatar as sender_avatar FROM messages m JOIN users u ON m.sender_id = u.id WHERE m.id = ?`,
      [msgId]
    );

    const sockets = userSockets.get(target_id);
    if (sockets) {
      for (const sId of sockets) {
        io.to(sId).emit('private_message', createdMsg);
        io.to(sId).emit('balance_updated', { coins: updated.coins, diamonds: updated.diamonds, level: updated.level, added: { coins, diamonds } });
      }
    }

    res.json({ success: true, user: updated, message: createdMsg });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// عدد كل الحسابات المسجلة فعلياً في الموقع (للعدّاد في صفحة الكوكب)
app.get('/api/stats/registered-count', async (req, res) => {
  try {
    const row = await get('SELECT COUNT(*) AS c FROM users');
    res.json({ count: row ? (row.c || 0) : 0 });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 7. Get All Users (for Soul Planet Radar)
app.get('/api/users', async (req, res) => {
  try {
    const users = await all('SELECT id, name, avatar, bio, gender, country_code, soul_planet, soul_score, soul_tags, level, wealth_level, charm_level, avatar_frame, role FROM users LIMIT 50');
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

const SUPPORTED_COUNTRIES = [
  { code: 'GLOBAL', name: 'عالمي', flag: '🌍', isGlobal: true },
  { code: 'JO', name: 'الأردن', flag: '🇯🇴', defaultCity: 'إربد / عمان' },
  { code: 'SA', name: 'السعودية', flag: '🇸🇦', defaultCity: 'الرياض' },
  { code: 'EG', name: 'مصر', flag: '🇪🇬', defaultCity: 'القاهرة' },
  { code: 'AE', name: 'الإمارات', flag: '🇦🇪', defaultCity: 'دبي' },
  { code: 'IQ', name: 'العراق', flag: '🇮🇶', defaultCity: 'بغداد' },
  { code: 'KW', name: 'الكويت', flag: '🇰🇼', defaultCity: 'الكويت' },
  { code: 'MA', name: 'المغرب', flag: '🇲🇦', defaultCity: 'الدار البيضاء' },
  { code: 'DZ', name: 'الجزائر', flag: '🇩🇿', defaultCity: 'الجزائر' },
  { code: 'QA', name: 'قطر', flag: '🇶🇦', defaultCity: 'الدوحة' },
  { code: 'OM', name: 'عُمان', flag: '🇴🇲', defaultCity: 'مسقط' },
  { code: 'BH', name: 'البحرين', flag: '🇧🇭', defaultCity: 'المنامة' },
  { code: 'LB', name: 'لبنان', flag: '🇱🇧', defaultCity: 'بيروت' },
  { code: 'SY', name: 'سوريا', flag: '🇸🇾', defaultCity: 'دمشق' },
  { code: 'YE', name: 'اليمن', flag: '🇾🇪', defaultCity: 'صنعاء' },
  { code: 'TN', name: 'تونس', flag: '🇹🇳', defaultCity: 'تونس' },
  { code: 'PS', name: 'فلسطين', flag: '🇵🇸', defaultCity: 'القدس' }
];

function getClientIp(req) {
  const forwarded = req.headers['x-forwarded-for'];
  if (forwarded) {
    return forwarded.split(',')[0].trim();
  }
  return req.headers['x-real-ip'] || req.socket.remoteAddress || req.ip || '127.0.0.1';
}

function getCountryFromIp(ip) {
  // If local or private sandbox network, map to user's real country (Jordan 🇯🇴 - JO)
  if (!ip || ip === '127.0.0.1' || ip === '::1' || ip.startsWith('10.') || ip.startsWith('192.168.') || ip.startsWith('172.') || ip.startsWith('169.254.')) {
    return {
      ip: ip || '127.0.0.1',
      country_code: 'JO',
      country_name: 'الأردن',
      country_flag: '🇯🇴',
      city: 'إربد',
      isLocal: true
    };
  }

  // Known sample IP blocks for Arab countries
  if (ip.startsWith('94.249.') || ip.startsWith('212.35.') || ip.startsWith('212.118.')) {
    return { ip, country_code: 'JO', country_name: 'الأردن', country_flag: '🇯🇴', city: 'عمان', isLocal: false };
  }
  if (ip.startsWith('178.80.') || ip.startsWith('82.167.') || ip.startsWith('212.11.')) {
    return { ip, country_code: 'SA', country_name: 'السعودية', country_flag: '🇸🇦', city: 'الرياض', isLocal: false };
  }
  if (ip.startsWith('197.38.') || ip.startsWith('156.192.') || ip.startsWith('41.232.')) {
    return { ip, country_code: 'EG', country_name: 'مصر', country_flag: '🇪🇬', city: 'القاهرة', isLocal: false };
  }
  if (ip.startsWith('94.200.') || ip.startsWith('194.170.')) {
    return { ip, country_code: 'AE', country_name: 'الإمارات', country_flag: '🇦🇪', city: 'دبي', isLocal: false };
  }
  if (ip.startsWith('149.255.') || ip.startsWith('37.236.')) {
    return { ip, country_code: 'IQ', country_name: 'العراق', country_flag: '🇮🇶', city: 'بغداد', isLocal: false };
  }
  if (ip.startsWith('196.12.') || ip.startsWith('105.154.')) {
    return { ip, country_code: 'MA', country_name: 'المغرب', country_flag: '🇲🇦', city: 'الدار البيضاء', isLocal: false };
  }
  if (ip.startsWith('62.215.') || ip.startsWith('83.96.')) {
    return { ip, country_code: 'KW', country_name: 'الكويت', country_flag: '🇰🇼', city: 'الكويت', isLocal: false };
  }

  // Fallback to Jordan (JO)
  return {
    ip,
    country_code: 'JO',
    country_name: 'الأردن',
    country_flag: '🇯🇴',
    city: 'إربد',
    isLocal: false
  };
}

// 7b. Get Client IP & Detected Country
app.get('/api/geo/my-country', (req, res) => {
  const ip = getClientIp(req);
  const geo = getCountryFromIp(ip);
  res.json({
    success: true,
    ...geo
  });
});

// 7c. Get Supported Countries List & Active Room Counts
app.get('/api/geo/countries', async (req, res) => {
  try {
    const counts = await all(`
      SELECT country_code, COUNT(*) as room_count
      FROM rooms
      GROUP BY country_code
    `);
    const countMap = {};
    counts.forEach(c => { countMap[c.country_code] = c.room_count; });
    const totalRooms = counts.reduce((acc, c) => acc + c.room_count, 0);

    const list = SUPPORTED_COUNTRIES.map(item => ({
      ...item,
      room_count: item.code === 'GLOBAL' ? totalRooms : (countMap[item.code] || 0)
    }));

    res.json({ success: true, countries: list });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 8. Voice & Video Rooms List (with IP / Country Filtering)
app.get('/api/rooms', async (req, res) => {
  try {
    const countryFilter = req.query.country;
    let query = `
      SELECT r.*, u.name as host_name, u.avatar as host_avatar, u.avatar_frame as host_frame,
             rc.image_url as host_room_card
      FROM rooms r
      JOIN users u ON r.host_id = u.id
      LEFT JOIN room_cards rc ON rc.id = u.room_card AND rc.is_active = 1
    `;
    const params = [];

    if (countryFilter && countryFilter !== 'all' && countryFilter !== 'GLOBAL') {
      query += ` WHERE r.country_code = ? `;
      params.push(countryFilter);
    }

    query += ` ORDER BY r.created_at DESC `;

    const rooms = await all(query, params);

    // Attach active occupants count & seat previews
    for (const r of rooms) {
      const seats = await all(`
        SELECT s.seat_index, s.is_muted, s.is_locked, u.id as user_id, u.name, u.avatar
        FROM room_seats s
        LEFT JOIN users u ON s.user_id = u.id
        WHERE s.room_id = ?
        ORDER BY s.seat_index ASC
      `, [r.id]);

      r.seats = seats;
      r.active_speakers = seats.filter(s => s.user_id !== null).length;
      const roomState = activeRoomStates.get(r.id);
      r.audience_count = roomState ? visibleAudienceCount(roomState) : 0;
      r.total_occupants = r.audience_count;
      // أول 5 من المتواجدين الآن في الغرفة (مع إطاراتهم) لعرضهم في بطاقة الغرفة
      r.audience_preview = roomState
        ? visibleAudienceList(roomState).slice(0, 5).map(u => ({
            id: u.id, avatar: u.avatar || '', frame: u.avatar_frame || ''
          }))
        : [];
    }

    // الأكثر زواراً أولاً (sort ثابت: الأحدث أولاً عند التساوي)
    rooms.sort((a, b) => (b.audience_count || 0) - (a.audience_count || 0));

    res.json(rooms.map(stripRoomSecrets));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 9. Create New Voice Room or Live Video Broadcast (Automatic IP & Country Detection)
app.post('/api/rooms', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'] || req.body.creator_id;
    if (!userId || userId === 'null' || userId === 'undefined') {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    // لا يُنشئ غرفة إلا حساب مسجّل (لا إنشاء حسابات تلقائية بمعرّف مجهول)
    const hostUser = await get('SELECT * FROM users WHERE id = ?', [userId]);
    if (!hostUser) return res.status(401).json({ error: 'الحساب غير مسجّل' });

    // Single Active Room Rule: A user cannot create a second room until they delete their existing room
    const existingRoom = await get('SELECT * FROM rooms WHERE host_id = ?', [userId]);
    if (existingRoom) {
      return res.status(400).json({
        success: false,
        hasActiveRoom: true,
        error: `لديك غرفة نشطة بالفعل بعنوان "${existingRoom.title}". وفقاً لنظام SoulChill، يجب حذف غرفتك السابقة قبل إنشاء غرفة جديدة.`,
        existingRoom
      });
    }

    const { title, category, room_type, theme, announcement, cover_image, country_code } = req.body;
    if (!title) return res.status(400).json({ error: 'Room title is required' });
    const roomCode = String((req.body && req.body.password) || '').trim();
    if (roomCode && !ROOM_CODE_RE.test(roomCode)) return res.status(400).json({ error: 'كلمة مرور الغرفة يجب أن تكون 4 أرقام بالضبط' });

    const clientIp = getClientIp(req);
    const geo = getCountryFromIp(clientIp);

    // Check if user specified a country or fallback to IP detected country
    let countryItem = SUPPORTED_COUNTRIES.find(c => c.code === country_code) || geo;
    const finalCountryCode = countryItem.code || geo.country_code || 'JO';
    const finalCountryName = countryItem.name || geo.country_name || 'الأردن';
    const finalCountryFlag = countryItem.flag || geo.country_flag || '🇯🇴';

    const roomId = `room-${Date.now().toString().slice(-6)}`;
    const finalRoomType = 'voice';
    const defaultCover = cover_image || 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=600&q=80';

    await run(`
      INSERT INTO rooms (id, title, category, room_type, cover_image, likes_count, host_id, country_code, country_name, country_flag, creator_ip, theme, announcement)
      VALUES (?, ?, ?, 'voice', ?, 0, ?, ?, ?, ?, ?, ?, ?)
    `, [roomId, title, category || 'chill', defaultCover, userId, finalCountryCode, finalCountryName, finalCountryFlag, clientIp, theme || 'cosmic_purple', announcement || 'أهلاً بكم في رومنا الصوتي 🌟']);

    // Setup 8 seats + seat 0 for host (seat 0 starts EMPTY so host is not forced directly onto mic)
    await run(`INSERT INTO room_seats (room_id, seat_index, user_id, is_muted, is_locked) VALUES (?, 0, NULL, 0, 0)`, [roomId]);
    for (let i = 1; i <= 8; i++) {
      await run(`INSERT INTO room_seats (room_id, seat_index, user_id, is_muted, is_locked) VALUES (?, ?, NULL, 0, 0)`, [roomId, i]);
    }

    await run(`UPDATE rooms SET host_last_seen = CURRENT_TIMESTAMP WHERE id = ?`, [roomId]);
    if (roomCode) await setRoomCode(roomId, roomCode);
    pushFemaleTasksStatus(userId);
    let created = await get(`
      SELECT r.*, u.name as host_name, u.avatar as host_avatar, u.avatar_frame as host_frame
      FROM rooms r
      LEFT JOIN users u ON r.host_id = u.id
      WHERE r.id = ?
    `, [roomId]);

    if (!created) {
      created = await get('SELECT * FROM rooms WHERE id = ?', [roomId]);
    }

    if (created) {
      created.host_id = created.host_id || userId;
      created.host_name = created.host_name || (hostUser ? hostUser.name : 'المضيف');
      created.host_avatar = created.host_avatar || (hostUser ? hostUser.avatar : defaultCover);
      created.host_frame = created.host_frame || (hostUser ? hostUser.avatar_frame : '');
      created.audience_count = 1;
    }
    created = stripRoomSecrets(created);

    // Broadcast room creation to ALL clients in real time so the rooms grid updates immediately without page refresh
    io.emit('room_created', { room: created });

    res.json({ success: true, room: created });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 9b. Delete Room by ID (Host or Owner) - Updates lobby instantly
app.delete('/api/rooms/:id', async (req, res) => {
  try {
    const roomId = req.params.id;
    const userId = req.headers['x-user-id'] || req.body.userId;
    if (!userId) return res.status(401).json({ error: 'Unauthorized' });

    const room = await get('SELECT * FROM rooms WHERE id = ?', [roomId]);
    if (!room) return res.status(404).json({ error: 'Room not found' });

    const user = await get('SELECT * FROM users WHERE id = ?', [userId]);
    const isStaff = user && ['owner', 'super_master', 'super_admin', 'admin', 'moderator'].includes(user.role);
    const isAuthorized = room.host_id === userId || isStaff;
    if (!isAuthorized) {
      return res.status(403).json({ error: 'ليس لديك صلاحية حذف هذه الغرفة' });
    }

    // Clean up room records in SQLite
    await run('DELETE FROM room_seats WHERE room_id = ?', [roomId]);
    await run('DELETE FROM messages WHERE room_id = ?', [roomId]);
    await run('DELETE FROM rooms WHERE id = ?', [roomId]);

    // Notify all participants in this room to leave
    io.to(`room:${roomId}`).emit('room_closed_by_host', {
      roomId,
      adminName: user ? user.name : 'المضيف'
    });

    // Broadcast room deletion globally to update all rooms grids instantly without reload
    io.emit('room_deleted', { roomId });
    pushFemaleTasksStatus(room.host_id);

    res.json({ success: true, message: 'تم حذف الغرفة بنجاح', roomId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 9b. Get Favorite Rooms ("المفضلة")
app.get(['/api/rooms/favorites', '/api/favorite-rooms'], async (req, res) => {
  try {
    const userId = req.headers['x-user-id'] || req.query.user_id;
    if (!userId) return res.json({ favoriteRoomIds: [] });

    const rows = await all('SELECT room_id FROM favorite_rooms WHERE user_id = ? ORDER BY created_at DESC', [userId]);
    res.json({
      favoriteRoomIds: rows.map(r => r.room_id)
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 10. Get Specific Room Details & Seats
app.get('/api/rooms/:id', async (req, res) => {
  try {
    const roomId = req.params.id;
    const room = await get(`
      SELECT r.*, u.name as host_name, u.avatar as host_avatar, u.avatar_frame as host_frame, u.level as host_level
      FROM rooms r
      LEFT JOIN users u ON r.host_id = u.id
      WHERE r.id = ?
    `, [roomId]);

    if (!room) return res.status(404).json({ error: 'Room not found' });

    const seats = await all(`
      SELECT s.seat_index, s.is_muted, s.is_locked, u.id as user_id, u.name, u.avatar, u.avatar_frame, u.level, u.charm_level
      FROM room_seats s
      LEFT JOIN users u ON s.user_id = u.id
      WHERE s.room_id = ?
      ORDER BY s.seat_index ASC
    `, [roomId]);

    room.seats = seats;
    // شكل المقاعد = مقعد المايك المفعّل عند مضيف/مالك الغرفة (يظهر لكل من في الغرفة)
    room.mic_seat = await getEquippedMicSeatUrl(room.host_id);
    res.json(stripRoomSecrets(room));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 11. Room Chat Messages
app.get('/api/rooms/:id/messages', async (req, res) => {
  try {
    const roomId = req.params.id;
    const gateRoom = await get('SELECT id, host_id, access_hash FROM rooms WHERE id = ?', [roomId]);
    if (await roomNeedsCode(gateRoom, req.headers['x-user-id'])) {
      return res.status(403).json({ error: 'الغرفة محمية بكلمة مرور', code: 'room_password_required' });
    }
    const messages = await all(`
      SELECT m.*, u.name as sender_name, u.avatar as sender_avatar, u.level as sender_level, u.wealth_level as sender_wealth_level, u.charm_level as sender_charm_level, u.avatar_frame as sender_frame, u.chat_frame as sender_chat_frame, u.role as sender_role
      FROM messages m
      JOIN users u ON m.sender_id = u.id
      WHERE m.room_id = ?
      ORDER BY m.created_at ASC
      LIMIT 100
    `, [roomId]);

    const bubbleCache = new Map();
    for (const m of messages) {
      if (!bubbleCache.has(m.sender_id)) bubbleCache.set(m.sender_id, await getEquippedBubbleUrl(m.sender_id));
      m.sender_chat_bubble = bubbleCache.get(m.sender_id);
    }
    res.json(messages);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 12. Direct Messages Conversations List
app.get(['/api/messages/conversations', '/api/conversations'], async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    if (!userId) return res.json([]);

    // Find distinct conversation partners
    const conversations = await all(`
      SELECT DISTINCT 
        CASE WHEN sender_id = ? THEN receiver_id ELSE sender_id END as other_id
      FROM messages
      WHERE (sender_id = ? OR receiver_id = ?) AND room_id IS NULL
    `, [userId, userId, userId]);

    const result = [];
    for (const c of conversations) {
      if (!c.other_id) continue;
      const otherUser = await get('SELECT id, name, avatar, soul_planet, avatar_frame FROM users WHERE id = ?', [c.other_id]);
      if (!otherUser) continue;

      const lastMsg = await get(`
        SELECT content, message_type, media_url, created_at, sender_id
        FROM messages
        WHERE ((sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?))
          AND room_id IS NULL
        ORDER BY created_at DESC
        LIMIT 1
      `, [userId, c.other_id, c.other_id, userId]);

      result.push({
        user: otherUser,
        lastMessage: lastMsg || null,
        last_message: lastMsg || null,
        unreadCount: 0
      });
    }

    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 13. Direct Chat History with Specific User
app.get('/api/messages/history/:otherId', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    const otherId = req.params.otherId;
    if (!userId) return res.status(401).json({ error: 'Unauthorized' });

    const messages = await all(`
      SELECT m.*, u.name as sender_name, u.avatar as sender_avatar
      FROM messages m
      JOIN users u ON m.sender_id = u.id
      WHERE ((m.sender_id = ? AND m.receiver_id = ?) OR (m.sender_id = ? AND m.receiver_id = ?))
        AND m.room_id IS NULL
      ORDER BY m.created_at ASC, m.rowid ASC
      LIMIT 100
    `, [userId, otherId, otherId, userId]);

    res.json(messages);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// المتابعة المتبادلة: شرط تفعيل المكالمات وإرسال الصور والتسجيل الصوتي
async function areMutualFollowers(a, b) {
  if (!a || !b || a === b) return false;
  const f1 = await get('SELECT 1 AS x FROM follows WHERE follower_id = ? AND following_id = ?', [a, b]);
  if (!f1) return false;
  const f2 = await get('SELECT 1 AS x FROM follows WHERE follower_id = ? AND following_id = ?', [b, a]);
  return !!f2;
}
const MUTUAL_FOLLOW_MSG = 'المكالمات والصور والرسائل الصوتية تُفعَّل فقط عندما تتابعان بعضكما';

// 14. Send Direct Message
app.post('/api/messages', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    if (!userId) return res.status(401).json({ error: 'Unauthorized' });

    const { receiver_id, message_type, content, media_url, metadata } = req.body;

    // الصور والرسائل الصوتية (وأي وسائط) تتطلب متابعة متبادلة بين الطرفين
    if (['image', 'voice'].includes(message_type) || (media_url && message_type !== 'gift')) {
      if (!(await areMutualFollowers(userId, receiver_id))) {
        return res.status(403).json({ success: false, code: 'MUTUAL_FOLLOW_REQUIRED', error: MUTUAL_FOLLOW_MSG });
      }
    }
    const msgId = `msg-${Date.now().toString()}-${uuidv4().slice(0, 4)}`;

    await run(`
      INSERT INTO messages (id, sender_id, receiver_id, message_type, content, media_url, metadata)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `, [msgId, userId, receiver_id, message_type || 'text', content, media_url, metadata ? JSON.stringify(metadata) : null]);

    // نقاط المستوى: التفاعل في المحادثات الخاصة (مقيَّد زمنياً ضد السبام)
    addChatInteractionXp(userId, 5);

    const createdMsg = await get(`
      SELECT m.*, u.name as sender_name, u.avatar as sender_avatar
      FROM messages m
      JOIN users u ON m.sender_id = u.id
      WHERE m.id = ?
    `, [msgId]);

    // Send via socket to receiver if online
    const receiverSockets = userSockets.get(receiver_id);
    if (receiverSockets) {
      for (const sockId of receiverSockets) {
        io.to(sockId).emit('private_message', createdMsg);
      }
    }

    areMutualFollowers(userId, receiver_id).then(ok => { if (ok) recordMission(userId, 'dm_messages', 1); }).catch(() => {});
    res.json(createdMsg);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 15. File / Voice Note Upload
app.post('/api/upload', upload.single('file'), (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }
    const fileUrl = `/uploads/${req.file.filename}`;
    res.json({
      success: true,
      url: fileUrl,
      filename: req.file.filename,
      mimetype: req.file.mimetype,
      size: req.file.size
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Personal music repository: uploaded files and online audio links are persisted per user.
function musicFilePath(url) {
  if (typeof url !== 'string' || !url.startsWith('/uploads/')) return null;
  const uploadsDir = path.join(__dirname, 'public', 'uploads');
  const full = path.resolve(__dirname, 'public', url.replace(/^\//, ''));
  return path.dirname(full) === uploadsDir ? full : null;
}

// يحذف كل نسخ مقطع يوتيوب من الخادم (الملف المحفوظ بأي صيغة + كاش البث) — يُستدعى فقط حين لا يحتفظ به أي مستخدم
function purgeYtMediaFiles(ytId) {
  if (!/^[A-Za-z0-9_-]{11}$/.test(String(ytId || ''))) return 0;
  const targets = [];
  for (const ext of ['mp4', 'mp3', 'm4a', 'webm', 'mkv', 'opus']) targets.push(path.join(__dirname, 'public', 'uploads', 'ytm-' + ytId + '.' + ext));
  for (const ext of ['m4a', 'webm']) targets.push(path.join(__dirname, 'cache', 'yt', ytId + '.' + ext));
  let removed = 0;
  for (const f of targets) { try { if (fs.existsSync(f)) { fs.unlinkSync(f); removed++; } } catch (e) { /* غير مهم */ } }
  return removed;
}

async function requireMusicUser(req, res) {
  const userId = String(req.headers['x-user-id'] || '').trim();
  if (!userId) { res.status(401).json({ error: 'يجب تسجيل الدخول أولاً' }); return null; }
  const user = await get('SELECT id FROM users WHERE id = ?', [userId]);
  if (!user) { res.status(401).json({ error: 'المستخدم غير موجود' }); return null; }
  return user.id;
}

app.get('/api/music-library', async (req, res) => {
  try {
    const userId = await requireMusicUser(req, res); if (!userId) return;
    const tracks = await all(`
      SELECT id, title, source, url, file_name, artist, thumbnail, yt_id, audio_status, audio_error, audio_attempts, created_at
      FROM user_music_tracks WHERE user_id = ? ORDER BY created_at DESC
    `, [userId]);
    res.json({ success: true, tracks });
  } catch (err) {
    res.status(500).json({ error: 'تعذر تحميل مكتبة الموسيقى' });
  }
});

// حفظ أغنية من يوتيوب في مكتبة المستخدم (رفع الملفات من الجهاز أُلغي)
app.post('/api/music-library', async (req, res) => {
  try {
    const userId = await requireMusicUser(req, res); if (!userId) return;
    const body = req.body || {};
    const ytId = String(body.youtube_id || '').trim();
    if (!/^[A-Za-z0-9_-]{11}$/.test(ytId)) {
      return res.status(400).json({ error: 'أضف الأغاني عن طريق البحث في يوتيوب' });
    }
    const dup = await get('SELECT id, title, source, url, file_name, artist, thumbnail, yt_id, audio_status, audio_error, audio_attempts FROM user_music_tracks WHERE user_id = ? AND yt_id = ?', [userId, ytId]);
    if (dup) {
      // إن كان الحفظ السابق فاشلاً نعيد تشغيل المعالجة تلقائياً بدل إرجاع سجل ميت
      if (dup.audio_status === 'failed' && dup.yt_id) {
        cancelYtAudioRetry(dup.yt_id);
        ytMp3.reset(dup.yt_id);
        await run(`UPDATE user_music_tracks SET audio_status = 'processing', audio_error = '', audio_attempts = 0 WHERE id = ?`, [dup.id]);
        dup.audio_status = 'processing'; dup.audio_error = ''; dup.audio_attempts = 0;
        startYtAudioJob(dup.yt_id);
      }
      return res.json({ success: true, track: dup, duplicate: true });
    }
    // الحد قابل للضبط عبر MUSIC_MAX_TRACKS — 0 أو غير محدد = بلا حد
    const musicMaxTracks = Math.max(0, Number(process.env.MUSIC_MAX_TRACKS || 0));
    if (musicMaxTracks > 0) {
      const count = await get('SELECT COUNT(*) AS n FROM user_music_tracks WHERE user_id = ?', [userId]);
      if (count && count.n >= musicMaxTracks) return res.status(400).json({ error: 'وصلت للحد الأقصى من الأغاني (' + musicMaxTracks + ')، احذف بعضها أولاً أو ارفع MUSIC_MAX_TRACKS' });
    }

    const title = String(body.title || 'موسيقى').replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, 100) || 'موسيقى';
    const artist = String(body.artist || '').replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, 80);
    const thumbnail = /^https:\/\/i\.ytimg\.com\//.test(String(body.thumbnail || '')) ? String(body.thumbnail).slice(0, 300) : `https://i.ytimg.com/vi/${ytId}/mqdefault.jpg`;
    const id = uuidv4();
    // إن كان الصوت محمّلاً مسبقاً (حفظه مستخدم آخر) نستعمله فوراً؛ وإلا نبدأ التحميل في الخلفية
    const ready = ytMp3.existing(ytId);
    let source, url, fileName, status;
    if (ready) { source = 'device'; url = ready.url; fileName = path.basename(ready.file); status = 'ready'; }
    else { source = 'youtube'; url = `https://www.youtube.com/watch?v=${ytId}`; fileName = null; status = 'processing'; }
    await run(`INSERT INTO user_music_tracks (id, user_id, title, source, url, file_name, artist, thumbnail, yt_id, audio_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [id, userId, title, source, url, fileName, artist, thumbnail, ytId, status]);
    res.json({ success: true, track: { id, title, source, url, file_name: fileName, artist, thumbnail, yt_id: ytId, audio_status: status } });
    if (status === 'processing') startYtAudioJob(ytId);   // بعد الرد: لا ننتظر التحميل
  } catch (e) {
    console.error('music-library save error:', e);
    res.status(500).json({ error: 'تعذر حفظ الأغنية في مكتبتك' });
  }
});

// إعادة محاولة التحويل إلى MP3 بعد فشل التنزيل (مثلاً بعد إضافة cookies أو بروكسي).
app.post('/api/music-library/:id/retry', async (req, res) => {
  try {
    const userId = await requireMusicUser(req, res); if (!userId) return;
    const track = await get(`SELECT id, title, source, url, file_name, artist, thumbnail, yt_id, audio_status
      FROM user_music_tracks WHERE id = ? AND user_id = ?`, [req.params.id, userId]);
    if (!track) return res.status(404).json({ error: 'الأغنية غير موجودة' });
    if (!track.yt_id || track.source !== 'youtube') return res.status(400).json({ error: 'إعادة المحاولة متاحة لأغاني يوتيوب التي لم تكتمل معالجتها فقط' });
    if (track.audio_status === 'processing') return res.json({ success: true, track });
    cancelYtAudioRetry(track.yt_id);
    ytMp3.reset(track.yt_id);

    const ready = ytMp3.existing(track.yt_id);
    if (ready) {
      track.source = 'device'; track.url = ready.url; track.file_name = path.basename(ready.file); track.audio_status = 'ready';
      await run(`UPDATE user_music_tracks SET source = 'device', url = ?, file_name = ?, audio_status = 'ready' WHERE yt_id = ? AND audio_status != 'ready'`,
        [ready.url, track.file_name, track.yt_id]);
      return res.json({ success: true, track });
    }

    track.source = 'youtube'; track.url = `https://www.youtube.com/watch?v=${track.yt_id}`; track.file_name = null; track.audio_status = 'processing';
    track.audio_error = ''; track.audio_attempts = 0;
    await run(`UPDATE user_music_tracks SET source = 'youtube', url = ?, file_name = NULL, audio_status = 'processing', audio_error = '', audio_attempts = 0 WHERE id = ? AND user_id = ?`,
      [track.url, track.id, userId]);
    res.json({ success: true, track });
    startYtAudioJob(track.yt_id);
  } catch (e) {
    console.error('music-library retry error:', e);
    if (!res.headersSent) res.status(500).json({ error: 'تعذر بدء إعادة معالجة الأغنية' });
  }
});

// إعادة محاولة كل الأغاني الفاشلة دفعة واحدة
app.post('/api/music-library/retry-failed', async (req, res) => {
  try {
    const userId = await requireMusicUser(req, res); if (!userId) return;
    const rows = await all(`SELECT DISTINCT yt_id FROM user_music_tracks
      WHERE user_id = ? AND audio_status = 'failed' AND source = 'youtube' AND yt_id != ''`, [userId]);
    if (!rows.length) return res.json({ success: true, retried: 0, message: 'لا توجد أغانٍ فاشلة' });
    await run(`UPDATE user_music_tracks SET audio_status = 'processing', audio_error = '', audio_attempts = 0
      WHERE user_id = ? AND audio_status = 'failed' AND source = 'youtube'`, [userId]);
    rows.forEach(r => { cancelYtAudioRetry(r.yt_id); ytMp3.reset(r.yt_id); startYtAudioJob(r.yt_id); });
    res.json({ success: true, retried: rows.length });
  } catch (e) {
    console.error('music-library retry-failed error:', e);
    res.status(500).json({ error: 'تعذر إعادة المحاولة' });
  }
});

app.delete('/api/music-library/:id', async (req, res) => {
  try {
    const userId = await requireMusicUser(req, res); if (!userId) return;
    const track = await get('SELECT id, url, yt_id FROM user_music_tracks WHERE id = ? AND user_id = ?', [req.params.id, userId]);
    if (!track) return res.status(404).json({ error: 'النغمة غير موجودة' });
    if (track.yt_id) cancelYtAudioRetry(track.yt_id);
    await run('DELETE FROM user_music_tracks WHERE id = ? AND user_id = ?', [req.params.id, userId]);
    const filePath = musicFilePath(track.url);
    if (filePath && fs.existsSync(filePath)) {
      // ملفات يوتيوب مشتركة بين المستخدمين: لا نحذفها ما دام مستخدم آخر يحتفظ بها
      const still = await get('SELECT id FROM user_music_tracks WHERE url = ? LIMIT 1', [track.url]);
      if (!still) { try { fs.unlinkSync(filePath); } catch (e) {} }
    }
    // مقطع يوتيوب: احذف أي نسخة له على الخادم (حتى لو بصيغة أخرى أو ما زال قيد التجهيز) ما لم يحتفظ به مستخدم آخر
    if (track.yt_id) {
      const keeper = await get('SELECT id FROM user_music_tracks WHERE yt_id = ? LIMIT 1', [track.yt_id]);
      if (!keeper) { try { ytMp3.reset(track.yt_id); } catch (e) {} purgeYtMediaFiles(track.yt_id); }
    }
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'تعذر حذف النغمة' });
  }
});

// 16. Moments Feed List
app.get('/api/moments', async (req, res) => {
  try {
    const currentUserId = req.headers['x-user-id'];
    const friendsOnly = req.query.scope === 'friends';
    if (friendsOnly && !currentUserId) return res.json([]);
    const moments = await all(`
      SELECT m.*, u.name as user_name, u.avatar as user_avatar, u.soul_planet, u.avatar_frame
      FROM moments m
      JOIN users u ON m.user_id = u.id
      ${friendsOnly ? 'WHERE m.user_id = ? OR m.user_id IN (SELECT following_id FROM follows WHERE follower_id = ?)' : ''}
      ORDER BY m.created_at DESC
      LIMIT 50
    `, friendsOnly ? [currentUserId, currentUserId] : []);

    // Fetch comments and check if current user liked
    for (const m of moments) {
      m.comments = await all(`
        SELECT c.*, u.name as user_name, u.avatar as user_avatar
        FROM moment_comments c
        JOIN users u ON c.user_id = u.id
        WHERE c.moment_id = ?
        ORDER BY c.created_at ASC
      `, [m.id]);

      if (currentUserId) {
        const liked = await get('SELECT 1 FROM moment_likes WHERE moment_id = ? AND user_id = ?', [m.id, currentUserId]);
        m.is_liked = !!liked;
      } else {
        m.is_liked = false;
      }
    }

    res.json(moments);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 17-yt. البحث في يوتيوب — يعمل بمفتاح YouTube Data API v3 إن وُجد، وإلا عبر بديل Innertube بدون مفتاح
const ytSearchCache = new Map(); // key -> { t, data }
const ytSearchHits = new Map();  // userId -> [timestamps]
const YT_CACHE_MS = 10 * 60 * 1000;

function decodeHtmlEntities(str) {
  return String(str || '')
    .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&#39;/g, "'")
    .replace(/&#(\d+);/g, (m, n) => String.fromCharCode(Number(n)));
}

async function getYoutubeApiKey() {
  if (process.env.YOUTUBE_API_KEY) return process.env.YOUTUBE_API_KEY;
  try {
    const row = await get(`SELECT value FROM app_settings WHERE key = 'youtube_api_key'`);
    if (row && row.value) return row.value;
  } catch (e) {}
  return null;
}

// ---- بحث يوتيوب بدون مفتاح: عدة طرق تعمل بالتوازي ويُعاد أول نتيجة ناجحة ----
function ytParseVideoRenderers(root, limit = 12) {
  const found = [];
  const seen = new Set();
  const walk = (node) => {
    if (found.length >= limit || !node || typeof node !== 'object') return;
    if (Array.isArray(node)) { for (const x of node) walk(x); return; }
    const vr = node.videoRenderer;
    if (vr && vr.videoId && !seen.has(vr.videoId)) {
      seen.add(vr.videoId);
      found.push({
        id: vr.videoId,
        title: decodeHtmlEntities(vr.title?.runs?.map(x => x.text).join('') || vr.title?.simpleText || ''),
        channel: decodeHtmlEntities(vr.ownerText?.runs?.map(x => x.text).join('') || vr.shortBylineText?.runs?.map(x => x.text).join('') || ''),
        thumbnail: `https://i.ytimg.com/vi/${vr.videoId}/mqdefault.jpg`,
        published_at: vr.publishedTimeText?.simpleText || ''
      });
    }
    for (const k of Object.keys(node)) { if (k !== 'videoRenderer') walk(node[k]); }
  };
  walk(root);
  return found;
}

const YT_COMMON_HEADERS = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
  'Accept-Language': 'ar,en-US;q=0.8,en;q=0.6',
  // تجاوز صفحة الموافقة (consent) التي تظهر لبعض الدول وتمنع النتائج
  'Cookie': 'SOCS=CAI; CONSENT=YES+1'
};

async function ytSearchInnertube(q, clientName, clientVersion, timeoutMs) {
  const r = await fetch('https://www.youtube.com/youtubei/v1/search?prettyPrint=false', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...YT_COMMON_HEADERS, 'Origin': 'https://www.youtube.com' },
    body: JSON.stringify({ context: { client: { clientName, clientVersion, hl: 'ar', gl: 'SA' } }, query: q }),
    signal: AbortSignal.timeout(timeoutMs)
  });
  if (!r.ok) throw new Error(`innertube ${clientName} status ${r.status}`);
  const items = ytParseVideoRenderers(await r.json());
  if (!items.length) throw new Error(`innertube ${clientName}: no results`);
  return { items, nextPageToken: null };
}

async function ytSearchHtml(q, timeoutMs) {
  const r = await fetch('https://www.youtube.com/results?hl=ar&search_query=' + encodeURIComponent(q), {
    headers: { ...YT_COMMON_HEADERS, 'Accept': 'text/html' },
    signal: AbortSignal.timeout(timeoutMs)
  });
  if (!r.ok) throw new Error('html status ' + r.status);
  const html = await r.text();
  const m = html.match(/var ytInitialData\s*=\s*(\{.+?\});<\/script>/s);
  if (!m) throw new Error('html: ytInitialData not found');
  const items = ytParseVideoRenderers(JSON.parse(m[1]));
  if (!items.length) throw new Error('html: no results');
  return { items, nextPageToken: null };
}

function ytSearchViaYtDlp(q, timeoutMs) {
  return new Promise((resolve, reject) => {
    const bin = findYtDlp();
    if (!bin) return reject(new Error('yt-dlp not installed'));
    const { execFile } = require('child_process');
    const args = ['--flat-playlist', '-J', '--no-warnings', ...ytDlpAuthArgs(), 'ytsearch12:' + q];
    execFile(bin, args, { timeout: timeoutMs, maxBuffer: 8 * 1024 * 1024 }, (err, out) => {
      if (err) return reject(new Error('yt-dlp search: ' + String(err.message).slice(0, 120)));
      try {
        const j = JSON.parse(out);
        const items = (j.entries || []).filter(e => e && e.id).slice(0, 12).map(e => ({
          id: e.id, title: e.title || '', channel: e.channel || e.uploader || '',
          thumbnail: `https://i.ytimg.com/vi/${e.id}/mqdefault.jpg`, published_at: ''
        }));
        if (!items.length) return reject(new Error('yt-dlp search: no results'));
        resolve({ items, nextPageToken: null });
      } catch (e) { reject(new Error('yt-dlp search: bad json')); }
    });
  });
}

// نسخ Invidious/Piped العامة كملاذ أخير (قد تتغير؛ يمكن تحديدها عبر YT_INVIDIOUS_INSTANCES مفصولة بفواصل)
async function ytSearchViaInvidious(q, timeoutMs) {
  const hosts = (process.env.YT_INVIDIOUS_INSTANCES || 'https://yewtu.be,https://inv.nadeko.net,https://invidious.nerdvpn.de')
    .split(',').map(x => x.trim()).filter(Boolean);
  const attempts = hosts.map(async (h) => {
    const r = await fetch(`${h}/api/v1/search?type=video&q=${encodeURIComponent(q)}`, { signal: AbortSignal.timeout(timeoutMs), headers: { 'User-Agent': YT_COMMON_HEADERS['User-Agent'] } });
    if (!r.ok) throw new Error(`invidious ${h} status ${r.status}`);
    const j = await r.json();
    const items = (Array.isArray(j) ? j : []).filter(v => v.type === 'video' && v.videoId).slice(0, 12).map(v => ({
      id: v.videoId, title: v.title || '', channel: v.author || '',
      thumbnail: `https://i.ytimg.com/vi/${v.videoId}/mqdefault.jpg`, published_at: v.publishedText || ''
    }));
    if (!items.length) throw new Error(`invidious ${h}: no results`);
    return { items, nextPageToken: null };
  });
  return Promise.any(attempts);
}

async function searchYoutubeViaInnertube(q, musicOnly) {
  const T = 8000;
  const strategies = [
    ['innertube-web', () => ytSearchInnertube(q, 'WEB', '2.20250101.00.00', T)],
    ['innertube-mweb', () => ytSearchInnertube(q, 'MWEB', '2.20250101.00.00', T)],
    ['html', () => ytSearchHtml(q, T)],
    ['yt-dlp', () => ytSearchViaYtDlp(q, 15000)],
    ['invidious', () => ytSearchViaInvidious(q, T)]
  ];
  const errors = [];
  const attempts = strategies.map(([name, fn]) => fn().then((r) => { r.source = name; return r; }, (e) => {
    errors.push(`${name}: ${e && e.message ? e.message : e}`);
    throw e;
  }));
  try {
    return await Promise.any(attempts);
  } catch (e) {
    // اطبع سبب فشل كل طريقة ليعرف المدير هل المشكلة شبكة محظورة أم حجب يوتيوب لعنوان الخادم
    console.error('YouTube search: all strategies failed ->', errors.join(' | '));
    throw new Error('all strategies failed');
  }
}

app.get('/api/youtube/search', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    if (!userId || !(await get('SELECT id FROM users WHERE id = ?', [userId]))) {
      return res.status(401).json({ success: false, error: 'Unauthorized' });
    }
    let apiKey = await getYoutubeApiKey();
    const q = String(req.query.q || '').trim().slice(0, 100);
    if (q.length < 2) return res.status(400).json({ success: false, error: 'اكتب كلمة بحث من حرفين على الأقل' });
    const pageToken = /^[A-Za-z0-9_-]{1,100}$/.test(String(req.query.pageToken || '')) ? String(req.query.pageToken) : '';

    // حد معقول للطلبات لحماية حصة المفتاح: 15 بحثاً في الدقيقة لكل مستخدم
    const now = Date.now();
    const hits = (ytSearchHits.get(userId) || []).filter(t => now - t < 60000);
    if (hits.length >= 15) return res.status(429).json({ success: false, error: 'عدد كبير من عمليات البحث، انتظر قليلاً ثم أعد المحاولة' });
    hits.push(now);
    ytSearchHits.set(userId, hits);

    const musicOnly = String(req.query.music || '') === '1';
    const cacheKey = `${q.toLowerCase()}|${pageToken}|${musicOnly ? 'm' : ''}|${apiKey ? 'key' : 'free'}`;
    const cached = ytSearchCache.get(cacheKey);
    if (cached && now - cached.t < YT_CACHE_MS) return res.json({ success: true, ...cached.data });

    let data = null;
    let usedFallback = false;

    if (apiKey) {
      // جرّب Official API أولاً
      try {
        const url = new URL('https://www.googleapis.com/youtube/v3/search');
        url.searchParams.set('part', 'snippet');
        url.searchParams.set('type', 'video');
        url.searchParams.set('maxResults', '12');
        url.searchParams.set('safeSearch', 'strict');
        url.searchParams.set('videoEmbeddable', 'true');
        url.searchParams.set('q', q);
        if (musicOnly) url.searchParams.set('videoCategoryId', '10');
        if (pageToken) url.searchParams.set('pageToken', pageToken);
        url.searchParams.set('key', apiKey);

        const r = await fetch(url, { signal: AbortSignal.timeout(8000) });
        const j = await r.json().catch(() => ({}));
        if (r.ok) {
          data = {
            items: (j.items || []).filter(it => it.id && it.id.videoId).map(it => ({
              id: it.id.videoId,
              title: decodeHtmlEntities(it.snippet.title),
              channel: decodeHtmlEntities(it.snippet.channelTitle),
              thumbnail: (it.snippet.thumbnails && ((it.snippet.thumbnails.medium || it.snippet.thumbnails.default) || {}).url) || '',
              published_at: it.snippet.publishedAt
            })),
            nextPageToken: j.nextPageToken || null
          };
        } else {
          const reason = j && j.error && j.error.errors && j.error.errors[0] && j.error.errors[0].reason;
          console.error('YouTube search error:', r.status, reason || (j.error && j.error.message));
          if (reason === 'quotaExceeded' || reason === 'dailyLimitExceeded') {
            // الحصة انتهت — تحوّل تلقائياً إلى البديل المجاني
            console.log('Quota exceeded, switching to fallback');
          } else if (r.status === 400 || r.status === 403) {
            // مفتاح غير صالح — جرّب البديل بدل إظهار خطأ للعميل
            console.log('API key invalid, trying fallback');
          } else {
            return res.status(502).json({ success: false, error: 'تعذر البحث في يوتيوب حالياً' });
          }
          // سننتقل إلى Fallback أدناه
        }
      } catch (err) {
        console.error('Official API fetch failed, trying fallback:', err.message);
      }
    }

    if (!data) {
      // جرّب البديل المجاني
      try {
        const fb = await searchYoutubeViaInnertube(q, musicOnly);
        data = fb;
        usedFallback = true;
      } catch (err) {
        console.error('Fallback search failed:', err.message);
        if (apiKey) {
          // كان لدينا مفتاح لكنه فشل والبديل فشل أيضاً
          return res.status(502).json({ success: false, error: 'تعذر البحث في يوتيوب حالياً، حاول مرة أخرى' });
        } else {
          // بدون مفتاح والبديل فشل (مثلاً الشبكة محظورة في البيئة المحلية) — أعد رسالة واضحة مع السماح باللصق المباشر
          return res.status(503).json({ success: false, code: 'NO_KEY', fallback_direct: true, error: 'تعذر الاتصال بخدمة البحث حالياً. يمكنك لصق رابط يوتيوب مباشرة، أو على مدير الخادم إضافة YOUTUBE_API_KEY لتفعيل البحث.' });
        }
      }
    }

    if (!data.items.length) {
      // لا نتائج — لا نعتبره خطأ
    }
    if (ytSearchCache.size > 200) ytSearchCache.delete(ytSearchCache.keys().next().value);
    ytSearchCache.set(cacheKey, { t: now, data });
    res.json({ success: true, items: data.items, nextPageToken: data.nextPageToken || null, via: usedFallback ? 'fallback' : 'api', source: data.source || 'api' });
  } catch (err) {
    console.error('youtube search outer error:', err);
    res.status(500).json({ success: false, error: 'تعذر البحث في يوتيوب حالياً' });
  }
});

// إعداد مفتاح يوتيوب من لوحة الإدارة (يُحفظ في app_settings ويُستخدم فوراً بدون إعادة تشغيل)

// ── تشغيل يوتيوب كمقطع صوتي مخفي (للموسيقى في الغرف) — يعيد رابط صوت مباشر عبر Innertube ──
// استخراج رابط الصوت: 1) yt-dlp إن كان مثبتاً (الأكثر موثوقية)  2) عدة عملاء Innertube بترويسات مطابقة
let _ytdlpBin; // undefined=لم يُفحص، null=غير موجود
const YTDLP_LOCAL = path.join(__dirname, 'bin', process.platform === 'win32' ? 'yt-dlp.exe' : 'yt-dlp');
// كوكيز يوتيوب: تُقرأ ديناميكياً من data/yt-cookies*.txt (التي ترفعها لوحة الإدارة) أو cookies.txt
// أو bin/cookies.txt أو YTDLP_COOKIES — بدون إعادة تشغيل، ويمكن تدوير عدة حسابات.
const YT_COOKIES_STORE = require('./yt-cookies');
function listYtCookieFiles() { return YT_COOKIES_STORE.listCookieFiles(__dirname); }
(function announceYtCookies() {
  const files = listYtCookieFiles();
  if (files.length) console.log('🍪 yt-dlp cookies:', files.map(f => path.relative(__dirname, f)).join(' | '));
  else console.log('🍪 yt-dlp cookies: لا يوجد — أضفها من لوحة الإدارة ← إعدادات يوتيوب ← كوكيز يوتيوب');
})();
function findYtDlp() {
  if (_ytdlpBin !== undefined) return _ytdlpBin;
  const { spawnSync } = require('child_process');
  for (const bin of [process.env.YTDLP_PATH, YTDLP_LOCAL, 'yt-dlp', 'yt-dlp.exe'].filter(Boolean)) {
    try { const r = spawnSync(bin, ['--version'], { timeout: 5000 }); if (r.status === 0) { _ytdlpBin = bin; return bin; } } catch (e) {}
  }
  _ytdlpBin = null; return null;
}
// تحميل yt-dlp تلقائياً (مرة واحدة) إلى ./bin إذا لم يكن مثبتاً — يعمل على Windows/Linux/macOS
// يحاول ثلاث طرق بالترتيب: ملف GitHub التنفيذي ← وحدة بايثون موجودة ← pip install (PyPI)
let _ytdlpInstalling = null;
let _ytdlpFailAt = 0; // لا نعيد محاولة تثبيت yt-dlp قبل مرور 10 دقائق بعد فشل
function pythonCmd() {
  for (const py of [process.env.PYTHON_PATH, 'python3', 'python'].filter(Boolean)) {
    try {
      const { spawnSync } = require('child_process');
      const r = spawnSync(py, ['--version'], { timeout: 8000 });
      if (r.status === 0) return py;
    } catch (e) { /* جرّب التالي */ }
  }
  return null;
}
function pythonHasYtDlp(py) {
  if (!py) return false;
  try {
    const { spawnSync } = require('child_process');
    const r = spawnSync(py, ['-m', 'yt_dlp', '--version'], { timeout: 20000 });
    return r.status === 0;
  } catch (e) { return false; }
}
function writeYtDlpPythonWrapper(py) {
  fs.mkdirSync(path.dirname(YTDLP_LOCAL), { recursive: true });
  fs.writeFileSync(YTDLP_LOCAL, '#!/bin/sh\nexec ' + py + ' -m yt_dlp "$@"\n', { mode: 0o755 });
  try { fs.chmodSync(YTDLP_LOCAL, 0o755); } catch (e) { /* Windows */ }
  _ytdlpBin = undefined;
}
function runSilently(bin, args, timeout) {
  return new Promise((resolve) => {
    try {
      const { execFile } = require('child_process');
      execFile(bin, args, { timeout, maxBuffer: 4 * 1024 * 1024 }, (err, so, se) => resolve({ err, out: String(so || ''), se: String(se || '') }));
    } catch (e) { resolve({ err: e }); }
  });
}
function ensureYtDlp() {
  if (findYtDlp()) return Promise.resolve(true);
  if (_ytdlpInstalling) return _ytdlpInstalling;
  // فشل قريب؟ لا نكرر محاولة تثبيت طويلة مع كل أغنية — ننتظر 10 دقائق
  if (_ytdlpFailAt && Date.now() - _ytdlpFailAt < 10 * 60 * 1000) return Promise.resolve(false);
  const file = process.platform === 'win32' ? 'yt-dlp.exe' : process.platform === 'darwin' ? 'yt-dlp_macos' : (process.arch === 'arm64' ? 'yt-dlp_linux_aarch64' : 'yt-dlp_linux');
  _ytdlpInstalling = (async () => {
    let ok = false;
    // 1) الملف التنفيذي من GitHub
    try {
      console.log('yt-dlp غير موجود — جارٍ تحميله تلقائياً…');
      const r = await fetch('https://github.com/yt-dlp/yt-dlp/releases/latest/download/' + file, { redirect: 'follow', signal: AbortSignal.timeout(120000) });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const buf = Buffer.from(await r.arrayBuffer());
      if (buf.length < 1e6) throw new Error('ملف غير صالح');
      fs.mkdirSync(path.dirname(YTDLP_LOCAL), { recursive: true });
      fs.writeFileSync(YTDLP_LOCAL, buf, { mode: 0o755 });
      _ytdlpBin = undefined;
      ok = !!findYtDlp();
      console.log(ok ? 'yt-dlp جاهز: ' + YTDLP_LOCAL : 'yt-dlp: فشل التشغيل بعد التحميل');
    } catch (e) {
      console.error('yt-dlp GitHub download failed:', e.message);
    }

    if (!ok && process.platform !== 'win32') {
      // 2) وحدة yt_dlp مثبتة مسبقاً عبر pip على الخادم
      const py = pythonCmd();
      if (py && pythonHasYtDlp(py)) {
        console.log('yt-dlp: استخدام وحدة بايثون الموجودة (' + py + ' -m yt_dlp)');
        writeYtDlpPythonWrapper(py);
        ok = !!findYtDlp();
      }
      if (!ok && py) {
        // 3) pip --user (قد ترفضه بعض التوزيعات بسبب externally-managed-environment)
        console.log('yt-dlp: محاولة التثبيت عبر pip…');
        const r = await runSilently(py, ['-m', 'pip', 'install', '--user', '--upgrade', '--quiet', 'yt-dlp'], 300000);
        if (!r.err && pythonHasYtDlp(py)) {
          console.log('yt-dlp: تم التثبيت عبر pip بنجاح');
          writeYtDlpPythonWrapper(py);
          ok = !!findYtDlp();
        }
      }
      if (!ok && py) {
        // 4) بيئة بايثون معزولة داخل bin/ (تتجاوز قيد externally-managed دون لمس حزم النظام)
        console.log('yt-dlp: محاولة التثبيت داخل بيئة معزولة (venv)…');
        try {
          const venvDir = path.join(__dirname, 'bin', 'ytdlp-venv');
          const vpy = path.join(venvDir, 'bin', 'python');
          if (!fs.existsSync(vpy)) await runSilently(py, ['-m', 'venv', venvDir], 180000);
          if (fs.existsSync(vpy)) {
            const rv = await runSilently(vpy, ['-m', 'pip', 'install', '--quiet', '--upgrade', 'yt-dlp'], 300000);
            if (!rv.err && pythonHasYtDlp(vpy)) {
              console.log('yt-dlp: تم التثبيت في بيئة معزولة: ' + venvDir);
              writeYtDlpPythonWrapper(vpy);
              ok = !!findYtDlp();
            } else {
              const detail = String(rv.se || (rv.err && rv.err.message) || '').trim().split('\n').slice(-3).join(' ').slice(0, 200);
              console.error('yt-dlp venv install failed:', detail || 'غير متاح');
            }
          } else {
            console.error('yt-dlp venv: python3-venv غير متاح (apt install python3-venv)');
          }
        } catch (e) { console.error('yt-dlp venv error:', e.message); }
      }
      if (!ok && py) {
        // 5) الملاذ الأخير: تثبيت على مستوى النظام مع --break-system-packages
        console.log('yt-dlp: محاولة أخيرة عبر pip --break-system-packages…');
        const rb = await runSilently(py, ['-m', 'pip', 'install', '--user', '--upgrade', '--quiet', '--break-system-packages', 'yt-dlp'], 300000);
        if (!rb.err && pythonHasYtDlp(py)) {
          console.log('yt-dlp: تم التثبيت عبر pip (--break-system-packages)');
          writeYtDlpPythonWrapper(py);
          ok = !!findYtDlp();
        } else {
          const detail = String(rb.se || (rb.err && rb.err.message) || '').trim().slice(0, 200);
          if (detail) console.error('yt-dlp pip آخر محاولة:', detail);
        }
      }
    }
    if (!ok) console.error('yt-dlp غير متاح — حمّله يدوياً من github.com/yt-dlp/yt-dlp/releases وضعه في مجلد bin، أو ثبّته بالأمر: python3 -m pip install yt-dlp');
    return ok;
  })().then((ok) => { _ytdlpFailAt = ok ? 0 : Date.now(); return ok; })
    .finally(() => { _ytdlpInstalling = null; });
  return _ytdlpInstalling;
}
setTimeout(() => { ensureYtDlp(); }, 1500);

function ytDlpAuthArgs(cookieFile) {
  const args = [];
  if (process.env.YTDLP_PROXY) args.push('--proxy', process.env.YTDLP_PROXY);
  let ck = cookieFile;
  if (!ck) {
    const files = listYtCookieFiles();
    ck = files[0] || '';
  }
  if (ck) args.push('--cookies', ck);
  else if (process.env.YTDLP_COOKIES_FROM_BROWSER) args.push('--cookies-from-browser', process.env.YTDLP_COOKIES_FROM_BROWSER);
  return args;
}
function ytDlpAudioUrl(videoId) {
  return new Promise((resolve, reject) => {
    const bin = findYtDlp(); if (!bin) return reject(new Error('yt-dlp not installed'));
    const { execFile } = require('child_process');
    // هذا المسار للتشغيل المباشر فقط. مرّر له إعدادات البروكسي/الكوكيز نفسها المستخدمة في التنزيل.
    const args = ['-f', 'bestaudio[ext=m4a]/bestaudio', '-g', '--no-playlist', '--no-warnings', '--js-runtimes', 'node',
      ...ytDlpAuthArgs(), 'https://www.youtube.com/watch?v=' + videoId];
    execFile(bin, args, { timeout: 25000, maxBuffer: 2 * 1024 * 1024 }, (err, out, stderr) => {
      const url = String(out || '').trim().split('\n')[0];
      if (err || !/^https?:\/\//.test(url)) {
        const detail = String(stderr || (err && err.message) || 'no url').replace(/\s+/g, ' ').slice(0, 240);
        return reject(new Error('yt-dlp: ' + detail));
      }
      resolve({ url, ua: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36', duration: 0, title: '' });
    });
  });
}
const YT_CLIENTS = [
  { ua: 'com.google.android.apps.youtube.vr.oculus/1.60.19 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip',
    client: { clientName: 'ANDROID_VR', clientVersion: '1.60.19', deviceMake: 'Oculus', deviceModel: 'Quest 3', osName: 'Android', osVersion: '12L', androidSdkVersion: 32, hl: 'en', gl: 'US' } },
  { ua: 'com.google.ios.youtube/19.45.4 (iPhone16,2; U; CPU iOS 18_1_0 like Mac OS X;)',
    client: { clientName: 'IOS', clientVersion: '19.45.4', deviceMake: 'Apple', deviceModel: 'iPhone16,2', osName: 'iPhone', osVersion: '18.1.0.22B83', hl: 'en', gl: 'US' } },
  { ua: 'Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version', embed: true, id: '85',
    client: { clientName: 'TVHTML5_SIMPLY_EMBEDDED_PLAYER', clientVersion: '2.0', hl: 'en', gl: 'US' } },
  { ua: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36', embed: true, id: '56',
    client: { clientName: 'WEB_EMBEDDED_PLAYER', clientVersion: '1.20250101.01.00', hl: 'en', gl: 'US' } },
  { ua: 'com.google.android.youtube/20.10.38 (Linux; U; Android 14) gzip',
    client: { clientName: 'ANDROID', clientVersion: '20.10.38', androidSdkVersion: 34, osName: 'Android', osVersion: '14', hl: 'en', gl: 'US' } }
];
async function innertubeCandidates(videoId) {
  const errs = [], out = [];
  for (const c of YT_CLIENTS) {
    const name = c.client.clientName;
    try {
      const ids = { IOS: '5', ANDROID_VR: '28', ANDROID: '3' };
      const body = { context: { client: c.client }, videoId, contentCheckOk: true, racyCheckOk: true };
      if (c.embed) body.context.thirdParty = { embedUrl: 'https://www.youtube.com/watch?v=' + videoId };
      const r = await fetch('https://www.youtube.com/youtubei/v1/player?prettyPrint=false', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'User-Agent': c.ua, 'X-YouTube-Client-Name': c.id || ids[name] || '3', 'X-YouTube-Client-Version': c.client.clientVersion, 'Origin': 'https://www.youtube.com' },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(9000)
      });
      if (!r.ok) { errs.push(name + ' HTTP ' + r.status); continue; }
      const j = await r.json();
      const sd = j.streamingData;
      if (!sd) { errs.push(name + ': ' + (j.playabilityStatus?.reason || j.playabilityStatus?.status || 'no streamingData')); continue; }
      const audios = [...(sd.adaptiveFormats || []), ...(sd.formats || [])].filter(f => (f.mimeType || '').startsWith('audio/') && f.url);
      if (!audios.length) { errs.push(name + ': no direct url (needs signature)'); continue; }
      audios.sort((x, y) => ((y.mimeType.includes('mp4') ? 1e7 : 0) + (y.bitrate || 0)) - ((x.mimeType.includes('mp4') ? 1e7 : 0) + (x.bitrate || 0)));
      out.push({ url: audios[0].url, ua: c.ua, client: name, size: Number(audios[0].contentLength || 0), bitrate: Number(audios[0].averageBitrate || audios[0].bitrate || 0), durationMs: Number(audios[0].approxDurationMs || (Number(j.videoDetails?.lengthSeconds || 0) * 1000)), duration: Number(j.videoDetails?.lengthSeconds || 0), title: j.videoDetails?.title || '' });
    } catch (e) { errs.push(name + ': ' + (e.cause?.code || e.message)); }
  }
  out.errors = errs;
  return out;
}
async function innertubeAudioUrl(videoId) {
  const c = await innertubeCandidates(videoId);
  if (!c.length) throw new Error(c.errors.join(' || '));
  return c[0];
}
async function getYoutubeAudioUrl(videoId) {
  const errs = [];
  if (findYtDlp()) { try { return await ytDlpAudioUrl(videoId); } catch (e) { errs.push(e.message); } }
  try { return await innertubeAudioUrl(videoId); } catch (e) { errs.push(e.message); }
  const err = new Error(errs.join(' | ')); throw err;
}

app.get('/api/youtube/audio/:videoId', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    if (!userId || !(await get('SELECT id FROM users WHERE id = ?', [userId]))) {
      return res.status(401).json({ success: false, error: 'Unauthorized' });
    }
    const videoId = String(req.params.videoId || '').trim();
    if (!/^[A-Za-z0-9_-]{11}$/.test(videoId)) return res.status(400).json({ success: false, error: 'معرّف فيديو غير صالح' });
    // حماية بسيطة من الإغراق
    const now = Date.now();
    const hits = (ytSearchHits.get(userId) || []).filter(t => now - t < 60000);
    if (hits.length >= 20) return res.status(429).json({ success: false, error: 'عدد كبير من الطلبات' });
    hits.push(now);
    ytSearchHits.set(userId, hits);

    const data = await getYoutubeAudioUrl(videoId);
    res.json({ success: true, ...data });
  } catch (err) {
    // هذا المسار خاص بجلب رابط تشغيل مباشر؛ حفظ MP3 يعمل في /api/music-library بشكل منفصل.
    console.error('youtube audio playback error:', err.message);
    res.status(502).json({ success: false, error: 'تعذر جلب رابط الصوت المباشر؛ قد يحجب يوتيوب خادم الموقع.' });
  }
});

// ── بروكسي صوت يوتيوب (نفس النطاق) ──
// يجعل الصوت من نفس أصل الموقع فيستطيع المتصفح التقاطه عبر WebAudio ودمجه في ميكرفون المقعد
// (الرابط المباشر من googlevideo لا يدعم CORS فكان يفشل ويسقط إلى مشغّل iframe الذي لا يمكن بثّه).
const ytAudioUrlCache = new Map(); // videoId -> { url, ua, total, mime, exp }
const YT_CHUNK = 4 * 1024 * 1024;
function ytChunkFetch(cand, from, to) {
  const u = new URL(cand.url); if (!cand.noOrigin) u.searchParams.set('range', from + '-' + to);
  const hdr = { 'User-Agent': cand.ua || 'Mozilla/5.0', 'Range': 'bytes=' + from + '-' + to };
  if (!cand.noOrigin) { hdr['Origin'] = 'https://www.youtube.com'; hdr['Referer'] = 'https://www.youtube.com/'; }
  return fetch(u.toString(), { headers: hdr, signal: AbortSignal.timeout(20000) });
}
// يفحص كل رابط مرشّح: بداية الملف + منتصفه (روابط بعض العملاء تُقبل في البداية ثم تعطي 403 لاحقاً بدون PO token)
// ويعيد قائمة بكل الروابط الصالحة بالترتيب، ليجرّب المحمّل التالي منها إذا رُفض الأول أثناء التحميل.
async function resolveYtStream(videoId) {
  const cands = [];
  if (findYtDlp()) { try { cands.push(await ytDlpAudioUrl(videoId)); } catch (e) { cands.errors = [e.message]; } }
  let it = [];
  try { it = await innertubeCandidates(videoId); } catch (e) {}
  cands.push(...it);
  try { cands.push(...await pipedCandidates(videoId)); } catch (e) {}
  const errs = [...(cands.errors || []), ...(it.errors || [])];
  const good = [];
  for (const c of cands) {
    const nm = c.client || 'yt-dlp';
    try {
      const r = await ytChunkFetch(c, 0, 1023);
      if (!(r.status === 200 || r.status === 206)) { errs.push(nm + ' download HTTP ' + r.status); try { await r.arrayBuffer(); } catch (e) {} continue; }
      const cr = r.headers.get('content-range') || '';
      const total = Number(new URL(c.url).searchParams.get('clen') || 0) || c.size || Number(cr.split('/')[1] || 0) || 0;
      const mime = r.headers.get('content-type') || 'audio/mp4';
      try { await r.arrayBuffer(); } catch (e) {}
      const expected = c.bitrate && c.durationMs ? (c.bitrate * c.durationMs) / 8000 : 0;
      if (!(total > 0)) { errs.push(nm + ': unknown size'); continue; }
      if (expected && total < expected * 0.3) { errs.push(nm + ': size too small (' + total + ' vs ~' + Math.round(expected) + ')'); continue; }
      // فحص عميق: دفعة بعد أول ~3MB وأخرى قرب النهاية
      let deepOk = true;
      for (const off of [Math.min(3 * 1024 * 1024, total - 1025), total - 1025]) {
        if (off <= 1024) continue;
        const d = await ytChunkFetch(c, off, off + 1023);
        try { await d.arrayBuffer(); } catch (e) {}
        if ([401, 403, 410].includes(d.status)) { errs.push(nm + ' deep-probe HTTP ' + d.status + ' @' + off); deepOk = false; break; }
      }
      if (!deepOk) continue;
      good.push({ url: c.url, ua: c.ua, total, mime, client: nm });
    } catch (e) { errs.push(nm + ' download: ' + (e.cause?.code || e.message)); }
  }
  if (!good.length) throw new Error(errs.join(' || ') || 'no candidates');
  return good;
}
// ملاذ أخير: yt-dlp يحمّل الملف بنفسه إلى مجلد الكاش
// بدون كوكيز: نجرّب عدة عملاء يوتيوب (بعضها لا يطلب تسجيل دخول)، ويدعم بروكسي اختياري YTDLP_PROXY
const YTDLP_CLIENT_SETS = [
  'youtube:player_client=tv_simply,tv_embedded',
  'youtube:player_client=web_embedded,mweb',
  'youtube:player_client=android_vr',
  'youtube:player_client=web_safari,tv',
  ''
];
async function ytDlpDownloadFile(videoId, cacheDir) {
  await ensureYtDlp();
  const bin = findYtDlp(); if (!bin) throw new Error('yt-dlp not installed');
  const { execFile } = require('child_process');
  const base = path.join(cacheDir, videoId);
  const errs = [];
  const cookiess = listYtCookieFiles();
  const cookieOrder = cookiess.length ? cookiess : [''];
  for (const ck of cookieOrder) {
    for (const ex of YTDLP_CLIENT_SETS) {
      const args = ['-f', 'bestaudio[ext=m4a]/bestaudio[ext=webm]/bestaudio', '--no-playlist', '--no-warnings', '--no-part',
        '--retries', '4', '--socket-timeout', '20',
        ...ytDlpAuthArgs(ck || undefined), '-o', base + '.%(ext)s'];
      if (ex) args.push('--extractor-args', ex);
      args.push('https://www.youtube.com/watch?v=' + videoId);
      const found = await new Promise((resolve) => {
        execFile(bin, args, { timeout: 90000 }, (err, so, se) => {
          for (const e2 of ['m4a', 'webm']) { const f = base + '.' + e2; try { if (fs.statSync(f).size > 0) return resolve(f); } catch (e) {} }
          errs.push((ck ? path.basename(ck) : 'no-cookie') + '/' + (ex || 'default') + ': ' + String(se || (err && err.message) || 'no file').trim().slice(-120));
          resolve(null);
        });
      });
      if (found) return found;
    }
  }
  throw new Error(errs.join(' | ').slice(0, 500));
}

// بدائل Piped: خوادم عامة تجلب الصوت من يوتيوب بدلاً منا (لا كوكيز ولا IP خادمك). يمكن تعديل القائمة عبر PIPED_INSTANCES
const PIPED_INSTANCES = (process.env.PIPED_INSTANCES || 'https://pipedapi.kavin.rocks,https://pipedapi.adminforge.de,https://api.piped.private.coffee,https://pipedapi.leptons.xyz').split(',').map(x => x.trim().replace(/\/$/, '')).filter(Boolean);
async function pipedCandidates(videoId) {
  const out = [];
  for (const base of PIPED_INSTANCES) {
    try {
      const r = await fetch(base + '/streams/' + videoId, { headers: { 'User-Agent': 'Mozilla/5.0' }, signal: AbortSignal.timeout(8000) });
      if (!r.ok) continue;
      const j = await r.json();
      const audios = (j.audioStreams || []).filter(a => a.url && !a.videoOnly);
      if (!audios.length) continue;
      audios.sort((x, y) => ((/mp4/.test(y.mimeType || '') ? 1e7 : 0) + (y.bitrate || 0)) - ((/mp4/.test(x.mimeType || '') ? 1e7 : 0) + (x.bitrate || 0)));
      for (const a of audios.slice(0, 2)) {
        out.push({ url: a.url, ua: 'Mozilla/5.0', client: 'piped', size: Number(a.contentLength || 0), bitrate: 0, durationMs: 0, noOrigin: true });
      }
      if (out.length) break;
    } catch (e) { /* جرّب المثيل التالي */ }
  }
  return out;
}

const ytDiskStream = require('./yt-stream').createYtStream({
  resolve: resolveYtStream,
  fetchChunk: ytChunkFetch,
  fallbackDownload: ytDlpDownloadFile,
  cacheDir: path.join(__dirname, 'cache', 'yt')
});

// حفظ أغنية يوتيوب كملف MP3 صغير (أقل جودة = أسرع تحميل) ثم تشغيلها كمقطع صوتي عادي
const ytMp3 = require('./yt-mp3-saver').createYtMp3Saver({
  ensureYtDlp, findYtDlp,
  outDir: path.join(__dirname, 'public', 'uploads'),
  clientSets: YTDLP_CLIENT_SETS,
  cookieFiles: listYtCookieFiles,           // تدوير عدة حسابات/ملفات كوكيز تلقائياً
  concurrency: Number(process.env.YT_MP3_CONCURRENCY || 3),
  // بديل عند فشل yt-dlp: عملاء Innertube (قد تعمل من خوادم لا تقبل yt-dlp)
  altSource: (id) => ytDiskStream.ensure(id, false, { skipFallback: true })
});
// ── مهام تحويل يوتيوب إلى MP3: إعادة محاولة تلقائية متعددة المراحل بدل الفشل من أول مرة ──
const YT_AUDIO_MAX_TRIES = Math.max(1, Number(process.env.YT_AUDIO_MAX_TRIES || 8));
const YT_AUDIO_RETRY_BASE_MS = Math.max(5000, Number(process.env.YT_AUDIO_RETRY_MS || 60000));
const ytAudioRetryTimers = new Map(); // ytId -> Timer

function ytAudioErrorMessage(e) {
  if (!e) return 'تعذر تجهيز MP3';
  if (e.code === 'no-ffmpeg') return 'الخادم بحاجة إلى ffmpeg لتجهيز MP3 — ثبّته ثم اضغط إعادة';
  if (e.code === 'too-long') return String(e.message || 'المقطع أطول من الحد المسموح').slice(0, 220);
  if (e.code === 'unavailable') return 'المقطع غير متاح (خاص/محذوف/مقيّد) — جرّب مقطعاً آخر';
  if (e.botBlock) return 'يوتيوب يطلب تحقق/تسجيل دخول للخادم — أضف كوكيز من لوحة الإدارة (إعدادات يوتيوب)';
  return String(e.message || 'تعذر تجهيز MP3').slice(0, 220);
}
function cancelYtAudioRetry(ytId) {
  const t = ytAudioRetryTimers.get(ytId);
  if (t) { clearTimeout(t); ytAudioRetryTimers.delete(ytId); }
}
function scheduleYtAudioRetry(ytId, attempt) {
  if (ytAudioRetryTimers.has(ytId) || !ytId) return;
  const delay = Math.min(30 * 60 * 1000, YT_AUDIO_RETRY_BASE_MS * Math.pow(2, Math.max(0, attempt - 1)));
  const timer = setTimeout(() => {
    ytAudioRetryTimers.delete(ytId);
    startYtAudioJob(ytId, attempt + 1);
  }, delay);
  if (timer.unref) timer.unref();
  ytAudioRetryTimers.set(ytId, timer);
  console.log('🔁 إعادة محاولة تجهيز MP3 بعد', Math.round(delay / 1000), 'ثانية —', ytId, 'محاولة', attempt + 1);
}

function startYtAudioJob(ytId, attempt = 1) {
  if (!ytId) return;
  ytMp3.queue(ytId).then(async (r) => {
    cancelYtAudioRetry(ytId);
    await run(`UPDATE user_music_tracks SET source = 'device', url = ?, file_name = ?, audio_status = 'ready', audio_error = '', audio_attempts = ? WHERE yt_id = ? AND audio_status != 'ready'`,
      [r.url, path.basename(r.file), attempt, ytId]);
    console.log('🎵 yt audio ready:', ytId, r.format);
    // حُذف المقطع من كل الحسابات أثناء التجهيز ← احذف الملف الناتج حتى لا يبقى يتيماً على الخادم
    try { const left = await get('SELECT id FROM user_music_tracks WHERE yt_id = ? LIMIT 1', [ytId]); if (!left) purgeYtMediaFiles(ytId); } catch (x) {}
  }).catch(async (e) => {
    const msg = ytAudioErrorMessage(e);
    console.error('yt audio job failed:', ytId, 'attempt', attempt, e.message);
    try { await run(`UPDATE user_music_tracks SET audio_error = ?, audio_attempts = ? WHERE yt_id = ?`, [msg, attempt, ytId]); } catch (x) {}
    if (!e.permanent && attempt < YT_AUDIO_MAX_TRIES) {
      // نُبقي الحالة processing ونعيد المحاولة تلقائياً بتأخير متزايد (غالباً الحجب مؤقت أو الكوكيز تحتاج تحديثاً)
      scheduleYtAudioRetry(ytId, attempt);
    } else {
      try { await run(`UPDATE user_music_tracks SET audio_status = 'failed' WHERE yt_id = ? AND audio_status = 'processing'`, [ytId]); } catch (x) {}
    }
  });
}
app.get('/api/youtube/stream/:videoId', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'] || req.query.uid;
    if (!userId || !(await get('SELECT id FROM users WHERE id = ?', [userId]))) return res.status(401).end();
    const videoId = String(req.params.videoId || '').trim();
    if (!/^[A-Za-z0-9_-]{11}$/.test(videoId)) return res.status(400).end();
    await ytDiskStream.handle(req, res, videoId, { fresh: req.query.fresh === '1' });
  } catch (err) {
    console.error('youtube stream route error:', err.message);
    if (!res.headersSent) res.status(502).json({ success: false, error: String(err.message || 'فشل جلب الصوت').slice(0, 300) });
  }
});

app.get('/api/admin/youtube-key', async (req, res) => {

  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const key = await getYoutubeApiKey();
    res.json({ success: true, has_key: !!key, preview: key ? (key.slice(0, 6) + '...' + key.slice(-4)) : '' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});
app.post('/api/admin/youtube-key', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const key = String(req.body.key || '').trim();
    if (key && !/^AIza[0-9A-Za-z_\-]{30,}$/.test(key)) return res.status(400).json({ error: 'مفتاح YouTube غير صالح (يجب أن يبدأ بـ AIza…)' });
    if (key) {
      await run(`INSERT INTO app_settings (key, value) VALUES ('youtube_api_key', ?)\n        ON CONFLICT(key) DO UPDATE SET value = excluded.value`, [key]);
      ytSearchCache.clear();
    } else {
      await run(`DELETE FROM app_settings WHERE key = 'youtube_api_key'`);
      ytSearchCache.clear();
    }
    res.json({ success: true, has_key: !!key });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ═══════════════════════════════════════════════════════════════════════════
// إدارة كوكيز يوتيوب وتشخيص محرك تحويل MP3 (بدون إعادة تشغيل الخادم)
// الكوكيز تُكتب في data/ (مستثناة من git) بصلاحيات 600 ولا تُعاد أبداً للواجهة.
// ═══════════════════════════════════════════════════════════════════════════

function ytCookieStatusPayload() {
  const files = YT_COOKIES_STORE.describeAll(__dirname);
  return { files, active: files.length ? files[0].name : '', count: files.length, dir: 'data/' };
}

app.get('/api/admin/youtube-cookies', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try { res.json({ success: true, ...ytCookieStatusPayload() }); }
  catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/admin/youtube-cookies', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const body = req.body || {};
    const text = String(body.cookies || body.text || '');
    if (text.length > 512 * 1024) return res.status(413).json({ error: 'الملف كبير جداً (الحد 512KB)' });
    const saved = YT_COOKIES_STORE.saveCookieFile(__dirname, text, body.name);
    console.log('🍪 تم حفظ كوكيز يوتيوب من لوحة الإدارة:', saved.name, '— يوتيوب:', saved.info.youtube, 'جلسة:', saved.info.login);
    res.json({
      success: true,
      file: saved.description,
      warning: saved.info.login ? '' : 'الكوكيز لا تحتوي SID/LOGIN_INFO — يبدو أنها ليست من جلسة مسجّلة، وقد لا تكفي لتجاوز حجب يوتيوب.',
      ...ytCookieStatusPayload()
    });
  } catch (err) {
    res.status(400).json({ error: err.message || 'تعذر حفظ الكوكيز' });
  }
});

app.delete('/api/admin/youtube-cookies/:name', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    YT_COOKIES_STORE.deleteCookieFile(__dirname, req.params.name);
    console.log('🍪 تم حذف كوكيز يوتيوب:', req.params.name);
    res.json({ success: true, ...ytCookieStatusPayload() });
  } catch (err) {
    res.status(400).json({ error: err.message || 'تعذر حذف الملف' });
  }
});

// اختبار حقيقي: يشغّل yt-dlp بوضع --simulate على مقطع قصير مع كل ملف كوكيز
function ytDlpProbeOnce(bin, videoId, cookieFile, extractor) {
  const { execFile } = require('child_process');
  return new Promise((resolve) => {
    const args = ['--simulate', '--no-playlist', '--no-warnings', '--no-progress', '--skip-download',
      '--print', '%(title)s|%(duration)s|%(uploader)s', '-f', 'worstaudio/bestaudio',
      ...ytDlpAuthArgs(cookieFile || undefined)];
    if (extractor) args.push('--extractor-args', extractor);
    args.push('https://www.youtube.com/watch?v=' + videoId);
    execFile(bin, args, { timeout: 30000, maxBuffer: 2 * 1024 * 1024 }, (err, so, se) => {
      resolve({ err, out: String(so || '').trim(), se: String(se || '').trim() });
    });
  });
}

async function ytDlpProbe(videoId) {
  await ensureYtDlp();
  const bin = findYtDlp();
  if (!bin) return { success: false, error: 'yt-dlp غير مثبت على الخادم ولا يمكن تحميله تلقائياً' };
  const cookieFiles = listYtCookieFiles();
  const cookieOrder = cookieFiles.length ? cookieFiles.slice(0, 3) : [''];
  const clients = [...YTDLP_CLIENT_SETS].slice(0, 3);
  const errs = [];
  for (const ck of cookieOrder) {
    for (const ex of clients) {
      const r = await ytDlpProbeOnce(bin, videoId, ck, ex);
      if (!r.err && r.out) {
        const [title, duration, uploader] = r.out.split('|');
        return {
          success: true, title: title || '', duration: Number(duration) || 0, uploader: uploader || '',
          cookie: ck ? path.basename(ck) : 'بدون كوكيز', client: ex || 'default',
          message: 'يعمل ✅ — هذا يعني أن الخادم يستطيع تنزيل الصوت من يوتيوب الآن'
        };
      }
      errs.push((ck ? path.basename(ck) : 'بدون كوكيز') + '/' + (ex || 'default') + ': ' +
        (r.se || (r.err && r.err.message) || 'فشل').replace(/\s+/g, ' ').slice(0, 240));
    }
  }
  const joined = errs.join(' | ');
  let reason = 'فشل اختبار التنزيل';
  if (/not a bot|sign in|login/i.test(joined)) reason = 'يوتيوب يحجب الخادم (Sign in to confirm you\'re not a bot) — الكوكيز غير صالحة أو انتهت صلاحيتها';
  else if (/getaddrinfo|name or service|name resolution|connection refused|timed out|timeout|unreachable|econnrefused|etimedout|enetunreach|proxy|tls|ssl|unable to download/i.test(joined)) reason = 'الخادم لا يستطيع الوصول إلى يوتيوب (شبكة/DNS/بروكسي) — تحقق من اتصال الخادم أو اضبط YTDLP_PROXY';
  else if (/ffmpeg|js runtime|javascript/i.test(joined)) reason = 'الخادم يحتاج مكوّناً ناقصاً (ffmpeg/JS runtime) — راجع قسم التشخيص';
  return { success: false, error: reason, details: joined.slice(0, 1600) };
}

app.post('/api/admin/youtube-cookies/test', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const body = req.body || {};
    const videoId = /^[A-Za-z0-9_-]{11}$/.test(String(body.videoId || '')) ? String(body.videoId) : 'dQw4w9WgXcQ';
    const result = await ytDlpProbe(videoId);
    res.json(result);
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

function ytBinVersion(bin, args) {
  const { execFile } = require('child_process');
  return new Promise((resolve) => {
    if (!bin) return resolve({ installed: false, version: '' });
    execFile(bin, args, { timeout: 10000, maxBuffer: 2 * 1024 * 1024 }, (err, so, se) => {
      if (err) return resolve({ installed: true, version: String(se || err.message || '').split('\n')[0].slice(0, 160) });
      resolve({ installed: true, version: String(so || '').trim().split('\n')[0].slice(0, 160) });
    });
  });
}

app.get('/api/admin/youtube-diagnose', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const ytdlpBin = findYtDlp();
    const ffmpegBin = ytMp3.findFfmpeg();
    const [ytdlp, ffmpeg] = await Promise.all([
      ytBinVersion(ytdlpBin, ['--version']),
      ytBinVersion(ffmpegBin, ['-version'])
    ]);
    const queue = ytMp3.stats();
    res.json({
      success: true,
      ytdlp: { ...ytdlp, path: ytdlpBin ? path.relative(__dirname, ytdlpBin) : '' },
      ffmpeg: { ...ffmpeg, path: ffmpegBin ? path.relative(__dirname, ffmpegBin) : '' },
      cookies: ytCookieStatusPayload(),
      limits: ytMp3.limits,
      queue: { running: queue.running, waiting: queue.waiting, concurrency: queue.concurrency, jobs: queue.jobs },
      platform: process.platform,
      node: process.version
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/youtube/health', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    if (!userId || !(await get('SELECT id FROM users WHERE id = ?', [userId]))) {
      return res.status(401).json({ success: false, error: 'Unauthorized' });
    }
    const q = ytMp3.stats();
    res.json({
      success: true,
      ffmpeg: !!ytMp3.findFfmpeg(),
      ytdlp: !!findYtDlp(),
      cookies: listYtCookieFiles().length,
      limits: ytMp3.limits,
      queue: { running: q.running, waiting: q.waiting }
    });
  } catch (err) {
    res.status(500).json({ success: false });
  }
});


// 17a. رفع وسائط المنشورات (صورة أو فيديو)
const MOMENT_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
const MOMENT_VIDEO_TYPES = ['video/mp4', 'video/webm', 'video/quicktime'];
const momentMediaUpload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB للفيديو
  fileFilter: (req, file, cb) => {
    if (MOMENT_IMAGE_TYPES.includes(file.mimetype) || MOMENT_VIDEO_TYPES.includes(file.mimetype)) return cb(null, true);
    cb(new Error('نوع الملف غير مدعوم. المسموح: صور (JPG/PNG/WEBP/GIF) أو فيديو (MP4/WEBM/MOV)'));
  }
});
app.post('/api/moments/upload', (req, res) => {
  momentMediaUpload.single('file')(req, res, async (err) => {
    try {
      const userId = req.headers['x-user-id'];
      if (err) {
        const msg = err.code === 'LIMIT_FILE_SIZE' ? 'حجم الملف كبير جداً (الحد الأقصى 50MB للفيديو و8MB للصورة)' : err.message;
        return res.status(400).json({ success: false, error: msg });
      }
      if (!userId || !(await get('SELECT id FROM users WHERE id = ?', [userId]))) {
        if (req.file) { try { fs.unlinkSync(req.file.path); } catch (e) {} }
        return res.status(401).json({ success: false, error: 'Unauthorized' });
      }
      if (!req.file) return res.status(400).json({ success: false, error: 'لم يتم اختيار ملف' });
      const isVideo = MOMENT_VIDEO_TYPES.includes(req.file.mimetype);
      if (!isVideo && req.file.size > 8 * 1024 * 1024) {
        try { fs.unlinkSync(req.file.path); } catch (e) {}
        return res.status(400).json({ success: false, error: 'حجم الصورة كبير (الحد الأقصى 8MB)' });
      }
      res.json({ success: true, url: `/uploads/${req.file.filename}`, kind: isVideo ? 'video' : 'image' });
    } catch (e) {
      res.status(500).json({ success: false, error: e.message });
    }
  });
});

function extractYouTubeId(input) {
  if (!input) return null;
  const str = String(input).trim();
  if (/^[A-Za-z0-9_-]{11}$/.test(str)) return str;
  let u;
  try { u = new URL(/^https?:\/\//i.test(str) ? str : 'https://' + str); } catch (e) { return null; }
  const host = u.hostname.replace(/^www\.|^m\./, '');
  let id = null;
  if (host === 'youtu.be') id = u.pathname.split('/')[1];
  else if (host === 'youtube.com' || host === 'music.youtube.com' || host === 'youtube-nocookie.com') {
    if (u.pathname === '/watch') id = u.searchParams.get('v');
    else {
      const m = u.pathname.match(/^\/(?:shorts|embed|live|v)\/([^/?#]+)/);
      if (m) id = m[1];
    }
  }
  return id && /^[A-Za-z0-9_-]{11}$/.test(id) ? id : null;
}

// 17. Create Moment (نص + صورة / صورة فقط / فيديو / يوتيوب)
app.post('/api/moments', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    if (!userId) return res.status(401).json({ error: 'Unauthorized' });

    const { image_url, audio_url, tag, youtube_url } = req.body;
    let { media_type, video_url } = req.body;
    const content = (req.body.content || '').toString().trim();
    const okImage = (u) => typeof u === 'string' && (u.startsWith('/uploads/') || /^https:\/\//i.test(u));

    let imageUrl = null;
    let videoUrl = null;
    if (!media_type) {
      // توافق مع الواجهة القديمة: نص + صورة اختيارية
      if (!content) return res.status(400).json({ error: 'Content is required' });
      media_type = image_url ? 'text_image' : 'text';
      imageUrl = image_url || null;
    } else if (media_type === 'text_image') {
      if (!content) return res.status(400).json({ error: 'اكتب نص المنشور' });
      if (!okImage(image_url)) return res.status(400).json({ error: 'اختر صورة للمنشور' });
      imageUrl = image_url;
    } else if (media_type === 'image') {
      if (!okImage(image_url)) return res.status(400).json({ error: 'اختر صورة للمنشور' });
      imageUrl = image_url;
    } else if (media_type === 'video') {
      if (typeof video_url !== 'string' || !video_url.startsWith('/uploads/')) {
        return res.status(400).json({ error: 'ارفع مقطع فيديو أولاً' });
      }
      videoUrl = video_url;
    } else if (media_type === 'youtube') {
      const ytId = extractYouTubeId(youtube_url || video_url);
      if (!ytId) return res.status(400).json({ error: 'رابط يوتيوب غير صالح' });
      videoUrl = ytId;
    } else if (media_type === 'text') {
      if (!content) return res.status(400).json({ error: 'اكتب نص المنشور' });
    } else {
      return res.status(400).json({ error: 'نوع المنشور غير معروف' });
    }

    const momentId = `moment-${Date.now()}`;
    await run(`
      INSERT INTO moments (id, user_id, content, image_url, audio_url, tag, likes_count, media_type, video_url)
      VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?)
    `, [momentId, userId, content, imageUrl, audio_url || null, tag || 'chill', media_type, videoUrl]);

    const newMoment = await get(`
      SELECT m.*, u.name as user_name, u.avatar as user_avatar, u.soul_planet, u.avatar_frame
      FROM moments m
      JOIN users u ON m.user_id = u.id
      WHERE m.id = ?
    `, [momentId]);

    newMoment.comments = [];
    newMoment.is_liked = false;

    // Broadcast new moment to everyone
    io.emit('new_moment', newMoment);

    res.json({ success: true, moment: newMoment });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 18. Like/Unlike Moment
app.post('/api/moments/:id/like', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    const momentId = req.params.id;
    if (!userId) return res.status(401).json({ error: 'Unauthorized' });

    const existing = await get('SELECT 1 FROM moment_likes WHERE moment_id = ? AND user_id = ?', [momentId, userId]);

    if (existing) {
      await run('DELETE FROM moment_likes WHERE moment_id = ? AND user_id = ?', [momentId, userId]);
      await run('UPDATE moments SET likes_count = MAX(0, likes_count - 1) WHERE id = ?', [momentId]);
      res.json({ success: true, liked: false });
    } else {
      await run('INSERT INTO moment_likes (moment_id, user_id) VALUES (?, ?)', [momentId, userId]);
      await run('UPDATE moments SET likes_count = likes_count + 1 WHERE id = ?', [momentId]);
      res.json({ success: true, liked: true });
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 19. Add Comment to Moment
app.post('/api/moments/:id/comments', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    const momentId = req.params.id;
    const { content } = req.body;
    if (!userId) return res.status(401).json({ error: 'Unauthorized' });
    if (!content) return res.status(400).json({ error: 'Content required' });

    const cmtId = `cmt-${Date.now()}`;
    await run(`
      INSERT INTO moment_comments (id, moment_id, user_id, content)
      VALUES (?, ?, ?, ?)
    `, [cmtId, momentId, userId, content]);

    const comment = await get(`
      SELECT c.*, u.name as user_name, u.avatar as user_avatar
      FROM moment_comments c
      JOIN users u ON c.user_id = u.id
      WHERE c.id = ?
    `, [cmtId]);

    io.emit('new_moment_comment', { momentId, comment });

    res.json({ success: true, comment });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 19b. Delete Moment (المشرفون فقط: المالك، سوبر ماستر، سوبر أدمن، أدمن، مشرف)
app.delete('/api/moments/:id', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    if (!userId) return res.status(401).json({ error: 'Unauthorized' });

    // الصلاحية تُقرأ من قاعدة البيانات وليس من الطلب
    const user = await get('SELECT id, role FROM users WHERE id = ?', [userId]);
    const canModerate = user && ['owner', 'super_master', 'super_admin', 'admin', 'moderator'].includes(user.role);
    if (!canModerate) return res.status(403).json({ error: 'حذف المنشورات متاح للمشرفين فقط' });

    const momentId = req.params.id;
    const moment = await get('SELECT * FROM moments WHERE id = ?', [momentId]);
    if (!moment) return res.status(404).json({ error: 'المنشور غير موجود أو تم حذفه' });

    await run('DELETE FROM moment_comments WHERE moment_id = ?', [momentId]);
    await run('DELETE FROM moment_likes WHERE moment_id = ?', [momentId]);
    await run('DELETE FROM moments WHERE id = ?', [momentId]);

    // حذف صورة المنشور من السيرفر إن كانت مرفوعة محلياً داخل uploads
    try {
      if (moment.image_url && moment.image_url.startsWith('/uploads/')) {
        const uploadsDir = path.join(__dirname, 'public', 'uploads');
        const full = path.join(__dirname, 'public', moment.image_url);
        if (path.dirname(full) === uploadsDir && fs.existsSync(full)) fs.unlinkSync(full);
      }
    } catch (e) { console.error('delete moment image error:', e.message); }
    try {
      if (moment.media_type === 'video' && moment.video_url && moment.video_url.startsWith('/uploads/')) {
        const uploadsDir = path.join(__dirname, 'public', 'uploads');
        const full = path.join(__dirname, 'public', moment.video_url);
        if (path.dirname(full) === uploadsDir && fs.existsSync(full)) fs.unlinkSync(full);
      }
    } catch (e) { console.error('delete moment video error:', e.message); }

    io.emit('moment_deleted', { momentId });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 20. Gift List Catalogue
app.get('/api/gifts', async (req, res) => {
  res.json(await getActiveGifts());
});

// ═══════════════════════════════════════════════════════════════
//  نظام نشاط الأعضاء: النقاط / المستويات / بطاقات العرض / VIP
//  1) نشاط العضو: إرسال هدايا — استلام هدايا — شراء VIP
//  2) تسجيل النقاط والعملات والهدايا ومدة الاشتراك في قاعدة البيانات
//  3) حساب المستوى من النقاط (member-levels.js)
//  4) بطاقات العرض: الثروة Lv.3 — الرواج Lv.4 — VIP0
// ═══════════════════════════════════════════════════════════════
const memberLevels = require('./member-levels');
const vipPerks = require('./vip-perks');
if (typeof memberLevels.configure !== 'function') console.error('⚠️ ملف member-levels.js قديم: استبدله بالنسخة الجديدة (فيه configure) ليعمل مقياس المستويات وزر توليد المستوى.');
const levelScaleReady = () => typeof memberLevels.configure === 'function';
const LEVEL_SCALE_OLD_MSG = 'ملف member-levels.js في مشروعك قديم. استبدله بالنسخة الجديدة ثم أعد تشغيل الخادم.';
const adminMaxGrantLevel = () => Math.max(99, memberLevels.MAX_LEVEL); // أقصى مستوى يمنحه المشرف يدوياً (لا يقل عن 99)

async function getPointSettings() {
  const rows = await all(`SELECT key, value FROM app_settings WHERE key IN ('coins_per_point','diamonds_per_point')`);
  const m = { coins_per_point: 10, diamonds_per_point: 1 };
  rows.forEach(r => { const n = Math.floor(Number(r.value)); if (Number.isFinite(n) && n >= 1) m[r.key] = n; });
  return m;
}

// إضافة نقاط (ثروة/رواج) ثم إعادة حساب المستوى وتخزينه في الأعمدة القديمة حتى يعمل باقي التطبيق كما هو
async function addMemberPoints(userId, kind, points) {
  points = Math.max(0, Math.floor(Number(points)) || 0);
  if (!userId || !points) return;
  const col = kind === 'wealth' ? 'wealth_points' : 'popularity_points';
  const lvCol = kind === 'wealth' ? 'wealth_level' : 'charm_level';
  await run(`UPDATE users SET ${col} = COALESCE(${col}, 0) + ? WHERE id = ?`, [points, userId]);
  const u = await get(`SELECT ${col} AS pts, ${lvCol} AS lvl FROM users WHERE id = ?`, [userId]);
  if (!u) return;
  const computed = memberLevels.levelFromPoints(u.pts).level;
  // المستوى يرتفع بالنقاط الجديدة ولا ينزل أبداً (ويحمي كذلك الحسابات الخاصة التي تتجاوز حد المقياس)
  if (computed > (Number(u.lvl) || 0)) {
    const prevLevel = Number(u.lvl) || 0;
    await run(`UPDATE users SET ${lvCol} = ? WHERE id = ?`, [computed, userId]);
    // مكافآت المستويات التي تم تجاوزها (تُمنح مرة واحدة لكل مستوى)
    try { await grantLevelRewards(userId, kind === 'wealth' ? 'wealth' : 'charm', prevLevel, computed, true); }
    catch (e) { console.error('grantLevelRewards error:', e.message); }
  }
}

// ───────── مكافآت المستويات ─────────
const LEVEL_KIND_LABELS = { wealth: 'الثروة', charm: 'الرواج', general: 'المستوى' };
const parseLevelKind = (k) => (k === 'charm' || k === 'general') ? k : 'wealth';
const LEVEL_REWARD_ITEM_TABLES = {
  avatar_frame: 'avatar_frames', entry_effect: 'entry_templates', room_card: 'room_cards', store_item: 'store_items'
};

// منح عنصر من المخزن: days = 0 دائم، وإلا يُمنح لعدد الأيام ثم يختفي تلقائياً (ينظّفه الفحص الدوري للمنتهي)
async function grantRewardItem(userId, type, itemId, days) {
  const tbl = LEVEL_REWARD_ITEM_TABLES[type];
  if (!tbl || !itemId) return '';
  const item = await get(`SELECT id, name FROM ${tbl} WHERE id = ?`, [itemId]);
  if (!item) return '';
  days = Math.max(0, Math.min(3650, Math.floor(Number(days)) || 0));
  const expr = days > 0 ? `datetime('now', '+${days} days')` : 'NULL';
  const has = await get(`SELECT id, expires_at, (expires_at IS NULL OR expires_at > datetime('now')) AS active FROM user_inventory WHERE user_id = ? AND item_type = ? AND item_id = ?`, [userId, type, item.id]);
  if (has) {
    if (has.active && !has.expires_at) return item.name;            // يملكه دائماً: لا نقصّر مدته
    if (days === 0) await run(`UPDATE user_inventory SET expires_at = NULL WHERE id = ?`, [has.id]);
    else await run(`UPDATE user_inventory SET expires_at = CASE WHEN expires_at IS NOT NULL AND expires_at > ${expr} THEN expires_at ELSE ${expr} END WHERE id = ?`, [has.id]);
  } else {
    await run(`INSERT INTO user_inventory (id, user_id, item_type, item_id, item_name, expires_at) VALUES (?, ?, ?, ?, ?, ${expr})`,
      [uuidv4(), userId, type, item.id, item.name]);
  }
  return item.name;
}

// تفعيل العنصر الممنوح مباشرة على حساب العضو
async function equipRewardItem(userId, type, itemId) {
  if (type === 'entry_effect') await run('UPDATE users SET entry_effect = ? WHERE id = ?', [itemId, userId]);
  else if (type === 'avatar_frame') await run('UPDATE users SET avatar_frame = ? WHERE id = ?', [itemId, userId]);
  else if (type === 'room_card') { await run('UPDATE users SET room_card = ? WHERE id = ?', [itemId, userId]); try { io.emit('rooms_refresh', {}); } catch (e) {} }
  else if (type === 'store_item') {
    const row = await get('SELECT category FROM store_items WHERE id = ?', [itemId]);
    if (!row || !STORE_CATEGORIES[row.category]) return;
    const u = await get('SELECT store_equipped FROM users WHERE id = ?', [userId]);
    const eq = parseEquipped(u && u.store_equipped);
    eq[row.category] = itemId;
    await run('UPDATE users SET store_equipped = ? WHERE id = ?', [JSON.stringify(eq), userId]);
    if (row.category === 'chatbubble') await run(`UPDATE users SET chat_frame = '' WHERE id = ?`, [userId]);
  } else return;
  pushUserAccessories(userId);
}

// إشعار فوري للعضو بالامتيازات التي فُتحت له عند بلوغ المستوى
async function announceUnlockedPerks(userId, fromLevel, toLevel) {
  const list = (await getWealthPerks()).filter(p => p.enabled !== false && p.level > Math.max(0, fromLevel) && p.level <= toLevel);
  if (!list.length) return;
  const set = userSockets.get(userId);
  if (!set || !set.size) return;
  const payload = { perks: list.map(p => ({ key: p.key, name: p.name, icon: p.icon, level: p.level })) };
  for (const sId of set) io.to(sId).emit('perk_unlocked', payload);
}

// إرفاق قائمة عناصر كل مستوى (للعرض في واجهة العضو ولوحة الإدارة)
async function attachRewardItems(kind, rows, withNames) {
  const items = await all('SELECT level, item_type, item_id, item_days FROM level_reward_items WHERE kind = ? ORDER BY level ASC, sort ASC', [kind]);
  const by = new Map();
  for (const it of items) { if (!by.has(it.level)) by.set(it.level, []); by.get(it.level).push({ ...it }); }
  if (withNames) {
    for (const list of by.values()) for (const it of list) {
      const tbl = LEVEL_REWARD_ITEM_TABLES[it.item_type];
      if (!tbl) continue;
      const extra = it.item_type === 'store_item' ? ', category' : '';
      const row = await get(`SELECT name, image_url${extra} FROM ${tbl} WHERE id = ?`, [it.item_id]);
      if (row) { it.name = row.name; it.image_url = row.image_url || ''; if (row.category) it.category = row.category; }
    }
  }
  return rows.map(r => {
    const list = by.get(r.level) || [];
    if (!list.length && r.item_type && r.item_id) list.push({ level: r.level, item_type: r.item_type, item_id: r.item_id, item_days: r.item_days || 0 });
    return { ...r, items: list };
  });
}

// منح مكافآت المستويات من fromLevel (غير شامل) إلى toLevel (شامل). آمن للاستدعاء المتكرر.
async function grantLevelRewards(userId, kind, fromLevel, toLevel, announcePerks, opts) {
  const onlyItems = !!(opts && opts.onlyItems);
  if (announcePerks && kind === 'wealth') announceUnlockedPerks(userId, fromLevel, toLevel).catch(() => {});
  const rows = await all(
    `SELECT * FROM level_rewards WHERE kind = ? AND level > ? AND level <= ? AND is_active = 1
       ${onlyItems ? `AND (COALESCE(item_id, '') != '' OR EXISTS (SELECT 1 FROM level_reward_items i WHERE i.kind = level_rewards.kind AND i.level = level_rewards.level))` : ''}
       ORDER BY level ASC`,
    [kind, Math.max(0, fromLevel), toLevel]);
  const granted = [];
  for (const r of rows) {
    // INSERT OR IGNORE على المفتاح الأساسي يضمن عدم الصرف مرتين حتى مع طلبات متزامنة
    const ins = await run(`INSERT OR IGNORE INTO level_rewards_claimed (user_id, kind, level, diamonds) VALUES (?, ?, ?, ?)`,
      [userId, kind, r.level, r.diamonds || 0]);
    if (!ins.changes) continue;
    const dia = Math.max(0, Math.floor(Number(r.diamonds)) || 0);
    const coins = Math.max(0, Math.floor(Number(r.coins)) || 0);
    if (dia) await run('UPDATE users SET diamonds = COALESCE(diamonds, 0) + ? WHERE id = ?', [dia, userId]);
    if (coins) await run('UPDATE users SET coins = COALESCE(coins, 0) + ? WHERE id = ?', [coins, userId]);
    // كل عناصر المستوى (الجدول الجديد) + العنصر القديم إن لم يُرحَّل
    const defs = await all('SELECT item_type, item_id, item_days FROM level_reward_items WHERE kind = ? AND level = ? ORDER BY sort ASC', [kind, r.level]);
    if (!defs.length && r.item_type && r.item_id) defs.push({ item_type: r.item_type, item_id: r.item_id, item_days: r.item_days || 0 });
    const items = [];
    for (const d of defs) {
      let itemName = '', itemImage = '', itemEquipped = false;
      try { itemName = await grantRewardItem(userId, d.item_type, d.item_id, d.item_days); } catch (e) { console.error('grantRewardItem:', e.message); }
      if (!itemName) continue;
      try { await equipRewardItem(userId, d.item_type, d.item_id); itemEquipped = true; } catch (e) { console.error('equipRewardItem:', e.message); }
      try { const im = await get(`SELECT image_url FROM ${LEVEL_REWARD_ITEM_TABLES[d.item_type]} WHERE id = ?`, [d.item_id]); itemImage = (im && im.image_url) || ''; } catch (e) {}
      items.push({ item_type: d.item_type, item_name: itemName, item_image: itemImage, item_equipped: itemEquipped, item_days: d.item_days || 0 });
    }
    if (items.length) await run('UPDATE level_rewards_claimed SET item_name = ? WHERE user_id = ? AND kind = ? AND level = ?', [items.map(i => i.item_name).join('، '), userId, kind, r.level]);
    await logMemberActivity({
      user_id: userId, type: 'level_reward', ref_id: r.level, ref_name: `${LEVEL_KIND_LABELS[kind] || kind} Lv.${r.level}`,
      amount: dia, currency: 'diamonds'
    });
    const first = items[0] || {};
    granted.push({ kind, level: r.level, tier_name: r.tier_name, diamonds: dia, coins, items,
      item_name: first.item_name || '', item_type: first.item_type || '', item_image: first.item_image || '', item_equipped: !!first.item_equipped, item_days: first.item_days || 0,
      perks: r.perks || '' });
  }
  if (granted.length) {
    try {
      const set = userSockets.get(userId);
      const fresh = await get('SELECT coins, diamonds, level, wealth_level, charm_level, entry_effect, avatar_frame, room_card, store_equipped FROM users WHERE id = ?', [userId]);
      if (set && set.size) {
        for (const sId of set) {
          io.to(sId).emit('level_reward', { rewards: granted, user: fresh || null });
          if (fresh) io.to(sId).emit('balance_updated', { coins: fresh.coins, diamonds: fresh.diamonds, level: fresh.level });
        }
      } else {
        // العضو غير متصل: نحفظ الإشعار ليظهر له نافذة المكافآت عند دخوله
        await run('INSERT INTO level_reward_notices (user_id, payload) VALUES (?, ?)', [userId, JSON.stringify(granted)]);
      }
    } catch (e) { console.error('level_reward emit:', e.message); }
  }
  return granted;
}

// عند دخول العضو: (1) منح ما بلغه من مستويات لها عناصر ولم يُمنح بعد، (2) عرض إشعارات المكافآت التي فاتته وهو غير متصل
const _rewardSyncAt = new Map();
async function syncLevelRewardsOnConnect(userId) {
  try {
    const now = Date.now();
    if (now - (_rewardSyncAt.get(userId) || 0) < 60000) return;
    _rewardSyncAt.set(userId, now);
    if (_rewardSyncAt.size > 5000) _rewardSyncAt.clear();
    const u = await get('SELECT wealth_level, charm_level, level FROM users WHERE id = ?', [userId]);
    if (!u) return;
    const cap = (v) => Math.min(memberLevels.MAX_LEVEL, Number(v) || 1);
    await grantLevelRewards(userId, 'wealth', 0, cap(u.wealth_level), false, { onlyItems: true });
    await grantLevelRewards(userId, 'charm', 0, cap(u.charm_level), false, { onlyItems: true });
    await grantLevelRewards(userId, 'general', 0, cap(u.level), false, { onlyItems: true });
    const notices = await all('SELECT id, payload FROM level_reward_notices WHERE user_id = ? ORDER BY id ASC', [userId]);
    const set = userSockets.get(userId);
    if (!notices.length || !set || !set.size) return;
    const fresh = await get('SELECT coins, diamonds, level, wealth_level, charm_level, entry_effect, avatar_frame, room_card, store_equipped FROM users WHERE id = ?', [userId]);
    for (const n of notices) {
      let rewards = []; try { rewards = JSON.parse(n.payload) || []; } catch (e) {}
      if (rewards.length) for (const sId of set) io.to(sId).emit('level_reward', { rewards, user: fresh || null });
      await run('DELETE FROM level_reward_notices WHERE id = ?', [n.id]);
    }
  } catch (e) { console.error('syncLevelRewardsOnConnect:', e.message); }
}

// ===================== نقاط المستوى العام للمستخدم (pill «المستوى» في الملف الشخصي) =====================
// المصادر كما طلب الإدارة: التفاعل في الدردشة، الصعود على المايك، إرسال الهدايا، والشراء/الشحن — تُضاف فقط ولا تنزل أبداً
async function addLevelPoints(userId, points) {
  points = Math.max(0, Math.floor(Number(points)) || 0);
  if (!userId || !points) return;
  try {
    await run('UPDATE users SET level_points = COALESCE(level_points, 0) + ? WHERE id = ?', [points, userId]);
    const u = await get('SELECT level, level_points FROM users WHERE id = ?', [userId]);
    if (!u) return;
    const computed = memberLevels.levelFromPoints(u.level_points || 0).level;
    if (computed > (Number(u.level) || 0)) {
      const prevGeneral = Number(u.level) || 0;
      await run('UPDATE users SET level = ? WHERE id = ?', [computed, userId]);
      try { await grantLevelRewards(userId, 'general', prevGeneral, computed); } catch (e) { console.error('grantLevelRewards(general):', e.message); }
      notifyMemberStats(userId); // لتحديث pf-pills في الملف الشخصي فوراً
    }
  } catch (e) { console.error('addLevelPoints error:', e.message); }
}

// نقاط تفاعل الدردشة مقيدة زمنياً (ثانيتان كحد أدنى) حتى لا يرتفع المستوى بالسبام
const _chatXpAt = new Map();
function addChatInteractionXp(userId, xp) {
  const now = Date.now();
  if (now - (_chatXpAt.get(userId) || 0) < 2000) return;
  _chatXpAt.set(userId, now);
  if (_chatXpAt.size > 5000) _chatXpAt.clear();
  addLevelPoints(userId, xp);
}

async function logMemberActivity(a) {
  await run(`
    INSERT INTO member_activity (id, user_id, type, other_user_id, ref_id, ref_name, quantity, amount, currency, points, points_kind, room_id)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `, [`act-${Date.now()}-${uuidv4().slice(0, 6)}`, a.user_id, a.type, a.other_user_id || null, a.ref_id != null ? String(a.ref_id) : null,
      a.ref_name || null, a.quantity || 1, a.amount || 0, a.currency || 'coins', a.points || 0, a.points_kind || null, a.room_id || null]);
}

// يرسل للعضو مباشرة بطاقاته الجديدة (الثروة/الرواج/VIP) ليتحدث العرض فوراً
async function notifyMemberStats(userId) {
  try {
    const set = userSockets.get(userId);
    if (!set || !set.size) return;
    const u = await get('SELECT * FROM users WHERE id = ?', [userId]);
    if (!u) return;
    const payload = {
      wealth_level: u.wealth_level, charm_level: u.charm_level,
      wealth_points: u.wealth_points || 0, popularity_points: u.popularity_points || 0,
      level: u.level || 1, level_points: u.level_points || 0,
      vip_level: memberLevels.activeVipLevel(u), vip_until: u.vip_until || null,
      vip_perks: vipPerks.perksForLevel(memberLevels.activeVipLevel(u)),
      coins: u.coins, diamonds: u.diamonds, cards: memberLevels.buildCards(u)
    };
    for (const sId of set) io.to(sId).emit('member_stats_updated', payload);
  } catch (e) { console.error('notifyMemberStats error:', e.message); }
}

// ───────── مزايا VIP: التطبيق الفعلي عند المنح / الشراء / الانتهاء ─────────
// الكتالوج في vip-perks.js (مطابق لجدول الواجهة). الإدارة تستطيع نقل ميزة لمستوى آخر أو تعطيلها (app_settings: vip_perk_levels).
async function loadVipPerkOverrides() {
  try {
    const row = await get(`SELECT value FROM app_settings WHERE key = 'vip_perk_levels'`);
    vipPerks.configure(row && row.value ? JSON.parse(row.value) : {});
  } catch (e) { /* القيم الافتراضية */ }
}
setTimeout(loadVipPerkOverrides, 1000).unref();
setInterval(loadVipPerkOverrides, 60 * 1000).unref();
const userHasVipPerk = (user, key) => vipPerks.hasPerk(user, key);

// أي مزايا عناصر تتطلب أي ميزة VIP (إن لم تكن الميزة مفتوحة لهذا المستوى لا يُمنح العنصر)
// الميزة المطلوبة لكل خانة عنصر. عناصر المتجر تنقسم بحسب قسمها: فقاعة دردشة / فقاعة دخول / بطاقة صوت / مقعد مايك.
const VIP_ITEM_PERK = {
  avatar_frame: 'frame', entry_effect: 'entry_vehicle',
  'store_item:chatbubble': 'chat_bubble', 'store_item:bubble': 'join_message', 'store_item:idcard': 'custom_card'
};
// خانة العنصر: يمكن رفع عدة عناصر من نفس الخانة في المستوى الواحد (يُفعَّل واحد فقط تلقائياً) (عناصر المتجر تُميَّز بقسمها)، فيمكن للمستوى الواحد أن يجمع إطاراً ودخولاً وفقاعة وبطاقة...
const vipItemSlot = (type, category) => type === 'store_item' ? `store_item:${category || ''}` : type;
// مدة عناصر المستويات الأدنى عند الترقية (بالأيام): ميزات المستويات التي دون مستواك الحالي تُمنح لمدة شهر فقط
const VIP_LOWER_LEVEL_ITEM_DAYS = 30;
const sqlUtc = (iso) => new Date(iso).toISOString().slice(0, 19).replace('T', ' ');

// يمنح عنصراً ينتهي مع اشتراك VIP تماماً، ويسجّله ليُسحب عند سحب VIP. لا يمسّ ما يملكه العضو دائماً أو اشتراه بنفسه.
async function grantVipItem(userId, type, itemId, untilSql, opts) {
  const tbl = LEVEL_REWARD_ITEM_TABLES[type];
  if (!tbl || !itemId) return null;
  const item = await get(`SELECT id, name FROM ${tbl} WHERE id = ?`, [itemId]);
  if (!item) return null;
  if (opts && opts.keepExisting) {
    // هدية شهرية من مستوى أدنى: إن سبق منحها من VIP لا نجدّد مدتها عند إعادة التطبيق (مثلاً بعد تعديل الإدارة للعناصر)
    const given = await get(`SELECT 1 AS x FROM vip_granted_items g JOIN user_inventory i ON i.user_id = g.user_id AND i.item_type = g.item_type AND i.item_id = g.item_id
      WHERE g.user_id = ? AND g.item_type = ? AND g.item_id = ? AND (i.expires_at IS NULL OR i.expires_at > datetime('now'))`, [userId, type, item.id]);
    if (given) return { id: item.id, name: item.name, type };
  }
  const has = await get(`SELECT id, expires_at, (expires_at IS NULL OR expires_at > datetime('now')) AS active FROM user_inventory WHERE user_id = ? AND item_type = ? AND item_id = ?`, [userId, type, item.id]);
  if (has && has.active) {
    if (has.expires_at) await run(`UPDATE user_inventory SET expires_at = CASE WHEN expires_at > ? THEN expires_at ELSE ? END WHERE id = ?`, [untilSql, untilSql, has.id]);
    return { id: item.id, name: item.name, type };            // يملكه بالفعل: نفعّله فقط ولا نسجّله كممنوح من VIP
  }
  if (has) await run(`UPDATE user_inventory SET expires_at = ? WHERE id = ?`, [untilSql, has.id]);
  else await run(`INSERT INTO user_inventory (id, user_id, item_type, item_id, item_name, expires_at) VALUES (?, ?, ?, ?, ?, ?)`, [uuidv4(), userId, type, item.id, item.name, untilSql]);
  await run(`INSERT OR IGNORE INTO vip_granted_items (user_id, item_type, item_id) VALUES (?, ?, ?)`, [userId, type, item.id]);
  return { id: item.id, name: item.name, type };
}

// هل لدى العضو الآن عنصر مفعَّل من هذه الخانة ضمن عناصر VIP؟ (لتفادي استبدال اختياره عند تحديث الإدارة)
async function vipSlotAlreadyEquipped(user, slot, rows) {
  try {
    const cur = await get('SELECT avatar_frame, entry_effect, room_card FROM users WHERE id = ?', [user.id]);
    const col = { avatar_frame: 'avatar_frame', entry_effect: 'entry_effect', room_card: 'room_card' }[slot];
    if (!col || !cur) return slot.startsWith('store_item:');     // عناصر المتجر: لا نعيد التفعيل أثناء التحديث الصامت
    return rows.some(r => vipItemSlot(r.item_type, r.category) === slot && r.item_id === cur[col]);
  } catch (e) { return false; }
}

// يطبّق مزايا VIP: عناصر مستواك الحالي تدوم مع الاشتراك، وعناصر كل مستوى أدنى منه تُمنح لمدة شهر فقط
// (مثلاً الترقية من VIP1 إلى VIP4 تعطيك عناصر 2 و3 لشهر واحد). يُفعَّل تلقائياً أعلى عنصر لكل خانة. آمن للاستدعاء المتكرر.
async function applyVipBenefits(userId, opts) {
  const silent = !!(opts && opts.silent);
  const granted = [];
  try {
    const user = await get('SELECT * FROM users WHERE id = ?', [userId]);
    const lvl = memberLevels.activeVipLevel(user);
    if (!lvl) return granted;
    const until = sqlUtc(user.vip_until);
    const bonusUntil = sqlUtc(new Date(Math.min(new Date(user.vip_until).getTime(), Date.now() + VIP_LOWER_LEVEL_ITEM_DAYS * 86400000)).toISOString());
    const rows = await all(`SELECT v.level, v.item_type, v.item_id, s.category FROM vip_level_items v
      LEFT JOIN store_items s ON v.item_type = 'store_item' AND s.id = v.item_id
      WHERE v.level <= ? ORDER BY v.level ASC`, [lvl]);
    const best = {};
    for (const r of rows) best[vipItemSlot(r.item_type, r.category)] = r;   // آخر صف = أعلى مستوى لكل خانة (هو المفعَّل)
    for (const r of rows) {
      const slot = vipItemSlot(r.item_type, r.category);
      // العنصر الذي وضعتَه الإدارة في مستوى معيّن يُمنح لصاحب هذا المستوى دون ربطه بمستوى ميزة أخرى
      // (كان الشرط القديم يمنع مثلاً قالب الدخول في VIP2 لأن ميزة «مركبة الدخول» تبدأ من VIP4)
      const own = r.level >= lvl;                                  // عنصر مستواي الحالي ← مدة الاشتراك، وغيره ← شهر
      const g = await grantVipItem(userId, r.item_type, r.item_id, own ? until : bonusUntil, own ? null : { keepExisting: true });
      if (!g) continue;
      // عدة عناصر من نفس النوع في المستوى: تُمنح كلها ويُفعَّل واحد فقط (آخرها). عند التحديث الصامت لا نغيّر اختيار العضو الحالي.
      if (best[slot] === r && !(silent && await vipSlotAlreadyEquipped(user, slot, rows))) {
        try { await equipRewardItem(userId, r.item_type, g.id); g.equipped = true; } catch (e) { console.error('equipRewardItem(vip):', e.message); }
      }
      granted.push(g);
    }
    // إشعار في الجرس بالميزات الممنوحة (عند الشراء/المنح/الترقية فقط، لا عند تحديث الإدارة الصامت)
    if (!silent) {
      try {
        const notifId = `notif-${uuidv4()}`;
        const createdAt = new Date().toISOString();
        const content = JSON.stringify({
          level: lvl, until: user.vip_until,
          perks: vipPerks.describe(user).filter(p => p.unlocked).map(p => ({ key: p.key, name: p.name, group: p.group, level: p.level })),
          items: granted.map(g => ({ name: g.name, type: g.type, equipped: !!g.equipped }))
        });
        await run('INSERT INTO notifications (id, user_id, type, actor_id, content, created_at) VALUES (?, ?, ?, ?, ?, ?)', [notifId, userId, 'vip_upgrade', null, content, createdAt]);
        emitToUser(userId, 'new_notification', { id: notifId, type: 'vip_upgrade', content, created_at: createdAt, is_read: 0 });
      } catch (e) { console.error('vip notification error:', e.message); }
    }
    const set = userSockets.get(userId);
    if (set && set.size) {
      const unlocked = vipPerks.describe(user).filter(p => p.unlocked).map(p => ({ key: p.key, name: p.name }));
      for (const sId of set) io.to(sId).emit('vip_activated', { level: lvl, until: user.vip_until, perks: unlocked, items: granted, silent });
    }
  } catch (e) { console.error('applyVipBenefits error:', e.message); }
  return granted;
}

// يسحب ما منحه نظام VIP (عند سحب الاشتراك أو انتهائه أو خفضه) دون المساس بما اشتراه العضو
async function revokeVipBenefits(userId) {
  try {
    const rows = await all('SELECT item_type, item_id FROM vip_granted_items WHERE user_id = ?', [userId]);
    let cardsChanged = false;
    for (const r of rows) {
      await run('DELETE FROM user_inventory WHERE user_id = ? AND item_type = ? AND item_id = ?', [userId, r.item_type, r.item_id]);
      if (r.item_type === 'entry_effect') await run(`UPDATE users SET entry_effect = '' WHERE id = ? AND entry_effect = ?`, [userId, r.item_id]);
      else if (r.item_type === 'avatar_frame') await run('UPDATE users SET avatar_frame = ? WHERE id = ? AND avatar_frame = ?', [DEFAULT_AVATAR_FRAME, userId, r.item_id]);
      else if (r.item_type === 'store_item') await unequipStoreItemEverywhere(userId, r.item_id);
      else if (r.item_type === 'room_card') { const ch = await run(`UPDATE users SET room_card = '' WHERE id = ? AND room_card = ?`, [userId, r.item_id]); if (ch.changes) cardsChanged = true; }
    }
    await run('DELETE FROM vip_granted_items WHERE user_id = ?', [userId]);
    if (rows.length) { pushUserAccessories(userId); if (cardsChanged) io.emit('rooms_refresh', {}); }
  } catch (e) { console.error('revokeVipBenefits error:', e.message); }
}

// إنهاء اشتراكات VIP المنتهية (تُصفَّر تلقائياً ليظهر VIP0)
async function expireVipSubscriptions() {
  try {
    const expired = await all(`SELECT id FROM users WHERE COALESCE(vip_level, 0) > 0 AND (vip_until IS NULL OR vip_until <= ?)`, [new Date().toISOString()]);
    for (const u of expired) {
      await run('UPDATE users SET vip_level = 0 WHERE id = ?', [u.id]);
      await revokeVipBenefits(u.id);
      notifyMemberStats(u.id);
    }
  } catch (e) { console.error('expireVipSubscriptions error:', e.message); }
}
setTimeout(expireVipSubscriptions, 15000).unref();
setInterval(expireVipSubscriptions, 60 * 60 * 1000).unref();

// مكافآت المستويات: عرض لكل مستوى مع حالة الاستلام
app.get('/api/level-rewards', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    const kind = parseLevelKind(req.query.kind);
    const rewards = await attachRewardItems(kind, await all(`SELECT level, tier_name, diamonds, coins, item_type, item_id, item_days, perks FROM level_rewards WHERE kind = ? AND is_active = 1 ORDER BY level ASC`, [kind]), true);
    let level = 1, points = 0, claimed = [];
    if (userId) {
      const u = await get('SELECT wealth_level, charm_level, wealth_points, popularity_points, level, level_points FROM users WHERE id = ?', [userId]);
      if (u) {
        const col = { wealth: ['wealth_level', 'wealth_points'], charm: ['charm_level', 'popularity_points'], general: ['level', 'level_points'] }[kind];
        level = Number(u[col[0]]) || 1;
        points = Number(u[col[1]]) || 0;
      }
      claimed = (await all('SELECT level FROM level_rewards_claimed WHERE user_id = ? AND kind = ?', [userId, kind])).map(r => r.level);
    }
    const info = memberLevels.levelFromPoints(points);
    res.json({ success: true, kind, level, points, next: info.next, remaining: info.remaining, progress: info.progress, rewards, claimed });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// استلام مكافآت المستويات التي وصلتَ لها سابقاً ولم تُمنح (للأعضاء القدامى)
app.post('/api/level-rewards/claim', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    if (!userId) return res.status(401).json({ error: 'Unauthorized' });
    const u = await get('SELECT wealth_level, charm_level, level FROM users WHERE id = ?', [userId]);
    if (!u) return res.status(404).json({ error: 'المستخدم غير موجود' });
    const cap = (v) => Math.min(memberLevels.MAX_LEVEL, Number(v) || 1);
    const granted = [
      ...(await grantLevelRewards(userId, 'wealth', 0, cap(u.wealth_level))),
      ...(await grantLevelRewards(userId, 'charm', 0, cap(u.charm_level))),
      ...(await grantLevelRewards(userId, 'general', 0, cap(u.level)))
    ];
    const fresh = await get('SELECT diamonds, coins FROM users WHERE id = ?', [userId]);
    res.json({ success: true, granted, diamonds: fresh ? fresh.diamonds : null });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ───── المهام اليومية (تمنح خبرة لمستوى الثروة) — قابلة للتعديل من لوحة الإدارة ─────
const MISSION_TZ_OFFSET_HOURS = 3; // بداية اليوم 00:00 بتوقيت UTC+3 (الأردن/السعودية)
const missionDay = () => new Date(Date.now() + MISSION_TZ_OFFSET_HOURS * 3600e3).toISOString().slice(0, 10);
const DEFAULT_DAILY_MISSIONS = {
  cap: 2000,
  missions: [
    { key: 'app_open', icon: '📱', title: 'فتح التطبيق', unit: 'مرة واحدة', target: 1, exp: 50, enabled: true },
    { key: 'watch_minutes', icon: '🎬', title: 'مشاهدة البث في الغرفة الصوتية', unit: '1 دقيقة', target: 10, exp: 30, enabled: true, suffix: 'min' },
    { key: 'room_comments', icon: '💬', title: 'إرسال تعليق في الغرفة الصوتية', unit: 'مرة واحدة', target: 5, exp: 40, enabled: true },
    { key: 'mic_minutes', icon: '🎤', title: 'الصعود على المايك في الغرفة الصوتية', unit: '1 دقيقة', target: 5, exp: 30, enabled: true, suffix: 'min' },
    { key: 'room_gift', icon: '🎁', title: 'إرسال هدية في الغرفة الصوتية', unit: 'مرة واحدة', target: 1, exp: 500, enabled: true },
    { key: 'follows', icon: '✉️', title: 'متابعة الآخرين', unit: 'مرة واحدة', target: 4, exp: 25, enabled: true },
    { key: 'friends', icon: '🤝', title: 'الحصول على أصدقاء', unit: 'مرة واحدة', target: 3, exp: 50, enabled: true },
    { key: 'dm_messages', icon: '🔔', title: 'إرسال رسالة إلى صديق', unit: 'رسالة واحدة', target: 10, exp: 25, enabled: true }
  ]
};
function normalizeDailyMissions(raw) {
  const out = { cap: DEFAULT_DAILY_MISSIONS.cap, missions: [] };
  const src = raw && typeof raw === 'object' ? raw : {};
  const cap = Math.floor(Number(src.cap));
  if (Number.isFinite(cap) && cap >= 0) out.cap = Math.min(10000000, cap);
  const byKey = {};
  if (Array.isArray(src.missions)) src.missions.forEach(m => { if (m && m.key) byKey[m.key] = m; });
  for (const d of DEFAULT_DAILY_MISSIONS.missions) {
    const m = byKey[d.key] || {};
    const target = Math.floor(Number(m.target)); const exp = Math.floor(Number(m.exp));
    out.missions.push({
      key: d.key, suffix: d.suffix || '',
      icon: String(m.icon || d.icon).trim().slice(0, 8) || d.icon,
      title: String(m.title || d.title).trim().slice(0, 80) || d.title,
      unit: String(m.unit || d.unit).trim().slice(0, 30) || d.unit,
      target: Number.isFinite(target) && target >= 1 ? Math.min(100000, target) : d.target,
      exp: Number.isFinite(exp) && exp >= 0 ? Math.min(1000000, exp) : d.exp,
      enabled: m.enabled === undefined ? d.enabled : !!m.enabled
    });
  }
  return out;
}
async function getDailyMissions() {
  try {
    const row = await get(`SELECT value FROM app_settings WHERE key = 'daily_missions'`);
    return normalizeDailyMissions(row && row.value ? JSON.parse(row.value) : null);
  } catch (e) { return normalizeDailyMissions(null); }
}
let missionTableReady = null;
function ensureMissionTable() {
  if (!missionTableReady) {
    missionTableReady = run(`CREATE TABLE IF NOT EXISTS daily_mission_progress (
      user_id TEXT NOT NULL, day TEXT NOT NULL, mission_key TEXT NOT NULL,
      count INTEGER NOT NULL DEFAULT 0, exp_awarded INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (user_id, day, mission_key))`).catch(e => { missionTableReady = null; throw e; });
  }
  return missionTableReady;
}
// تسجيل تقدّم مهمة يومية ومنح الخبرة (حتى سقف الخبرة اليومي)
async function recordMission(userId, key, delta = 1) {
  try {
    if (!userId) return;
    await ensureMissionTable();
    const cfg = await getDailyMissions();
    const m = cfg.missions.find(x => x.key === key && x.enabled);
    if (!m) return;
    const day = missionDay();
    const row = await get('SELECT count FROM daily_mission_progress WHERE user_id = ? AND day = ? AND mission_key = ?', [userId, day, key]);
    const prev = row ? Number(row.count) : 0;
    if (prev >= m.target) return;
    const next = Math.min(m.target, prev + Math.max(1, delta));
    const tot = await get('SELECT COALESCE(SUM(exp_awarded), 0) AS t FROM daily_mission_progress WHERE user_id = ? AND day = ?', [userId, day]);
    const gain = Math.max(0, Math.min((next - prev) * m.exp, cfg.cap - Number(tot.t || 0)));
    await run(`INSERT INTO daily_mission_progress (user_id, day, mission_key, count, exp_awarded) VALUES (?, ?, ?, ?, ?)
               ON CONFLICT(user_id, day, mission_key) DO UPDATE SET count = excluded.count, exp_awarded = daily_mission_progress.exp_awarded + ?`,
      [userId, day, key, next, gain, gain]);
    if (gain > 0) await addMemberPoints(userId, 'wealth', gain);
  } catch (e) { console.error('recordMission:', e.message); }
}
app.get('/api/me/daily-missions', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    if (!userId) return res.status(401).json({ error: 'Unauthorized' });
    await ensureMissionTable();
    const cfg = await getDailyMissions();
    const day = missionDay();
    const rows = await all('SELECT mission_key, count, exp_awarded FROM daily_mission_progress WHERE user_id = ? AND day = ?', [userId, day]);
    const by = {}; let total = 0;
    rows.forEach(r => { by[r.mission_key] = Number(r.count); total += Number(r.exp_awarded) || 0; });
    res.json({ success: true, cap: cfg.cap, total_exp: total,
      missions: cfg.missions.filter(m => m.enabled).map(m => ({ key: m.key, icon: m.icon, title: m.title, unit: m.unit, suffix: m.suffix, target: m.target, exp: m.exp, count: Math.min(by[m.key] || 0, m.target) })) });
  } catch (err) { res.status(500).json({ error: err.message }); }
});
app.get('/api/admin/settings/daily-missions', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  res.json({ success: true, settings: await getDailyMissions() });
});
app.post('/api/admin/settings/daily-missions', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const clean = normalizeDailyMissions(req.body || {});
    await run(`INSERT INTO app_settings (key, value) VALUES ('daily_missions', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value`, [JSON.stringify(clean)]);
    res.json({ success: true, settings: clean });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ───── مقياس المستويات القابل للتعديل من الإدارة (السقف + نسبة التصاعد بعد المستوى 30) ─────
async function loadLevelScale() {
  if (!levelScaleReady()) return;
  try {
    const rows = await all(`SELECT key, value FROM app_settings WHERE key IN ('max_level','extra_level_growth_pct')`);
    const m = {}; rows.forEach(r => { m[r.key] = r.value; });
    memberLevels.configure({ maxLevel: m.max_level, growthPct: m.extra_level_growth_pct });
  } catch (e) { console.error('loadLevelScale:', e.message); }
}
setTimeout(() => { loadLevelScale(); }, 2500);

app.get('/api/level-scale', async (req, res) => {
  let pts = { coins_per_point: 10, diamonds_per_point: 1 };
  try { pts = await getPointSettings(); } catch (e) {}
  const thresholds = []; for (let n = 1; n <= memberLevels.MAX_LEVEL; n++) thresholds.push(memberLevels.levelThreshold(n));
  res.json({ success: true, max_level: memberLevels.MAX_LEVEL, growth_pct: memberLevels.EXTRA_GROWTH_PCT, thresholds, coins_per_point: pts.coins_per_point, diamonds_per_point: pts.diamonds_per_point });
});

// ───── مميزات مستوى الثروة (بطاقات تُفتح حسب مستوى العضو) — قابلة للتعديل من لوحة الإدارة ─────
const PERK_PROGRESS_DESC = 'في كل مرة تتقدم في المستوى، ستحصل على عناصر افتراضية مع مدة صلاحيتها للمستوى المقابل.';
const DEFAULT_WEALTH_PERKS = [
  { icon: '🏅', name: 'شارة المستوى', level: 1, desc: 'تظهر شارة مستوى ثروتك بجانب اسمك في الغرف وبطاقة التعريف وقائمة الترحيب. كلما ارتفع المستوى حصلت على شارة أفخم.' },
  { icon: '🎙️', name: 'الصدارة في طابور الميكروفون', level: 1, desc: 'أولوية لك عند الصعود إلى المايك مقارنةً بالأعضاء الأقل مستوى.' },
  { icon: '📷', name: 'تثبيت صورة البروفايل', level: 1, desc: 'ثبّت صورتك الشخصية لتظهر لمن يزور بطاقتك.' },
  { icon: '✨', name: 'إشعار دخول رائع', level: 11, desc: 'يظهر إشعار دخول مميز لك عند دخولك الغرف.' },
  { icon: '💬', name: 'فقاعة دردشة مبهرة', level: 21, desc: PERK_PROGRESS_DESC, table: [{ range: '21-30', duration: '7 أيام', img: '' }, { range: '31-100', duration: '15 أيام', img: '' }] },
  { icon: '🪪', name: 'تصميم البطاقة', level: 31, desc: 'تصميم خاص لبطاقة التعريف الخاصة بك.' },
  { icon: '👥', name: 'زيادة عدد المتابعين', level: 35, desc: 'ارفع الحد الأقصى لعدد من تستطيع متابعتهم.' },
  { icon: '🪑', name: 'تأثيرات المقعد', level: 40, desc: 'تأثيرات بصرية خاصة تظهر حول مقعدك على المايك.' },
  { icon: '🏠', name: 'بطاقة الغرفة', level: 50, desc: 'بطاقة مميزة لغرفتك في قائمة الغرف.' },
  { icon: '⚡', name: 'تسريع ترقية المستوى', level: 51, desc: 'تكسب خبرة أكثر عند كل عملية تُحسب لك لرفع المستوى.' },
  { icon: '🖼️', name: 'إطار', level: 60, desc: PERK_PROGRESS_DESC },
  { icon: '📌', name: 'تثبيت المحادثة في الغرفة', level: 65, desc: 'ثبّت رسالتك في أعلى دردشة الغرفة.' },
  { icon: '🎁', name: 'هدايا المستوى', level: 70, desc: 'هدايا حصرية تُمنح لك عند بلوغ هذا المستوى.' },
  { icon: '🚪', name: 'دخوليات', level: 80, desc: 'مجموعة دخوليات مميزة تختار منها عند دخولك الغرف.' },
  { icon: '🏷️', name: 'لقب يجذب الانتباه', level: 90, desc: 'لقب مميز يظهر مع اسمك.' },
  { icon: '💌', name: 'الهدايا بالخاص', level: 95, desc: 'أرسل الهدايا مباشرةً في المحادثات الخاصة.' },
  { icon: '🔖', name: 'عنوان تقوم باختياره', level: 100, desc: 'اختر عنواناً خاصاً يظهر في بطاقتك.' },
  { icon: '📢', name: 'البث الشامل', level: 101, desc: 'ميزة بث شامل حصرية لهذا المستوى.' },
  { icon: '🌟', name: 'تعليق بارز', level: 110, desc: 'يظهر تعليقك بشكل بارز في دردشة الغرفة.' },
  { icon: '🔤', name: 'زخرفة الإسم', level: 120, desc: 'زخرفة خاصة لاسمك تظهر للجميع.' },
  { icon: '💠', name: 'مؤثر بطاقة التعريف', level: 125, desc: 'مؤثر بصري على بطاقة التعريف الخاصة بك.' },
  { icon: '🖼️', name: 'صورة شخصية متحركة', level: 141, desc: 'اجعل صورتك الشخصية متحركة.' },
  { icon: '🎉', name: 'إشعار إهداء مميز', level: 151, desc: 'إشعار مميز يظهر عند إهدائك للهدايا.' },
  { icon: '🕊️', name: 'رسائل طائرة', level: 160, desc: 'رسائل تطير على شاشة الغرفة.' },
  { icon: '🌍', name: 'إعلان عالمي', level: 165, desc: 'أعلن رسالتك لجميع الغرف.' },
  { icon: '🎀', name: 'هدية مصممة', level: 170, desc: 'هدية مصممة خصيصاً لك.' },
  { icon: '🚗', name: 'دخولية مصممة', level: 175, desc: 'دخولية مصممة خصيصاً لك.' },
  { icon: '🥷', name: 'الخفي في الجدول', level: 180, desc: 'اخفِ اسمك من جداول الترتيب.' },
  { icon: '🕶️', name: 'Mr.X بالغرف', level: 185, desc: 'ادخل الغرف متخفياً دون ظهور اسمك أو إشعار دخولك (حسب إعدادات الإدارة).' },
  { icon: '🛡️', name: 'لا يمكن طردك من الغرف', level: 190, desc: 'لا يمكن لأحد طردك من الغرف.' }
];
const globalAnnounceLast = new Map();
const WEALTH_PERK_KEYS = ['level_badge', 'mic_priority', 'pin_avatar', 'entry_notice', 'chat_bubble', 'card_design', 'follow_boost', 'seat_effects',
  'room_card', 'xp_boost', 'frame', 'pin_message', 'level_gifts', 'entries', 'title', 'private_gifts', 'custom_address', 'global_broadcast',
  'highlight_comment', 'name_decor', 'card_effect', 'animated_avatar', 'gift_notice', 'flying_messages', 'global_announce', 'designed_gift',
  'designed_entry', 'hidden_in_rank', 'mr_x', 'no_kick'];
DEFAULT_WEALTH_PERKS.forEach((p, i) => { p.key = WEALTH_PERK_KEYS[i] || ''; p.enabled = true; });
const perkNameNorm = (n) => String(n || '').replace(/[\uFE0F\u200D\s]/g, '').toLowerCase();
const DEFAULT_PERK_BY_NAME = new Map(DEFAULT_WEALTH_PERKS.map(p => [perkNameNorm(p.name), p.key]));
function normalizeWealthPerks(arr) {
  if (!Array.isArray(arr)) return null;
  const out = [];
  for (const p of arr.slice(0, 80)) {
    const name = String((p && p.name) || '').trim().slice(0, 60);
    const level = Math.floor(Number(p && p.level));
    if (!name || !Number.isFinite(level) || level < 1) continue;
    const table = [];
    if (p && Array.isArray(p.table)) {
      for (const r of p.table.slice(0, 12)) {
        const range = String((r && r.range) || '').trim().slice(0, 20);
        const duration = String((r && r.duration) || '').trim().slice(0, 30);
        let img = String((r && r.img) || '').trim();
        if (img && !/^(https?:\/\/|\/uploads\/)/.test(img)) img = '';
        if (range || duration) table.push({ range, duration, img: img.slice(0, 300) });
      }
    }
    let key = String((p && p.key) || '').toLowerCase().replace(/[^a-z0-9_]/g, '').slice(0, 40);
    if (!key) key = DEFAULT_PERK_BY_NAME.get(perkNameNorm(name)) || '';
    out.push({ key, enabled: !(p && (p.enabled === false || p.enabled === 0 || p.enabled === '0')), icon: String((p && p.icon) || '⭐').trim().slice(0, 8) || '⭐', name, level: Math.min(999, level), desc: String((p && p.desc) || '').trim().slice(0, 500), table });
  }
  out.sort((a, b) => a.level - b.level);
  return out;
}
async function getWealthPerks() {
  try {
    const row = await get(`SELECT value FROM app_settings WHERE key = 'wealth_perks'`);
    if (row && row.value) { const n = normalizeWealthPerks(JSON.parse(row.value)); if (n) return n; }
  } catch (e) {}
  return DEFAULT_WEALTH_PERKS;
}
// ذاكرة مؤقتة متزامنة لمستويات الامتيازات (تُحدَّث عند الحفظ من الإدارة وكل دقيقة)
let perkCache = {};
function setPerkCache(list) {
  const m = {};
  (list || []).forEach(p => { if (p && p.key) m[p.key] = { level: Number(p.level) || 1, enabled: p.enabled !== false, name: p.name, icon: p.icon }; });
  perkCache = m;
}
setPerkCache(DEFAULT_WEALTH_PERKS);
async function refreshPerkCache() { try { setPerkCache(await getWealthPerks()); } catch (e) {} }
// مستوى الثروة المطلوب لامتياز ما (Infinity إن عطّلته الإدارة). fallback إن لم يوجد الامتياز في القائمة.
function perkLevelSync(key, fallback) {
  const p = perkCache[key];
  if (!p) return fallback;
  return p.enabled ? p.level : Infinity;
}
function userHasPerkSync(user, key, fallback) {
  return !!user && (Number(user.wealth_level) || 1) >= perkLevelSync(key, fallback === undefined ? Infinity : fallback);
}
setTimeout(refreshPerkCache, 1500);
setInterval(refreshPerkCache, 60 * 1000);

// ───── حدود المتابعة (الأساسي / لأصحاب امتياز «زيادة عدد المتابعين») ─────
async function getFollowLimits() {
  let base = 500, boost = 2000;
  try {
    const rows = await all(`SELECT key, value FROM app_settings WHERE key IN ('follow_limit_base', 'follow_limit_boost')`);
    rows.forEach(r => { const n = Math.floor(Number(r.value)); if (Number.isFinite(n) && n >= 1) { if (r.key === 'follow_limit_base') base = Math.min(n, 1e6); else boost = Math.min(n, 1e6); } });
  } catch (e) {}
  return { base, boost: Math.max(base, boost) };
}
app.get('/api/admin/settings/follow-limits', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  res.json({ success: true, ...(await getFollowLimits()) });
});
app.post('/api/admin/settings/follow-limits', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const base = Math.floor(Number(req.body && req.body.base)), boost = Math.floor(Number(req.body && req.body.boost));
    if (!(base >= 1) || !(boost >= base)) return res.status(400).json({ error: 'الحد المرتفع يجب أن يساوي الأساسي أو يزيد عليه' });
    for (const [k, v] of [['follow_limit_base', base], ['follow_limit_boost', boost]]) {
      await run(`INSERT INTO app_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value`, [k, String(v)]);
    }
    res.json({ success: true, base, boost });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// امتيازات العضو الفعلية (للواجهة): ما فُتح له وما لم يُفتح
app.get('/api/me/perks', async (req, res) => {
  try {
    const uid = req.headers['x-user-id'];
    if (!uid) return res.status(401).json({ error: 'Unauthorized' });
    const u = await get('SELECT id, wealth_level FROM users WHERE id = ?', [uid]);
    if (!u) return res.status(404).json({ error: 'User not found' });
    const lv = Number(u.wealth_level) || 1;
    const perks = (await getWealthPerks()).filter(p => p.enabled !== false).map(p => ({ key: p.key, name: p.name, icon: p.icon, level: p.level, unlocked: lv >= p.level }));
    const lim = await getFollowLimits();
    res.json({ success: true, wealth_level: lv, perks, follow_limit: userHasPerkSync(u, 'follow_boost', 35) ? lim.boost : lim.base });
  } catch (err) { res.status(500).json({ error: err.message }); }
});
app.get('/api/wealth-perks', async (req, res) => { res.json({ success: true, perks: await getWealthPerks() }); });
app.get('/api/admin/settings/wealth-perks', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  res.json({ success: true, perks: await getWealthPerks() });
});
app.post('/api/admin/settings/wealth-perks', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const clean = normalizeWealthPerks(req.body && req.body.perks);
    if (!clean) return res.status(400).json({ error: 'بيانات غير صالحة' });
    await run(`INSERT INTO app_settings (key, value) VALUES ('wealth_perks', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value`, [JSON.stringify(clean)]);
    setPerkCache(clean);
    res.json({ success: true, perks: clean });
  } catch (err) { res.status(500).json({ error: err.message }); }
});
app.get('/api/admin/settings/level-scale', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  res.json({ success: true, max_level: memberLevels.MAX_LEVEL, growth_pct: memberLevels.EXTRA_GROWTH_PCT, limit: memberLevels.SCALE_LIMIT, base: memberLevels.MIN_MAX_LEVEL });
});
app.post('/api/admin/settings/level-scale', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  if (!levelScaleReady()) return res.status(500).json({ error: LEVEL_SCALE_OLD_MSG });
  try {
    const b = req.body || {};
    const maxLevel = Math.floor(Number(b.max_level));
    const growth = Number(b.growth_pct);
    if (!(maxLevel >= memberLevels.MIN_MAX_LEVEL && maxLevel <= memberLevels.SCALE_LIMIT)) return res.status(400).json({ error: `السقف يجب أن يكون بين ${memberLevels.MIN_MAX_LEVEL} و ${memberLevels.SCALE_LIMIT}` });
    if (!(growth >= 1 && growth <= 100)) return res.status(400).json({ error: 'نسبة التصاعد يجب أن تكون بين 1 و 100' });
    const cfg = memberLevels.configure({ maxLevel, growthPct: growth });
    const upsert = (k, v) => run(`INSERT INTO app_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value`, [k, String(v)]);
    await upsert('max_level', cfg.maxLevel);
    await upsert('extra_level_growth_pct', cfg.growthPct);
    // إنشاء صفوف مكافآت فارغة للمستويات الجديدة (تُعدَّل لاحقاً من جدول المكافآت)
    for (const kind of ['wealth', 'charm', 'general']) {
      const last = await get(`SELECT tier_name FROM level_rewards WHERE kind = ? ORDER BY level DESC LIMIT 1`, [kind]);
      const tier = (last && last.tier_name) || '';
      for (let l = 31; l <= cfg.maxLevel; l++) { // الصفوف المزروعة أصلاً في قاعدة البيانات تنتهي عند 30
        await run(`INSERT OR IGNORE INTO level_rewards (kind, level, tier_name, diamonds, perks) VALUES (?, ?, ?, 0, '')`, [kind, l, tier]);
      }
    }
    res.json({ success: true, max_level: cfg.maxLevel, growth_pct: cfg.growthPct });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ───── لوحة الإدارة: تعديل مكافآت المستويات ─────
app.get('/api/admin/level-rewards', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const kind = parseLevelKind(req.query.kind);
    res.json({ success: true, rewards: await attachRewardItems(kind, await all('SELECT * FROM level_rewards WHERE kind = ? ORDER BY level ASC', [kind]), true) });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// رفع/تعديل مستوى عضو (عام / ثروة / رواج) من الإدارة — تُضبط النقاط على حد المستوى حتى يبقى الحساب متسقاً
app.post('/api/admin/users/:id/levels', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const id = req.params.id;
    const user = await get('SELECT * FROM users WHERE id = ?', [id]);
    if (!user) return res.status(404).json({ error: 'المستخدم غير موجود' });
    const b = req.body || {};
    const grant = !(b.grant_rewards === false || b.grant_rewards === 'false' || b.grant_rewards === 0);
    const parse = (v) => {
      if (v === undefined || v === null || v === '') return null;
      const n = Math.floor(Number(v));
      // الإدارة تستطيع منح مستويات خاصة تتجاوز مقياس المستخدمين العاديين (30) حتى 99
      if (!(n >= 1 && n <= adminMaxGrantLevel())) throw new Error(`المستوى يجب أن يكون بين 1 و ${adminMaxGrantLevel()}`);
      return n;
    };
    const targets = [
      { key: 'wealth', lvCol: 'wealth_level', ptCol: 'wealth_points', val: parse(b.wealth_level), label: 'الثروة' },
      { key: 'charm', lvCol: 'charm_level', ptCol: 'popularity_points', val: parse(b.charm_level), label: 'الرواج' },
      { key: 'general', lvCol: 'level', ptCol: 'level_points', val: parse(b.level), label: 'المستوى العام' }
    ];
    if (!targets.some(t => t.val)) return res.status(400).json({ error: 'أدخل مستوى واحداً على الأقل' });
    const granted = [];
    for (const t of targets) {
      if (!t.val) continue;
      const prev = Number(user[t.lvCol]) || 1;
      const need = memberLevels.levelThreshold(t.val);
      const cur = Number(user[t.ptCol]) || 0;
      const newPts = t.val >= prev ? Math.max(cur, need) : need; // الرفع لا يُنقص نقاطاً، والخفض يعيد النقاط لحد المستوى
      await run(`UPDATE users SET ${t.lvCol} = ?, ${t.ptCol} = ? WHERE id = ?`, [t.val, newPts, id]);
      await logMemberActivity({ user_id: id, type: 'level_admin', ref_id: t.val, ref_name: `${t.label} → Lv.${t.val}`, points: newPts });
      if (grant && t.val > prev) granted.push(...await grantLevelRewards(id, t.key, prev, t.val));
    }
    notifyMemberStats(id);
    const fresh = await get('SELECT id, level, wealth_level, charm_level, wealth_points, popularity_points, level_points, diamonds FROM users WHERE id = ?', [id]);
    res.json({ success: true, user: fresh, granted });
  } catch (err) { res.status(err.message && err.message.startsWith('المستوى') ? 400 : 500).json({ error: err.message }); }
});

// قائمة عناصر قسم معيّن (اسم + معرّف) لاختيارها كمكافأة مستوى
app.get('/api/admin/level-reward-items', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const tbl = LEVEL_REWARD_ITEM_TABLES[req.query.type];
    if (!tbl) return res.json({ success: true, items: [] });
    // vip_only = 1 ← مرفوع من قسم مزايا VIP (مستقل عن المتجر)، ويُعرض أولاً
    if (req.query.type === 'store_item' && STORE_CATEGORIES[req.query.category]) {
      return res.json({ success: true, items: await all(`SELECT id, name, image_url, vip_only FROM ${tbl} WHERE category = ? ORDER BY vip_only DESC, created_at DESC LIMIT 500`, [req.query.category]) });
    }
    res.json({ success: true, items: await all(`SELECT id, name, image_url, vip_only FROM ${tbl} ORDER BY vip_only DESC, created_at DESC LIMIT 500`) });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// توليد المستوى (أو عدة مستويات) التالي تلقائياً بالترتيب بعد آخر مستوى موجود، ورفع سقف المقياس عند الحاجة
app.post('/api/admin/level-rewards/:kind/next', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  if (!levelScaleReady()) return res.status(500).json({ error: LEVEL_SCALE_OLD_MSG });
  try {
    const kind = ['wealth', 'charm', 'general'].includes(req.params.kind) ? req.params.kind : null;
    if (!kind) return res.status(400).json({ error: 'نوع غير صالح' });
    const count = Math.max(1, Math.min(20, Math.floor(Number(req.body && req.body.count)) || 1));
    const last = await get('SELECT level, tier_name FROM level_rewards WHERE kind = ? ORDER BY level DESC LIMIT 1', [kind]);
    const startLevel = (last ? Number(last.level) : 1) + 1;
    const endLevel = startLevel + count - 1;
    if (endLevel > memberLevels.SCALE_LIMIT) return res.status(400).json({ error: `لا يمكن تجاوز المستوى ${memberLevels.SCALE_LIMIT}` });
    const tier = (last && last.tier_name) || '';
    for (let l = startLevel; l <= endLevel; l++) {
      await run(`INSERT OR IGNORE INTO level_rewards (kind, level, tier_name, diamonds, perks) VALUES (?, ?, ?, 0, '')`, [kind, l, tier]);
    }
    // المقياس يتسع تلقائياً ليشمل المستويات الجديدة (ويُحفظ)
    let maxLevel = memberLevels.MAX_LEVEL;
    if (endLevel > maxLevel) {
      const cfg = memberLevels.configure({ maxLevel: endLevel });
      maxLevel = cfg.maxLevel;
      await run(`INSERT INTO app_settings (key, value) VALUES ('max_level', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value`, [String(maxLevel)]);
      await run(`INSERT INTO app_settings (key, value) VALUES ('extra_level_growth_pct', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value`, [String(cfg.growthPct)]);
    }
    res.json({ success: true, kind, from: startLevel, to: endLevel, max_level: maxLevel });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.put('/api/admin/level-rewards/:kind/:level', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const kind = ['wealth', 'charm', 'general'].includes(req.params.kind) ? req.params.kind : null;
    const level = Math.floor(Number(req.params.level));
    if (!kind) return res.status(400).json({ error: 'نوع غير صالح' });
    if (!(level >= 2 && level <= memberLevels.MAX_LEVEL)) return res.status(400).json({ error: `المستوى بين 2 و ${memberLevels.MAX_LEVEL}` });
    const b = req.body || {};
    const diamonds = Math.max(0, Math.min(100000000, Math.floor(Number(b.diamonds)) || 0));
    const coins = Math.max(0, Math.min(1000000000, Math.floor(Number(b.coins)) || 0));
    // قائمة العناصر: items[] (الجديد) أو item_type/item_id المفرد (للتوافق مع القديم)
    let rawItems = Array.isArray(b.items) ? b.items : (b.item_type && b.item_id ? [{ item_type: b.item_type, item_id: b.item_id, item_days: b.item_days }] : []);
    if (rawItems.length > 12) return res.status(400).json({ error: 'الحد الأقصى 12 عنصراً لكل مستوى' });
    const items = [];
    const seen = new Set();
    for (const it of rawItems) {
      const t = LEVEL_REWARD_ITEM_TABLES[it && it.item_type] ? it.item_type : '';
      const id = t ? String(it.item_id || '').trim().slice(0, 120) : '';
      if (!t || !id || seen.has(t + ':' + id)) continue;
      const exists = await get(`SELECT id FROM ${LEVEL_REWARD_ITEM_TABLES[t]} WHERE id = ?`, [id]);
      if (!exists) return res.status(400).json({ error: 'أحد العناصر غير موجود في قسمه' });
      seen.add(t + ':' + id);
      items.push({ item_type: t, item_id: id, item_days: Math.max(0, Math.min(3650, Math.floor(Number(it.item_days)) || 0)) });
    }
    const first = items[0] || { item_type: '', item_id: '', item_days: 0 };
    const tier = String(b.tier_name || '').trim().slice(0, 40);
    const perks = String(b.perks || '').trim().slice(0, 400);
    const active = b.is_active === false || b.is_active === 0 || b.is_active === '0' ? 0 : 1;
    // العمودان القديمان يحملان أول عنصر فقط للتوافق؛ القائمة الكاملة في level_reward_items
    await run(`
      INSERT INTO level_rewards (kind, level, tier_name, diamonds, coins, item_type, item_id, item_days, perks, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(kind, level) DO UPDATE SET tier_name = excluded.tier_name, diamonds = excluded.diamonds, coins = excluded.coins,
        item_type = excluded.item_type, item_id = excluded.item_id, item_days = excluded.item_days, perks = excluded.perks, is_active = excluded.is_active
    `, [kind, level, tier, diamonds, coins, first.item_type, first.item_id, first.item_days, perks, active]);
    await run('DELETE FROM level_reward_items WHERE kind = ? AND level = ?', [kind, level]);
    for (let i = 0; i < items.length; i++) {
      await run('INSERT OR IGNORE INTO level_reward_items (kind, level, item_type, item_id, item_days, sort) VALUES (?, ?, ?, ?, ?, ?)', [kind, level, items[i].item_type, items[i].item_id, items[i].item_days, i]);
    }
    res.json({ success: true, reward: (await attachRewardItems(kind, [await get('SELECT * FROM level_rewards WHERE kind = ? AND level = ?', [kind, level])], true))[0] });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// بطاقات العضو: الثروة / الرواج / VIP
app.get('/api/users/:id/member-card', async (req, res) => {
  try {
    const u = await get('SELECT * FROM users WHERE id = ?', [req.params.id]);
    if (!u) return res.status(404).json({ error: 'User not found' });
    res.json({ success: true, cards: memberLevels.buildCards(u) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// باقات VIP المتاحة للشراء
app.get('/api/vip/plans', async (req, res) => {
  try {
    const plans = await all('SELECT level, name, price_diamonds, original_price_diamonds, duration_days FROM vip_plans WHERE is_active = 1 ORDER BY level ASC');
    const uid = req.headers['x-user-id'];
    const u = uid ? await get('SELECT vip_level, vip_until, diamonds FROM users WHERE id = ?', [uid]) : null;
    res.json({
      success: true, plans,
      current: u ? { level: memberLevels.activeVipLevel(u), until: u.vip_until || null, days_left: memberLevels.vipDaysLeft(u) } : null,
      diamonds: u ? u.diamonds : null
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// شراء VIP بالألماس
app.post('/api/vip/buy', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    if (!userId) return res.status(401).json({ error: 'Unauthorized' });
    const level = Math.floor(Number(req.body && req.body.level));
    const plan = await get('SELECT * FROM vip_plans WHERE level = ? AND is_active = 1', [level]);
    if (!plan) return res.status(400).json({ error: 'باقة VIP غير متاحة' });

    const user = await get('SELECT * FROM users WHERE id = ?', [userId]);
    if (!user) return res.status(404).json({ error: 'المستخدم غير موجود' });

    const active = memberLevels.activeVipLevel(user);
    if (active > plan.level) {
      return res.status(400).json({ error: `لديك VIP${active} فعّال بالفعل، يمكنك تجديده أو الترقية لمستوى أعلى 👑` });
    }

    // خصم ذرّي: لا يمر إلا إذا الرصيد كافٍ
    const paid = await run('UPDATE users SET diamonds = diamonds - ? WHERE id = ? AND diamonds >= ?', [plan.price_diamonds, userId, plan.price_diamonds]);
    if (!paid.changes) return res.status(400).json({ error: 'عفواً، رصيد الألماس غير كافٍ! اشحن ألماساتك أولاً 💎' });

    const now = Date.now();
    const startedAt = active === plan.level ? user.vip_until : new Date(now).toISOString();
    const expiresAt = memberLevels.computeVipExpiry(user, plan.level, plan.duration_days, now);
    await run('UPDATE users SET vip_level = ?, vip_until = ? WHERE id = ?', [plan.level, expiresAt, userId]);
    await run(`
      INSERT INTO vip_subscriptions (id, user_id, level, duration_days, price_diamonds, source, started_at, expires_at)
      VALUES (?, ?, ?, ?, ?, 'purchase', ?, ?)
    `, [`vip-${now}-${uuidv4().slice(0, 6)}`, userId, plan.level, plan.duration_days, plan.price_diamonds, startedAt, expiresAt]);

    // الإنفاق على VIP يرفع نقاط الثروة
    const settings = await getPointSettings();
    const pts = memberLevels.pointsForAmount(plan.price_diamonds, 'diamonds', settings);
    await addMemberPoints(userId, 'wealth', pts);
    await addLevelPoints(userId, pts); // شراء VIP يرفع المستوى
    await logMemberActivity({
      user_id: userId, type: 'vip_purchase', ref_id: plan.level, ref_name: plan.name,
      amount: plan.price_diamonds, currency: 'diamonds', points: pts, points_kind: 'wealth'
    });

    await revokeVipBenefits(userId);                 // ترقية/تجديد: نبدأ من الصفر ثم نطبّق مزايا المستوى الجديد
    const vipItems = await applyVipBenefits(userId);
    const fresh = await get('SELECT * FROM users WHERE id = ?', [userId]);
    const set = userSockets.get(userId);
    if (set) for (const sId of set) io.to(sId).emit('balance_updated', { coins: fresh.coins, diamonds: fresh.diamonds, level: fresh.level });
    notifyMemberStats(userId);

    res.json({
      success: true,
      vip: { level: plan.level, until: expiresAt, days_left: memberLevels.vipDaysLeft(fresh), perks: vipPerks.perksForLevel(plan.level), items: vipItems },
      diamonds: fresh.diamonds,
      cards: memberLevels.buildCards(fresh)
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ───── لوحة الإدارة: نشاط الأعضاء والمستويات وVIP ─────
app.get('/api/admin/vip-plans', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    res.json({ success: true, plans: await all('SELECT * FROM vip_plans ORDER BY level ASC') });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.put('/api/admin/vip-plans/:level', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const level = Math.floor(Number(req.params.level));
    if (!(level >= 1 && level <= 99)) return res.status(400).json({ error: 'مستوى VIP غير صالح (1 - 99)' });
    const b = req.body || {};
    const name = String(b.name || `VIP ${level}`).trim().slice(0, 40) || `VIP ${level}`;
    const price = Math.max(0, Math.min(100000000, Math.floor(Number(b.price_diamonds)) || 0));
    const days = Math.max(1, Math.min(3650, Math.floor(Number(b.duration_days)) || 30));
    const active = b.is_active === false || b.is_active === 0 || b.is_active === '0' ? 0 : 1;
    const origRaw = Math.floor(Number(b.original_price_diamonds));
    const orig = origRaw > price ? Math.min(100000000, origRaw) : null; // السعر الأصلي يظهر فقط إن كان أعلى من السعر الحالي
    await run(`
      INSERT INTO vip_plans (level, name, price_diamonds, original_price_diamonds, duration_days, is_active) VALUES (?, ?, ?, ?, ?, ?)
      ON CONFLICT(level) DO UPDATE SET name = excluded.name, price_diamonds = excluded.price_diamonds,
        original_price_diamonds = excluded.original_price_diamonds,
        duration_days = excluded.duration_days, is_active = excluded.is_active
    `, [level, name, price, orig, days, active]);
    res.json({ success: true, plan: await get('SELECT * FROM vip_plans WHERE level = ?', [level]) });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// مزايا VIP الفعلية للعضو الحالي (للواجهة): ما فُتح له وما لم يُفتح
app.get('/api/me/vip-perks', async (req, res) => {
  try {
    const uid = req.headers['x-user-id'];
    if (!uid) return res.status(401).json({ error: 'Unauthorized' });
    const u = await get('SELECT id, vip_level, vip_until FROM users WHERE id = ?', [uid]);
    if (!u) return res.status(404).json({ error: 'User not found' });
    res.json({ success: true, level: memberLevels.activeVipLevel(u), until: u.vip_until || null, days_left: memberLevels.vipDaysLeft(u), perks: vipPerks.describe(u) });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// الإدارة: عناصر كل مستوى VIP (إطار / مؤثر دخول / فقاعة ...) تُمنح وتُفعَّل تلقائياً عند الشراء أو المنح
app.get('/api/admin/vip-level-items', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try { res.json({ success: true, items: await all(`SELECT v.level, v.item_type, v.item_id, s.category FROM vip_level_items v
    LEFT JOIN store_items s ON v.item_type = 'store_item' AND s.id = v.item_id ORDER BY v.level ASC, v.item_type ASC, s.category ASC`) }); }
  catch (err) { res.status(500).json({ error: err.message }); }
});
app.put('/api/admin/vip-level-items', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const list = Array.isArray(req.body && req.body.items) ? req.body.items.slice(0, 200) : null;
    if (!list) return res.status(400).json({ error: 'items مطلوبة' });
    const clean = [];
    for (const it of list) {
      const level = Math.floor(Number(it && it.level));
      const type = String((it && it.item_type) || '');
      const itemId = String((it && it.item_id) || '').trim();
      if (!itemId) continue;                                           // صف فارغ = إزالة العنصر
      if (!(level >= 1 && level <= 99)) return res.status(400).json({ error: 'مستوى VIP غير صالح' });
      if (!LEVEL_REWARD_ITEM_TABLES[type]) return res.status(400).json({ error: `نوع عنصر غير صالح: ${type}` });
      const exists = await get(`SELECT id${type === 'store_item' ? ', category' : ''} FROM ${LEVEL_REWARD_ITEM_TABLES[type]} WHERE id = ?`, [itemId]);
      if (!exists) return res.status(400).json({ error: `العنصر غير موجود: ${itemId}` });
      if (clean.some(c => c.level === level && c.item_type === type && c.item_id === itemId)) continue;   // تكرار حرفي لنفس العنصر: نتجاهله بصمت
      clean.push({ level, item_type: type, item_id: itemId });
    }
    await run('DELETE FROM vip_level_items');
    for (const c of clean) await run('INSERT OR REPLACE INTO vip_level_items (level, item_type, item_id) VALUES (?, ?, ?)', [c.level, c.item_type, c.item_id]);
    // أصحاب VIP الفعّال الآن يحصلون فوراً على الإعدادات الجديدة
    const holders = await all(`SELECT id FROM users WHERE COALESCE(vip_level, 0) > 0 AND vip_until > ?`, [new Date().toISOString()]);
    for (const h of holders) await applyVipBenefits(h.id, { silent: true });   // تحديث من الإدارة: بدون إشعار «تم تفعيل VIP» في الدردشة
    res.json({ success: true, items: clean, applied_to: holders.length });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// الإدارة: نقل ميزة VIP لمستوى آخر أو تعطيلها (0 = تعطيل). الافتراضي من vip-perks.js
app.get('/api/admin/vip-perks', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  res.json({ success: true, max_level: vipPerks.VIP_MAX, perks: vipPerks.VIP_PERKS.map(p => ({ key: p.key, group: p.group, name: p.name, default_level: p.level, level: Number.isFinite(vipPerks.perkLevel(p.key)) ? vipPerks.perkLevel(p.key) : 0 })) });
});
app.put('/api/admin/vip-perks', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const applied = vipPerks.configure(req.body && req.body.levels);
    const store = {};
    for (const [k, v] of Object.entries(applied)) store[k] = Number.isFinite(v) ? v : 0;
    await run(`INSERT INTO app_settings (key, value) VALUES ('vip_perk_levels', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value`, [JSON.stringify(store)]);
    res.json({ success: true, levels: store });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// منح أو سحب VIP يدوياً (level = 0 يعني سحب الاشتراك)
app.post('/api/admin/users/:id/vip', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const { id } = req.params;
    const user = await get('SELECT * FROM users WHERE id = ?', [id]);
    if (!user) return res.status(404).json({ error: 'المستخدم غير موجود' });
    const level = Math.max(0, Math.min(99, Math.floor(Number(req.body && req.body.level)) || 0));
    if (level === 0) {
      await run('UPDATE users SET vip_level = 0, vip_until = NULL WHERE id = ?', [id]);
    } else {
      const days = Math.max(1, Math.min(3650, Math.floor(Number(req.body && req.body.days)) || 30));
      const now = Date.now();
      const active = memberLevels.activeVipLevel(user);
      const startedAt = active === level ? user.vip_until : new Date(now).toISOString();
      const expiresAt = memberLevels.computeVipExpiry(user, level, days, now);
      await run('UPDATE users SET vip_level = ?, vip_until = ? WHERE id = ?', [level, expiresAt, id]);
      await run(`
        INSERT INTO vip_subscriptions (id, user_id, level, duration_days, price_diamonds, source, started_at, expires_at)
        VALUES (?, ?, ?, ?, 0, 'admin', ?, ?)
      `, [`vip-${now}-${uuidv4().slice(0, 6)}`, id, level, days, startedAt, expiresAt]);
      await logMemberActivity({ user_id: id, type: 'vip_grant', ref_id: level, ref_name: `VIP ${level}`, quantity: days });
    }
    await revokeVipBenefits(id);                     // يشمل الخفض والسحب (level = 0)
    if (level > 0) await applyVipBenefits(id);       // المنح الإداري يعطي نفس مزايا الشراء تماماً
    notifyMemberStats(id);
    const fresh = await get('SELECT * FROM users WHERE id = ?', [id]);
    res.json({ success: true, vip: { level: memberLevels.activeVipLevel(fresh), until: fresh.vip_until || null, days_left: memberLevels.vipDaysLeft(fresh), perks: vipPerks.perksForLevel(memberLevels.activeVipLevel(fresh)) } });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// سجل النشاط (هدايا مرسلة/مستلمة، شراء VIP)
app.get('/api/admin/member-activity', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const type = String(req.query.type || 'all');
    const q = String(req.query.q || '').trim();
    const limit = Math.max(1, Math.min(500, Math.floor(Number(req.query.limit)) || 100));
    let sql = `
      SELECT a.*, u.name AS user_name, u.avatar AS user_avatar, o.name AS other_name
      FROM member_activity a
      LEFT JOIN users u ON u.id = a.user_id
      LEFT JOIN users o ON o.id = a.other_user_id
      WHERE 1=1`;
    const params = [];
    if (type !== 'all') { sql += ' AND a.type = ?'; params.push(type); }
    if (q) { sql += ' AND (u.name LIKE ? OR a.user_id LIKE ? OR o.name LIKE ?)'; params.push(`%${q}%`, `%${q}%`, `%${q}%`); }
    sql += ' ORDER BY a.created_at DESC, a.rowid DESC LIMIT ?';
    params.push(limit);
    res.json({ success: true, activity: await all(sql, params) });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ملخص الأعضاء: النقاط والمستويات وVIP وعدد الهدايا
app.get('/api/admin/members-levels', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const q = String(req.query.q || '').trim();
    let sql = `
      SELECT u.id, u.name, u.avatar, u.coins, u.diamonds, u.level, u.wealth_points, u.wealth_level, u.popularity_points, u.charm_level,
             u.vip_level, u.vip_until,
             (SELECT COUNT(*) FROM member_activity a WHERE a.user_id = u.id AND a.type = 'gift_sent') AS gifts_sent,
             (SELECT COUNT(*) FROM member_activity a WHERE a.user_id = u.id AND a.type = 'gift_received') AS gifts_received
      FROM users u WHERE 1=1`;
    const params = [];
    if (q) { sql += ' AND (u.name LIKE ? OR u.email LIKE ? OR u.id LIKE ?)'; params.push(`%${q}%`, `%${q}%`, `%${q}%`); }
    sql += ' ORDER BY COALESCE(u.wealth_points, 0) + COALESCE(u.popularity_points, 0) DESC LIMIT 100';
    const rows = await all(sql, params);
    const now = Date.now();
    const members = rows.map(r => ({
      ...r,
      vip_active_level: memberLevels.activeVipLevel(r, now),
      vip_days_left: memberLevels.vipDaysLeft(r, now)
    }));
    const tot = await get(`
      SELECT
        (SELECT COUNT(*) FROM users WHERE COALESCE(vip_level, 0) > 0 AND vip_until > ?) AS vip_members,
        (SELECT COUNT(*) FROM member_activity WHERE type = 'gift_sent') AS gifts_sent,
        (SELECT COUNT(*) FROM member_activity WHERE type = 'vip_purchase') AS vip_purchases,
        (SELECT COALESCE(SUM(amount), 0) FROM member_activity WHERE type = 'vip_purchase') AS vip_revenue
    `, [new Date(now).toISOString()]);
    res.json({ success: true, members, totals: tot });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/admin/settings/points', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try { res.json({ success: true, settings: await getPointSettings() }); }
  catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/admin/settings/points', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const clamp = (v, d) => String(Math.min(1000000, Math.max(1, Math.floor(Number(v)) || d)));
    const b = req.body || {};
    await run(`INSERT INTO app_settings (key, value) VALUES ('coins_per_point', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value`, [clamp(b.coins_per_point, 10)]);
    await run(`INSERT INTO app_settings (key, value) VALUES ('diamonds_per_point', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value`, [clamp(b.diamonds_per_point, 1)]);
    res.json({ success: true, settings: await getPointSettings() });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// 21. Send Gift (in Room or Direct)
// تقدّم المستوى العام للمرسل (يُستخدم في شريط المستوى داخل نافذة الهدايا)
app.get('/api/me/level-info', async (req, res) => {
  try {
    const uid = req.headers['x-user-id'];
    if (!uid) return res.status(401).json({ error: 'Unauthorized' });
    const u = await get('SELECT level, level_points FROM users WHERE id = ?', [uid]);
    if (!u) return res.status(404).json({ error: 'not found' });
    res.json(memberLevels.levelFromPoints(u.level_points || 0));
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/gifts/send', async (req, res) => {
  try {
    const senderId = req.headers['x-user-id'];
    if (!senderId) return res.status(401).json({ error: 'Unauthorized' });

    const { receiver_id, room_id, gift_id } = req.body;
    // الكمية (x1 / x7 ...) وعدّاد الكومبو (للعرض فقط)
    const qty = Math.max(1, Math.min(99, parseInt(req.body.count, 10) || 1));
    const combo = Math.max(1, Math.min(9999, parseInt(req.body.combo, 10) || 1));
    if (!receiver_id) {
      return res.status(400).json({ error: 'يرجى تحديد الشخص المستلم للهدية أولاً! 👤🎁' });
    }

    const gift = await getGiftById(gift_id);
    if (!gift) return res.status(400).json({ error: 'Invalid gift' });

    const sender = await get('SELECT * FROM users WHERE id = ?', [senderId]);
    if (!sender) return res.status(404).json({ error: 'Sender not found' });

    // Check balance
    if (gift.currency === 'coins') {
      if (sender.coins < gift.cost * qty) {
        return res.status(400).json({ error: 'عفواً، رصيد العملات غير كافٍ! اشحن الآن أو احصل على مكافأتك اليومية 🪙' });
      }
      await run('UPDATE users SET coins = coins - ? WHERE id = ?', [gift.cost * qty, senderId]);
    } else {
      if (sender.diamonds < gift.cost * qty) {
        return res.status(400).json({ error: 'عفواً، رصيد الألماس غير كافٍ! اشحن ألماساتك لإرسال هدايا فاخرة 💎' });
      }
      await run('UPDATE users SET diamonds = diamonds - ? WHERE id = ?', [gift.cost * qty, senderId]);
    }

    // مكافأة المستلم بالعملات (الرواج يُحسب بالنقاط بعد تسجيل الهدية)
    if (receiver_id) {
      await creditGiftReward(receiver_id, Math.floor(gift.cost * qty * 0.4)); // الأنثى: تُعلَّق الأرباح حتى تُكمل مهام اليوم
    }

    // Record gift history (Saved in receiver's gifts wall)
    for (let qi = 0; qi < qty; qi++) {
      const historyId = `gift-${Date.now()}-${qi}-${Math.floor(Math.random() * 1000)}`;
      await run(`
        INSERT INTO gifts_history (id, sender_id, receiver_id, room_id, gift_id, gift_name, gift_icon, cost, currency)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [historyId, senderId, receiver_id, room_id, gift.id, gift.name, gift.image_url || gift.icon, gift.cost, gift.currency]);
    }

    // تسجيل النشاط والنقاط: المُرسل ← ثروة، المستلم ← رواج (لا رواج عند إهداء النفس)
    try {
      const ptSettings = await getPointSettings();
      const pts = memberLevels.pointsForAmount(gift.cost * qty, gift.currency, ptSettings);
      await addMemberPoints(senderId, 'wealth', pts);
      await addLevelPoints(senderId, pts); // إرسال الهدايا يرفع المستوى أيضاً
      if (room_id) recordMission(senderId, 'room_gift', 1);
      await logMemberActivity({ user_id: senderId, type: 'gift_sent', other_user_id: receiver_id, ref_id: gift.id, ref_name: gift.name,
        amount: gift.cost * qty, currency: gift.currency, points: pts, points_kind: 'wealth', room_id });
      if (receiver_id !== senderId) {
        await addMemberPoints(receiver_id, 'popularity', pts);
        await logMemberActivity({ user_id: receiver_id, type: 'gift_received', other_user_id: senderId, ref_id: gift.id, ref_name: gift.name,
          amount: gift.cost * qty, currency: gift.currency, points: pts, points_kind: 'popularity', room_id });
        notifyMemberStats(receiver_id);
      }
      notifyMemberStats(senderId);
    } catch (e) { console.error('member activity error:', e.message); }

    const updatedSender = await get('SELECT * FROM users WHERE id = ?', [senderId]);
    const receiver = receiver_id ? await get('SELECT id, name, avatar, charm_level FROM users WHERE id = ?', [receiver_id]) : null;

    const giftEventPayload = {
      count: qty,
      combo,
      gift,
      sender: { id: sender.id, name: sender.name, avatar: sender.avatar },
      receiver,
      room_id,
      timestamp: Date.now()
    };

    // Notify all clients so receiver's gifts wall updates in real time
    io.emit('user_gift_received', giftEventPayload);

    // إشعار خاص للشخص المُرسَل إليه الهدية (داخل الغرفة أو من المحادثة الخاصة)
    if (receiver_id) {
      try {
        const rs = userSockets.get(receiver_id);
        if (rs) for (const sockId of rs) io.to(sockId).emit('gift_received_notice', {
          gift, sender: { id: sender.id, name: sender.name, avatar: sender.avatar }, count: qty, room_id: room_id || null, timestamp: Date.now()
        });
      } catch (e) { console.error('gift notice error:', e.message); }
    }

    // هدية من داخل المحادثة الخاصة (بدون غرفة): تُسجَّل كرسالة خاصة بين الطرفين فقط ولا تظهر في أي غرفة
    let dmMessage = null;
    if (!room_id) {
      try {
        const iconTxt = (gift.icon && !/^(\/|https?:)/i.test(String(gift.icon))) ? ` ${gift.icon}` : '';
        const dmText = `أرسل هدية ${gift.name}${iconTxt}`;
        const dmId = `msg-${Date.now().toString()}-${uuidv4().slice(0, 4)}`;
        await run(`
          INSERT INTO messages (id, sender_id, receiver_id, message_type, content, metadata)
          VALUES (?, ?, ?, 'gift', ?, ?)
        `, [dmId, senderId, receiver_id, dmText, JSON.stringify(gift)]);
        dmMessage = await get(`
          SELECT m.*, u.name as sender_name, u.avatar as sender_avatar
          FROM messages m JOIN users u ON m.sender_id = u.id
          WHERE m.id = ?
        `, [dmId]);
        const rSockets = userSockets.get(receiver_id);
        if (rSockets && dmMessage) for (const sockId of rSockets) io.to(sockId).emit('private_message', dmMessage);
      } catch (e) { console.error('DM gift message error:', e.message); }
    }

    // Broadcast in room
    if (room_id) {
      io.to(`room:${room_id}`).emit('room_gift_sent', giftEventPayload);

      // إشعار عام لكل المتصلين (في أي غرفة) للهدايا التي فعّلت لها الإدارة خيار «إشعار عام»
      // يُنشأ من السيرفر فقط بعد خصم الرصيد، والنقر عليه يُدخل المستخدم إلى هذه الغرفة
      if (gift.banner_enabled || gift.luxury) {
        try {
          const roomRow = await get('SELECT id, title FROM rooms WHERE id = ?', [room_id]);
          io.emit('global_gift_banner', {
            id: `gb-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
            room_id,
            room_title: roomRow ? roomRow.title : '',
            gift,
            sender: { id: sender.id, name: sender.name, avatar: sender.avatar },
            receiver: receiver ? { id: receiver.id, name: receiver.name } : null,
            timestamp: Date.now()
          });
        } catch (e) { console.error('global gift banner error:', e.message); }
      }

      // Check if room has an active PK Battle: gifts directly increase the score and determine the winner!
      const roomState = activeRoomStates.get(room_id);
      if (roomState && roomState.pkState && roomState.pkState.active) {
        const isChallenger = receiver_id && (receiver_id === roomState.pkState.challenger?.id);
        const team = isChallenger ? 'challenger' : 'host';
        const points = gift.cost * qty;

        if (team === 'host') {
          roomState.pkState.hostScore += points;
        } else {
          roomState.pkState.challengerScore += points;
        }

        io.to(`room:${room_id}`).emit('pk_score_updated', {
          hostScore: roomState.pkState.hostScore,
          challengerScore: roomState.pkState.challengerScore,
          user: { id: sender.id, name: sender.name, avatar: sender.avatar },
          team,
          points,
          gift
        });
      }

      // رسالة عامة في شات الغرفة لكل الهدايا: «أرسل X إلى فلان»
      const msgId = `msg-${Date.now()}`;
      const giftQty = qty > 1 ? qty : combo;
      const recvName = receiver ? receiver.name : 'الجميع';
      const giftIconTxt = (gift.icon && !/^(\/|https?:)/i.test(String(gift.icon))) ? ` ${gift.icon}` : '';
      const giftNotice = gift.luxury
        ? `👑 الملك ${sender.name} يغمر ${recvName} بـ ${gift.name}${giftIconTxt}!`
        : `تم ارسال إلى ${recvName} ${gift.name} X${giftQty}`;
      await run(`
        INSERT INTO messages (id, sender_id, room_id, message_type, content, metadata)
        VALUES (?, ?, ?, 'gift', ?, ?)
      `, [msgId, senderId, room_id, giftNotice, JSON.stringify(gift)]);

      io.to(`room:${room_id}`).emit('room_message', {
        id: msgId,
        sender_id: sender.id,
        sender_name: sender.name,
        sender_avatar: sender.avatar,
        sender_frame: sender.avatar_frame,
        sender_level: sender.level,
        sender_chat_bubble: await getEquippedBubbleUrl(sender.id),
        message_type: 'gift',
        content: giftNotice,
        metadata: gift,
        created_at: new Date().toISOString()
      });
    }

    res.json({
      success: true,
      gift,
      sender: updatedSender,
      receiver,
      message: dmMessage,
      level_info: (() => { try { return memberLevels.levelFromPoints(updatedSender.level_points || 0); } catch (e) { return null; } })()
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ==========================================
// 21a. كيس الحظ (Lucky Bag) — يُرسل بالكرستالات (الألماس) ويُلتقط من أعضاء الغرفة
// ==========================================
const luckyBags = new Map(); // bagId -> bag
const LUCKY_BAG_AMOUNTS = [500, 2000, 5000];
const LUCKY_BAG_SHARES = 10;
const LUCKY_BAG_LIFETIME_MS = 10 * 60 * 1000;

function publicLuckyBag(b) {
  return {
    id: b.id, room_id: b.roomId, sender: b.sender, total: b.total,
    shares: b.shares, sharesLeft: b.sharesLeft, open_at: b.openAt,
    expires_at: b.expiresAt, claims: b.claims
  };
}

app.post('/api/lucky-bag/send', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    if (!userId) return res.status(401).json({ error: 'Unauthorized' });
    const { room_id } = req.body || {};
    const amount = parseInt(req.body?.amount, 10);
    const delayMs = req.body?.delay === 120 ? 120000 : 0;
    if (!room_id) return res.status(400).json({ error: 'يجب أن تكون داخل غرفة لإرسال كيس الحظ' });
    if (!LUCKY_BAG_AMOUNTS.includes(amount)) return res.status(400).json({ error: 'عدد الكريستال غير صالح' });

    const sender = await get('SELECT id, name, avatar FROM users WHERE id = ?', [userId]);
    if (!sender) return res.status(404).json({ error: 'المستخدم غير موجود' });

    const paid = await run('UPDATE users SET diamonds = diamonds - ? WHERE id = ? AND diamonds >= ?', [amount, userId, amount]);
    if (!paid.changes) return res.status(400).json({ error: 'عفواً، رصيد الكريستال غير كافٍ! اشحن ألماساتك أولاً 💎' });
    try {
      const pts = memberLevels.pointsForAmount(amount, 'diamonds', await getPointSettings());
      await addMemberPoints(userId, 'wealth', pts);
      await logMemberActivity({ user_id: userId, type: 'lucky_bag', ref_name: 'كيس الحظ', amount, currency: 'diamonds', points: pts, points_kind: 'wealth', room_id });
      notifyMemberStats(userId);
    } catch (e) { console.error('lucky bag points error:', e.message); }

    const now = Date.now();
    const bag = {
      id: `bag-${now}-${Math.floor(Math.random() * 1e4)}`,
      roomId: room_id, sender, total: amount, remaining: amount,
      shares: LUCKY_BAG_SHARES, sharesLeft: LUCKY_BAG_SHARES,
      openAt: now + delayMs, expiresAt: now + delayMs + LUCKY_BAG_LIFETIME_MS,
      claims: [], claimedBy: new Set()
    };
    luckyBags.set(bag.id, bag);

    setTimeout(async () => {
      const b = luckyBags.get(bag.id);
      if (!b) return;
      luckyBags.delete(bag.id);
      if (b.remaining > 0) {
        try { await run('UPDATE users SET diamonds = diamonds + ? WHERE id = ?', [b.remaining, b.sender.id]); } catch (e) {}
      }
      io.to(`room:${b.roomId}`).emit('lucky_bag_expired', { bagId: b.id, refunded: b.remaining });
    }, delayMs + LUCKY_BAG_LIFETIME_MS);

    io.to(`room:${room_id}`).emit('lucky_bag_created', publicLuckyBag(bag));
    const updated = await get('SELECT * FROM users WHERE id = ?', [userId]);
    res.json({ success: true, bag: publicLuckyBag(bag), user: updated });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/lucky-bag/room/:roomId', (req, res) => {
  const list = [];
  luckyBags.forEach(b => { if (b.roomId === req.params.roomId && b.sharesLeft > 0) list.push(publicLuckyBag(b)); });
  res.json(list);
});

app.post('/api/lucky-bag/:id/claim', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    if (!userId) return res.status(401).json({ error: 'Unauthorized' });
    const bag = luckyBags.get(req.params.id);
    if (!bag || bag.sharesLeft <= 0) return res.status(404).json({ error: 'انتهى كيس الحظ، حظاً أوفر المرة القادمة 🍀' });
    if (Date.now() < bag.openAt) return res.status(400).json({ error: 'لم يحن وقت فتح الكيس بعد ⏳' });
    if (bag.sender.id === userId) return res.status(400).json({ error: 'لا يمكنك التقاط كيس الحظ الذي أرسلته' });
    if (bag.claimedBy.has(userId)) return res.status(400).json({ error: 'التقطت حصتك من هذا الكيس بالفعل' });

    // توزيع عشوائي عادل: الحصة الأخيرة تأخذ ما تبقى
    let share;
    if (bag.sharesLeft === 1) share = bag.remaining;
    else {
      const avg = bag.remaining / bag.sharesLeft;
      share = Math.max(1, Math.min(bag.remaining - (bag.sharesLeft - 1), Math.floor(Math.random() * avg * 2) + 1));
    }
    bag.remaining -= share;
    bag.sharesLeft -= 1;
    bag.claimedBy.add(userId);

    await run('UPDATE users SET diamonds = diamonds + ? WHERE id = ?', [share, userId]);
    const user = await get('SELECT id, name, avatar FROM users WHERE id = ?', [userId]);
    bag.claims.push({ user, amount: share });

    io.to(`room:${bag.roomId}`).emit('lucky_bag_claimed', { bagId: bag.id, user, amount: share, sharesLeft: bag.sharesLeft });
    if (bag.sharesLeft <= 0) luckyBags.delete(bag.id);

    const updated = await get('SELECT * FROM users WHERE id = ?', [userId]);
    res.json({ success: true, amount: share, user: updated });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 21b. Get User's Received Gifts ("هداياه")
app.get('/api/users/:id/gifts', async (req, res) => {
  try {
    const userId = req.params.id;
    const summary = await all(`
      SELECT gift_id, gift_name, gift_icon, cost, currency, COUNT(*) as count, MAX(created_at) as last_received_at
      FROM gifts_history
      WHERE receiver_id = ?
      GROUP BY gift_id
      ORDER BY count DESC, cost DESC
    `, [userId]);

    const recent = await all(`
      SELECT gh.*, u.name as sender_name, u.avatar as sender_avatar
      FROM gifts_history gh
      LEFT JOIN users u ON gh.sender_id = u.id
      WHERE gh.receiver_id = ?
      ORDER BY gh.created_at DESC
      LIMIT 30
    `, [userId]);

    // المرسلون لكل هدية مع الكمية التي أرسلها كل واحد
    const senderRows = await all(`
      SELECT gh.gift_id, gh.sender_id, COUNT(*) as qty, MAX(gh.created_at) as last_at,
             u.name as sender_name, u.avatar as sender_avatar
      FROM gifts_history gh
      LEFT JOIN users u ON gh.sender_id = u.id
      WHERE gh.receiver_id = ?
      GROUP BY gh.gift_id, gh.sender_id
      ORDER BY qty DESC, last_at DESC
    `, [userId]);
    const sendersByGift = {};
    senderRows.forEach(r => {
      (sendersByGift[r.gift_id] = sendersByGift[r.gift_id] || []).push({
        sender_id: r.sender_id,
        sender_name: r.sender_name || 'مستخدم محذوف',
        sender_avatar: r.sender_avatar || '',
        qty: r.qty,
        last_at: r.last_at
      });
    });
    summary.forEach(g => { g.senders = sendersByGift[g.gift_id] || []; });

    const totalCount = summary.reduce((acc, g) => acc + (g.count || 0), 0);
    const totalValue = summary.reduce((acc, g) => acc + ((g.cost || 0) * (g.count || 0)), 0);

    res.json({
      summary,
      recent,
      totalCount,
      totalValue
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 21c. Toggle Favorite Rooms ("المفضلة")
app.post('/api/rooms/:id/favorite', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'] || req.body?.user_id;
    const roomId = req.params.id;
    if (!userId) return res.status(401).json({ error: 'Unauthorized' });

    const existing = await get('SELECT * FROM favorite_rooms WHERE user_id = ? AND room_id = ?', [userId, roomId]);
    let favorited = false;
    if (existing) {
      await run('DELETE FROM favorite_rooms WHERE user_id = ? AND room_id = ?', [userId, roomId]);
      favorited = false;
    } else {
      await run('INSERT INTO favorite_rooms (user_id, room_id) VALUES (?, ?)', [userId, roomId]);
      favorited = true;
    }

    const rows = await all('SELECT room_id FROM favorite_rooms WHERE user_id = ? ORDER BY created_at DESC', [userId]);
    const fanRow = await get('SELECT COUNT(*) AS c FROM favorite_rooms WHERE room_id = ?', [roomId]);
    if (favorited) {
      try {
        const favRoom = await get('SELECT id, title, host_id FROM rooms WHERE id = ?', [roomId]);
        const favUser = await get('SELECT name, avatar FROM users WHERE id = ?', [userId]);
        if (favRoom && favUser) {
          io.to(`room:${roomId}`).emit('room_message', {
            id: `sys-fav-${Date.now()}`,
            sender_id: 'system',
            sender_name: '❤️ المفضلة',
            sender_avatar: favUser.avatar,
            sender_level: 1,
            message_type: 'system',
            content: `${favUser.name} أضاف الغرفة إلى المفضلة ❤️`,
            created_at: new Date().toISOString()
          });
          const hostSockets = userSockets.get(favRoom.host_id);
          if (hostSockets) hostSockets.forEach(sid => io.to(sid).emit('room_favorited', {
            roomId, roomTitle: favRoom.title, userName: favUser.name, userAvatar: favUser.avatar, fanCount: fanRow.c
          }));
        }
      } catch (e) { console.error('favorite notify error:', e); }
    }
    res.json({
      success: true,
      favorited,
      fan_count: fanRow.c,
      favoriteRoomIds: rows.map(r => r.room_id)
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ==========================================
// نظام المتابعة (Follow) + الإشعارات
// ==========================================
function emitToUser(userId, event, payload) {
  const set = userSockets.get(userId);
  if (set) set.forEach(sid => io.to(sid).emit(event, payload));
}

async function followCounts(userId) {
  const a = await get('SELECT COUNT(*) AS c FROM follows WHERE following_id = ?', [userId]);
  const b = await get('SELECT COUNT(*) AS c FROM follows WHERE follower_id = ?', [userId]);
  return { followers_count: a.c, following_count: b.c };
}

// متابعة مستخدم
app.post('/api/users/:id/follow', async (req, res) => {
  try {
    const viewerId = req.headers['x-user-id'];
    const targetId = req.params.id;
    if (!viewerId) return res.status(401).json({ error: 'Unauthorized' });
    if (viewerId === targetId) return res.status(400).json({ error: 'لا يمكنك متابعة نفسك' });
    const viewer = await get('SELECT id, name, avatar FROM users WHERE id = ?', [viewerId]);
    const target = await get('SELECT id FROM users WHERE id = ?', [targetId]);
    if (!viewer || !target) return res.status(404).json({ error: 'User not found' });

    const exists = await get('SELECT 1 AS x FROM follows WHERE follower_id = ? AND following_id = ?', [viewerId, targetId]);
    if (!exists) {
      // حد المتابعة: أساسي للجميع، ويرتفع لمن فتح امتياز «زيادة عدد المتابعين»
      const vw = await get('SELECT wealth_level FROM users WHERE id = ?', [viewerId]);
      const lim = await getFollowLimits();
      const boosted = userHasPerkSync(vw, 'follow_boost', 35);
      const cap = boosted ? lim.boost : lim.base;
      const cur = await get('SELECT COUNT(*) AS c FROM follows WHERE follower_id = ?', [viewerId]);
      if ((cur && cur.c || 0) >= cap) {
        const need = perkLevelSync('follow_boost', 35);
        return res.status(400).json({ success: false, code: 'FOLLOW_LIMIT', limit: cap,
          error: boosted || !Number.isFinite(need) ? `وصلت للحد الأقصى للمتابعة (${cap})` : `وصلت للحد الأقصى للمتابعة (${cap}). ارفع مستوى الثروة إلى Lv${need} لزيادة الحد` });
      }
      await run('INSERT INTO follows (follower_id, following_id) VALUES (?, ?)', [viewerId, targetId]);
      const notifId = `notif-${uuidv4()}`;
      const createdAt = new Date().toISOString();
      await run(
        'INSERT INTO notifications (id, user_id, type, actor_id, content, created_at) VALUES (?, ?, ?, ?, ?, ?)',
        [notifId, targetId, 'follow', viewerId, 'قام بمتابعتك', createdAt]
      );
      const followsBack = await get('SELECT 1 AS x FROM follows WHERE follower_id = ? AND following_id = ?', [targetId, viewerId]);
      emitToUser(targetId, 'new_notification', {
        id: notifId, type: 'follow', content: 'قام بمتابعتك', created_at: createdAt, is_read: 0,
        actor_id: viewer.id, actor_name: viewer.name, actor_avatar: viewer.avatar,
        is_following_actor: !!followsBack
      });
      emitToUser(targetId, 'follow_stats_changed', { userId: targetId });
      recordMission(viewerId, 'follows', 1);
      if (followsBack) { recordMission(viewerId, 'friends', 1); recordMission(targetId, 'friends', 1); }
    }
    const counts = await followCounts(targetId);
    res.json({ success: true, is_following: true, ...counts });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// إلغاء المتابعة
app.delete('/api/users/:id/follow', async (req, res) => {
  try {
    const viewerId = req.headers['x-user-id'];
    const targetId = req.params.id;
    if (!viewerId) return res.status(401).json({ error: 'Unauthorized' });
    await run('DELETE FROM follows WHERE follower_id = ? AND following_id = ?', [viewerId, targetId]);
    // نزيل إشعار المتابعة القديم حتى لا يتكرر عند إعادة المتابعة
    await run("DELETE FROM notifications WHERE user_id = ? AND actor_id = ? AND type = 'follow'", [targetId, viewerId]);
    emitToUser(targetId, 'follow_stats_changed', { userId: targetId });
    const counts = await followCounts(targetId);
    res.json({ success: true, is_following: false, ...counts });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// إبلاغ عن مستخدم (من نافذة الملف الشخصي داخل الغرفة)
app.post('/api/users/:id/report', async (req, res) => {
  try {
    const viewerId = req.headers['x-user-id'];
    const targetId = req.params.id;
    if (!viewerId) return res.status(401).json({ error: 'Unauthorized' });
    if (viewerId === targetId) return res.status(400).json({ error: 'لا يمكنك الإبلاغ عن نفسك' });
    const reason = String((req.body && req.body.reason) || '').slice(0, 300);
    const roomId = String((req.body && req.body.room_id) || '').slice(0, 100) || null;
    const reporter = await get('SELECT vip_level, vip_until FROM users WHERE id = ?', [viewerId]);
    const priority = vipPerks.hasPerk(reporter, 'report_priority') ? 1 : 0;   // ميزة VIP «أولوية الإبلاغ»
    await run('INSERT INTO user_reports (reporter_id, reported_id, room_id, reason, priority) VALUES (?, ?, ?, ?, ?)', [viewerId, targetId, roomId, reason, priority]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// إضافة إلى قائمة الحظر (ويلغي المتابعة بين الطرفين)
app.post('/api/users/:id/block', async (req, res) => {
  try {
    const viewerId = req.headers['x-user-id'];
    const targetId = req.params.id;
    if (!viewerId) return res.status(401).json({ error: 'Unauthorized' });
    if (viewerId === targetId) return res.status(400).json({ error: 'لا يمكنك حظر نفسك' });
    await run('INSERT OR IGNORE INTO user_blocks (user_id, blocked_id) VALUES (?, ?)', [viewerId, targetId]);
    await run('DELETE FROM follows WHERE (follower_id = ? AND following_id = ?) OR (follower_id = ? AND following_id = ?)', [viewerId, targetId, targetId, viewerId]);
    emitToUser(targetId, 'follow_stats_changed', { userId: targetId });
    emitToUser(viewerId, 'follow_stats_changed', { userId: viewerId });
    res.json({ success: true, blocked: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// حذف شخص من متابعيّ (يتوقف عن متابعتي)
app.delete('/api/users/:id/follower', async (req, res) => {
  try {
    const viewerId = req.headers['x-user-id'];
    const followerId = req.params.id;
    if (!viewerId) return res.status(401).json({ error: 'Unauthorized' });
    await run('DELETE FROM follows WHERE follower_id = ? AND following_id = ?', [followerId, viewerId]);
    emitToUser(viewerId, 'follow_stats_changed', { userId: viewerId });
    emitToUser(followerId, 'follow_stats_changed', { userId: followerId });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// إحصائيات المتابعة لأي ملف شخصي (متاحة لأي زائر)
app.get('/api/users/:id/follow-stats', async (req, res) => {
  try {
    const viewerId = req.headers['x-user-id'] || '';
    const targetId = req.params.id;
    const counts = await followCounts(targetId);
    const f1 = viewerId ? await get('SELECT 1 AS x FROM follows WHERE follower_id = ? AND following_id = ?', [viewerId, targetId]) : null;
    const f2 = viewerId ? await get('SELECT 1 AS x FROM follows WHERE follower_id = ? AND following_id = ?', [targetId, viewerId]) : null;
    res.json({ ...counts, is_following: !!f1, follows_me: !!f2 });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// قائمة المتابِعين / من يتابعهم — عامة: يراها أي زائر وليس صاحب الحساب فقط
async function listFollowRelations(req, res, mode) {
  try {
    const viewerId = req.headers['x-user-id'] || '';
    const targetId = req.params.id;
    const joinCol = mode === 'followers' ? 'f.follower_id' : 'f.following_id';
    const whereCol = mode === 'followers' ? 'f.following_id' : 'f.follower_id';
    const rows = await all(`
      SELECT u.id, u.name, u.avatar, u.avatar_frame, u.level, u.soul_planet, u.bio, u.gender, u.age,
             f.created_at AS followed_at,
             CASE WHEN vf.follower_id IS NULL THEN 0 ELSE 1 END AS is_following
      FROM follows f
      JOIN users u ON u.id = ${joinCol}
      LEFT JOIN follows vf ON vf.follower_id = ? AND vf.following_id = u.id
      WHERE ${whereCol} = ?
      ORDER BY f.created_at DESC
      LIMIT 500
    `, [viewerId, targetId]);
    res.json({ users: rows.map(r => ({ ...r, is_following: !!r.is_following, is_me: r.id === viewerId })) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
app.get('/api/users/:id/followers', (req, res) => listFollowRelations(req, res, 'followers'));
app.get('/api/users/:id/following', (req, res) => listFollowRelations(req, res, 'following'));

// الأصدقاء = متابعة متبادلة
app.get('/api/users/:id/friends', async (req, res) => {
  try {
    const viewerId = req.headers['x-user-id'] || '';
    const targetId = req.params.id;
    const rows = await all(`
      SELECT u.id, u.name, u.avatar, u.avatar_frame, u.level, u.wealth_level, u.charm_level, u.vip_level, u.vip_until, u.gender, u.age, u.country_code,
             CASE WHEN vf.follower_id IS NULL THEN 0 ELSE 1 END AS is_following
      FROM follows a
      JOIN follows b ON b.follower_id = a.following_id AND b.following_id = a.follower_id
      JOIN users u ON u.id = a.following_id
      LEFT JOIN follows vf ON vf.follower_id = ? AND vf.following_id = u.id
      WHERE a.follower_id = ?
      ORDER BY a.created_at DESC
      LIMIT 500
    `, [viewerId, targetId]);
    res.json({ users: rows.map(r => ({ ...r, is_following: !!r.is_following, is_me: r.id === viewerId })) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// تسجيل زيارة لملف شخصي (يتجاهل زيارة الشخص لصفحته)
app.post('/api/users/:id/visit', async (req, res) => {
  try {
    const visitorId = req.headers['x-user-id'];
    const ownerId = req.params.id;
    if (!visitorId || visitorId === ownerId) return res.json({ success: true, skipped: true });
    const owner = await get('SELECT id FROM users WHERE id = ?', [ownerId]);
    const visitor = await get('SELECT id FROM users WHERE id = ?', [visitorId]);
    if (!owner || !visitor) return res.json({ success: true, skipped: true });
    await run(`INSERT INTO profile_visits (visitor_id, owner_id) VALUES (?, ?)
      ON CONFLICT(visitor_id, owner_id) DO UPDATE SET visits = visits + 1, last_visited = CURRENT_TIMESTAMP`, [visitorId, ownerId]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// أرقام صفحة «أنت»: الأصدقاء / أتابع / المتابعون / الزوار
app.get('/api/users/:id/profile-stats', async (req, res) => {
  try {
    const id = req.params.id;
    const counts = await followCounts(id);
    const fr = await get(`SELECT COUNT(*) AS c FROM follows a JOIN follows b ON b.follower_id = a.following_id AND b.following_id = a.follower_id WHERE a.follower_id = ?`, [id]);
    const vs = await get('SELECT COUNT(*) AS c FROM profile_visits WHERE owner_id = ?', [id]);
    let postsCount = 0;
    try { const pc = await get('SELECT COUNT(*) AS c FROM moments WHERE user_id = ?', [id]); postsCount = pc ? pc.c : 0; } catch (e) {}
    res.json({ ...counts, friends_count: fr.c, visitors_count: vs.c, posts_count: postsCount });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// زائرين صفحتي / زياراتي (لصاحب الحساب فقط)
async function listProfileVisits(req, res, mode) {
  try {
    const viewerId = req.headers['x-user-id'] || '';
    const targetId = req.params.id;
    if (!viewerId || viewerId !== targetId) return res.status(403).json({ error: 'غير مسموح' });
    const joinCol = mode === 'visitors' ? 'p.visitor_id' : 'p.owner_id';
    const whereCol = mode === 'visitors' ? 'p.owner_id' : 'p.visitor_id';
    const rows = await all(`
      SELECT u.id, u.name, u.avatar, u.avatar_frame, u.level, u.wealth_level, u.charm_level, u.vip_level, u.vip_until, u.gender, u.age, u.country_code,
             p.last_visited, p.visits,
             CASE WHEN vf.follower_id IS NULL THEN 0 ELSE 1 END AS is_following
      FROM profile_visits p
      JOIN users u ON u.id = ${joinCol}
      LEFT JOIN follows vf ON vf.follower_id = ? AND vf.following_id = u.id
      WHERE ${whereCol} = ?
      ORDER BY p.last_visited DESC
      LIMIT 200
    `, [viewerId, targetId]);
    const users = [];
    for (const r of rows) {
      let post_images = [];
      try {
        const ms = await all(`SELECT image_url FROM moments WHERE user_id = ? AND image_url IS NOT NULL AND image_url != '' ORDER BY created_at DESC LIMIT 2`, [r.id]);
        post_images = ms.map(m => m.image_url);
      } catch (e) { /* بدون صور */ }
      users.push({ ...r, is_following: !!r.is_following, is_online: !!(userSockets.get(r.id) && userSockets.get(r.id).size > 0), post_images });
    }
    res.json({ users });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
app.get('/api/users/:id/visitors', (req, res) => listProfileVisits(req, res, 'visitors'));
app.get('/api/users/:id/visits', (req, res) => listProfileVisits(req, res, 'visits'));

// الإشعارات
app.get('/api/notifications', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    if (!userId) return res.status(401).json({ error: 'Unauthorized' });
    const rows = await all(`
      SELECT n.id, n.type, n.content, n.is_read, n.created_at, n.actor_id,
             u.name AS actor_name, u.avatar AS actor_avatar, u.avatar_frame AS actor_frame,
             CASE WHEN f.follower_id IS NULL THEN 0 ELSE 1 END AS is_following_actor
      FROM notifications n
      LEFT JOIN users u ON u.id = n.actor_id
      LEFT JOIN follows f ON f.follower_id = n.user_id AND f.following_id = n.actor_id
      WHERE n.user_id = ?
      ORDER BY n.created_at DESC
      LIMIT 60
    `, [userId]);
    const unread = await get('SELECT COUNT(*) AS c FROM notifications WHERE user_id = ? AND is_read = 0', [userId]);
    res.json({
      unread: unread.c,
      notifications: rows.map(r => ({ ...r, is_following_actor: !!r.is_following_actor }))
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/notifications/read', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    if (!userId) return res.status(401).json({ error: 'Unauthorized' });
    await run('UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0', [userId]);
    res.json({ success: true, unread: 0 });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ==========================================
// مركز اهتماماتي (المفضلة / تم الانضمام / ما سبق / إدارتي) + المتابَعون في الغرف الآن
// ==========================================
function shapeInterestRooms(rows) {
  return rows.map(r => {
    const st = activeRoomStates.get(r.id);
    return {
      id: r.id, title: r.title, category: r.category, is_locked: r.is_locked ? 1 : 0, has_password: r.access_hash ? 1 : 0,
      cover_image: r.cover_image || null, country_code: r.country_code, country_flag: r.country_flag,
      host_id: r.host_id, host_name: r.host_name, host_avatar: r.host_avatar, host_frame: r.host_frame,
      audience_count: st ? visibleAudienceCount(st) : 0,
      at: r.at || null
    };
  });
}

// المتابَعون الموجودون في غرف الآن
async function getFollowedInRooms(userId) {
  const followingRows = await all('SELECT following_id FROM follows WHERE follower_id = ?', [userId]);
  const following = new Set(followingRows.map(r => r.following_id));
  if (!following.size) return { following, list: [] };
  const seen = new Map();
  for (const [roomId, st] of activeRoomStates.entries()) {
    for (const [uid, u] of st.activeAudience.entries()) {
      if (u && u.hidden_entry) continue; // المتخفّون لا يظهرون للآخرين
      if (following.has(uid) && !seen.has(uid)) seen.set(uid, { user: u, roomId });
    }
  }
  const list = [];
  for (const [uid, v] of seen.entries()) {
    const room = await get('SELECT id, title, category FROM rooms WHERE id = ?', [v.roomId]);
    if (!room) continue;
    const st = activeRoomStates.get(v.roomId);
    list.push({
      id: uid, name: v.user.name, avatar: v.user.avatar, avatar_frame: v.user.avatar_frame || null,
      room_id: room.id, room_title: room.title, room_category: room.category,
      room_audience: st ? visibleAudienceCount(st) : 0
    });
  }
  list.sort((a, b) => b.room_audience - a.room_audience);
  return { following, list };
}

// المتابَعون الموجودون الآن في غرف (لشريط الأشخاص فوق قائمة الغرف)
app.get('/api/following/in-rooms', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    if (!userId) return res.json({ users: [] });
    const { list } = await getFollowedInRooms(userId);
    res.json({ users: list });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ملخص خفيف للفقاعة في تبويب الحفلة
app.get('/api/interests/summary', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    if (!userId) return res.json({ count: 0, first: null });
    const { list } = await getFollowedInRooms(userId);
    res.json({ count: list.length, first: list[0] ? { name: list[0].name, avatar: list[0].avatar } : null });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/interests', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    if (!userId) return res.status(401).json({ error: 'Unauthorized' });
    const base = `SELECT r.*, u.name AS host_name, u.avatar AS host_avatar, u.avatar_frame AS host_frame`;

    const favorites = shapeInterestRooms(await all(`${base}, f.created_at AS at FROM favorite_rooms f JOIN rooms r ON r.id = f.room_id JOIN users u ON u.id = r.host_id WHERE f.user_id = ? ORDER BY f.created_at DESC`, [userId]));
    const joined = shapeInterestRooms(await all(`${base}, m.last_joined AS at FROM room_members m JOIN rooms r ON r.id = m.room_id JOIN users u ON u.id = r.host_id WHERE m.user_id = ? ORDER BY m.last_joined DESC`, [userId]));
    const history = shapeInterestRooms(await all(`${base}, v.last_visited AS at FROM room_visits v JOIN rooms r ON r.id = v.room_id JOIN users u ON u.id = r.host_id WHERE v.user_id = ? ORDER BY v.last_visited DESC LIMIT 50`, [userId]));
    const managed = shapeInterestRooms(await all(`${base}, r.created_at AS at FROM rooms r JOIN users u ON u.id = r.host_id WHERE r.host_id = ? OR r.co_host_id = ? OR r.id IN (SELECT room_id FROM room_moderators WHERE user_id = ?) ORDER BY r.created_at DESC`, [userId, userId, userId]));

    const { following, list: followedInRooms } = await getFollowedInRooms(userId);

    // اقتراح 3 أشخاص متوافقين: الأكثر اشتراكاً في الاهتمامات، والمتواجدون في الغرف أولاً
    const me = await get('SELECT soul_tags FROM users WHERE id = ?', [userId]);
    const myTags = new Set(String((me && me.soul_tags) || '').split(',').map(t => t.trim()).filter(Boolean));
    const inRoom = new Map();
    for (const [roomId, st] of activeRoomStates.entries()) {
      for (const uid of st.activeAudience.keys()) if (!inRoom.has(uid)) inRoom.set(uid, roomId);
    }
    const others = await all('SELECT id, name, avatar, avatar_frame, soul_tags, country_code FROM users WHERE id != ? LIMIT 300', [userId]);
    const scored = others.filter(u => !following.has(u.id)).map(u => {
      const tags = String(u.soul_tags || '').split(',').map(t => t.trim()).filter(Boolean);
      const shared = tags.filter(t => myTags.has(t)).length;
      const roomId = inRoom.get(u.id) || null;
      const st = roomId ? activeRoomStates.get(roomId) : null;
      return { id: u.id, name: u.name, avatar: u.avatar, avatar_frame: u.avatar_frame, country_code: u.country_code,
        room_id: roomId, room_audience: st ? visibleAudienceCount(st) : 0, score: shared * 10 + (roomId ? 5 : 0) };
    }).sort((a, b) => b.score - a.score).slice(0, 3);

    res.json({
      counts: { favorites: favorites.length, joined: joined.length, history: history.length, managed: managed.length },
      favorites, joined, history, managed,
      followed_in_rooms: followedInRooms,
      recommended: scored
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// إلغاء الانضمام لغرفة (زر "إلغاء" في تبويب تم الانضمام)
app.post('/api/rooms/:id/unjoin', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    if (!userId) return res.status(401).json({ error: 'Unauthorized' });
    await run('DELETE FROM room_members WHERE room_id = ? AND user_id = ?', [req.params.id, userId]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ==========================================
// ADMIN CONTROL PANEL ROUTES & API
// ==========================================

// ==========================================
// أشخاص الغرفة: الأونلاين / الأعضاء / المشرفون / المطرودون / المكتومون / المعجبون
// ==========================================
async function canManageRoom(room, user) {
  if (!room || !user) return false;
  if (room.host_id === user.id) return true;
  if (['owner', 'super_master', 'super_admin', 'admin', 'moderator'].includes(user.role)) return true;
  const m = await get('SELECT 1 AS x FROM room_moderators WHERE room_id = ? AND user_id = ?', [room.id, user.id]);
  return !!m;
}
function isRoomOwnerLevel(room, user) {
  return !!(room && user && (room.host_id === user.id || ['owner', 'super_master', 'super_admin'].includes(user.role)));
}

// ───────── صلاحيات الثروة داخل الغرف ─────────
//  • ثروة 21+  : كتم الكتابة وطرد الأعضاء الأقل ثروة (ما لم يكونوا مدراء الغرفة أو الإدارة)
//  • ثروة 26+  : حصانة كاملة من الكتم والطرد من أي عضو أو مشرف غرفة (تبقى فقط لصاحب الغرفة وإدارة المنصة)
const WEALTH_MOD_LEVEL = 21;
const immuneLevel = () => perkLevelSync('no_kick', 26); // يتحدد من امتياز «لا يمكن طردك من الغرف» في الإدارة
function isTargetImmune(room, actor, target) {
  if (!target) return false;
  // حصانة VIP (ميزة «حصانة من الطرد»): حتى صاحب الغرفة لا يستطيع، ويبقى فقط لإدارة المنصة
  if (vipPerks.hasPerk(target, 'kick_immunity')) return !(actor && PLATFORM_ADMIN_ROLES.includes(actor.role));
  if ((Number(target.wealth_level) || 1) < immuneLevel()) return false;
  if (isRoomOwnerLevel(room, actor) || (actor && actor.role === 'admin')) return false;
  return true;
}
// هل يستطيع actor تنفيذ كتم/طرد على target؟ (مدير الغرفة أو صاحب ثروة أعلى)
async function canActOnTarget(room, actor, target) {
  if (!room || !actor) return false;
  const manager = await canManageRoom(room, actor);
  if (manager) return !isTargetImmune(room, actor, target);
  if (!target || target.id === actor.id) return false;
  const aw = Number(actor.wealth_level) || 1, tw = Number(target.wealth_level) || 1;
  if (aw < WEALTH_MOD_LEVEL || aw <= tw) return false;
  if (isTargetImmune(room, actor, target)) return false;
  if (room.host_id === target.id || await canManageRoom(room, target)) return false; // لا سلطة على مدراء الغرفة
  const st = activeRoomStates.get(room.id);
  if (st && st.activeAudience && !st.activeAudience.has(actor.id)) return false; // يجب أن يكون داخل الغرفة
  return true;
}
function actDeniedMessage(room, actor, target) {
  return isTargetImmune(room, actor, target) ? 'هذا العضو يتمتع بحصانة ملكية 👑 ولا يمكن كتمه أو طرده' : 'ليس لديك صلاحيات إدارة هذه الغرفة!';
}

// ───────── حماية المقعد (المايك) ─────────
// ثروة 26+: لا يمكن إنزاله من المايك (طرد المقعد / قفل المقعد / قفل كل المقاعد) من صاحب الغرفة أو المشرفين.
// الاستثناء الوحيد: إدارة المنصة نفسها (owner / super_master / super_admin / admin).
const PLATFORM_ADMIN_ROLES = ['owner', 'super_master', 'super_admin', 'admin'];
function isSeatProtected(actor, target) {
  if (!target) return false;
  if (!vipPerks.hasPerk(target, 'kick_immunity') && (Number(target.wealth_level) || 1) < immuneLevel()) return false;
  if (actor && PLATFORM_ADMIN_ROLES.includes(actor.role)) return false;
  return true;
}
const SEAT_PROTECTED_MSG = 'هذا العضو يتمتع بحصانة ملكية 👑 ولا يمكن إنزاله من المايك';

// ───────── إشعار المشرف عند محاولة المساس بعضو محميّ ─────────
// يُرسَل للمشرف الذي حاول (الطرد / الكتم / الإنزال من المايك) فقط، ولا يُنفَّذ أي إجراء على العضو.
const BLOCKED_TEXT = { kick: (n) => `طرد «${n}» من الغرفة`, mute: (n) => `كتم «${n}»`, seat: (n) => `إنزال «${n}» من المايك` };
function emitModerationDone(sock, message) { sock.emit('moderation_done', { message }); }
function emitModerationBlocked(sock, action, target, customMessage) {
  const name = (target && target.name) ? target.name : 'هذا العضو';
  const what = (BLOCKED_TEXT[action] || ((n) => `تنفيذ هذا الإجراء على «${n}»`))(name);
  const message = customMessage || `لا يمكنك ${what} بسبب مستواه العالي 👑`;
  sock.emit('moderation_blocked', { action, targetId: target ? target.id : null, targetName: name, message });
  sock.emit('error_message', { message });
}

// ───────── الدخول المخفي ─────────
// الإدارة تحدد من لوحة التحكم: من يحق له الدخول متخفياً (مستوى معيّن من الثروة/الرواج/العام، المشرفون، إدارة المنصة).
// عند دخول مستحق للميزة يُخيَّر بين «مخفي» و«ظاهر». المتخفي لا يظهر في قائمة الحضور ولا يُحسب في العدد ولا يظهر له إشعار/تأثير دخول.
const HIDDEN_ENTRY_KINDS = ['wealth', 'charm', 'general'];
const HIDDEN_ENTRY_DEFAULT = { enabled: true, include_moderators: true, include_admins: true, rules: [] };
function normalizeHiddenEntrySettings(raw) {
  const out = { enabled: HIDDEN_ENTRY_DEFAULT.enabled, include_moderators: HIDDEN_ENTRY_DEFAULT.include_moderators, include_admins: HIDDEN_ENTRY_DEFAULT.include_admins, rules: [] };
  if (!raw || typeof raw !== 'object') return out;
  if (typeof raw.enabled === 'boolean') out.enabled = raw.enabled;
  if (typeof raw.include_moderators === 'boolean') out.include_moderators = raw.include_moderators;
  if (typeof raw.include_admins === 'boolean') out.include_admins = raw.include_admins;
  if (Array.isArray(raw.rules)) {
    const seen = new Set();
    for (const r of raw.rules.slice(0, 20)) {
      const kind = HIDDEN_ENTRY_KINDS.includes(r && r.kind) ? r.kind : null;
      const lvl = Math.floor(Number(r && r.min_level));
      if (!kind || !Number.isFinite(lvl) || lvl < 1) continue;
      const min_level = Math.min(999, lvl);
      const key = kind + ':' + min_level;
      if (seen.has(key)) continue;
      seen.add(key);
      out.rules.push({ kind, min_level });
    }
  }
  return out;
}
async function getHiddenEntrySettings() {
  try {
    const row = await get(`SELECT value FROM app_settings WHERE key = 'hidden_entry_settings'`);
    return normalizeHiddenEntrySettings(row && row.value ? JSON.parse(row.value) : null);
  } catch (e) { return normalizeHiddenEntrySettings(null); }
}
async function canEnterHidden(room, u) {
  if (!u) return false;
  const cfg = await getHiddenEntrySettings();
  if (!cfg.enabled) return false;
  if (cfg.include_admins && PLATFORM_ADMIN_ROLES.includes(u.role)) return true;
  if (cfg.include_moderators) {
    if (u.role === 'moderator') return true;
    if (room && room.id) {
      const m = await get('SELECT 1 AS x FROM room_moderators WHERE room_id = ? AND user_id = ?', [room.id, u.id]);
      if (m) return true;
    }
  }
  const lv = { wealth: Number(u.wealth_level) || 1, charm: Number(u.charm_level) || 1, general: Number(u.level) || 1 };
  if (vipPerks.hasPerk(u, 'mr_x_rooms')) return true;             // ميزة VIP «Mr.X بالغرف»
  return cfg.rules.some(r => lv[r.kind] >= r.min_level);
}
function visibleAudienceList(st) {
  if (!st || !st.activeAudience) return [];
  return Array.from(st.activeAudience.values()).filter(u => !(u && u.hidden_entry));
}
function visibleAudienceCount(st) { return visibleAudienceList(st).length; }

app.get('/api/admin/settings/hidden-entry', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try { res.json({ success: true, settings: await getHiddenEntrySettings() }); }
  catch (err) { res.status(500).json({ error: err.message }); }
});
app.post('/api/admin/settings/hidden-entry', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const clean = normalizeHiddenEntrySettings(req.body || {});
    await run(`INSERT INTO app_settings (key, value) VALUES ('hidden_entry_settings', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value`, [JSON.stringify(clean)]);
    res.json({ success: true, settings: clean });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/rooms/:id/people', async (req, res) => {
  try {
    const roomId = req.params.id;
    const room = await get('SELECT * FROM rooms WHERE id = ?', [roomId]);
    if (!room) return res.status(404).json({ error: 'الغرفة غير موجودة' });
    const uid = req.headers['x-user-id'];
    const viewer = uid ? await get('SELECT id, role FROM users WHERE id = ?', [uid]) : null;
    const manager = await canManageRoom(room, viewer);
    const ownerLevel = isRoomOwnerLevel(room, viewer);
    const cols = 'u.id, u.name, u.avatar, u.avatar_frame, u.level, u.wealth_level, u.role, u.gender, u.age, u.vip_level, u.vip_until';
    const members = await all(`SELECT ${cols}, m.last_joined, m.visits FROM room_members m JOIN users u ON u.id = m.user_id WHERE m.room_id = ? ORDER BY m.last_joined DESC LIMIT 1000`, [roomId]);
    const total = await get('SELECT COUNT(*) AS c FROM room_members WHERE room_id = ?', [roomId]);
    const moderators = await all(`SELECT ${cols} FROM room_moderators d JOIN users u ON u.id = d.user_id WHERE d.room_id = ?`, [roomId]);
    const st = activeRoomStates.get(roomId);
    // ميزة VIP «الصف الأمامي»: أصحابها على قمة القائمة (الأعلى مستوى أولاً) والباقي بترتيبه
    const frontRank = (u) => vipPerks.hasPerk(u, 'front_row') ? memberLevels.activeVipLevel(u) : 0;
    const online = st ? visibleAudienceList(st).slice().sort((a, b) => frontRank(b) - frontRank(a)) : [];
    const onlineIds = new Set(online.map(o => o.id));
    const left = members.filter(m => !onlineIds.has(m.id)); // دخلوا الغرفة ثم غادروها
    const out = { host_id: room.host_id, total_members: total.c, members, moderators, online, left, total_left: left.length, can_manage: manager, is_owner: ownerLevel };
    if (manager) {
      out.bans = await all(`SELECT ${cols} FROM room_restrictions r JOIN users u ON u.id = r.user_id WHERE r.room_id = ? AND r.type = 'ban'`, [roomId]);
      out.mutes = await all(`SELECT ${cols} FROM room_restrictions r JOIN users u ON u.id = r.user_id WHERE r.room_id = ? AND r.type = 'mute'`, [roomId]);
    }
    if (ownerLevel) {
      out.fans = await all(`SELECT ${cols}, f.created_at AS saved_at FROM favorite_rooms f JOIN users u ON u.id = f.user_id WHERE f.room_id = ? ORDER BY f.created_at DESC`, [roomId]);
      out.fan_count = out.fans.length;
    }
    res.json(out);
  } catch (err) {
    console.error('people error:', err);
    res.status(500).json({ error: 'تعذر تحميل القائمة' });
  }
});

// حالة شخص داخل الغرفة + صلاحية من يشاهده (لبطاقة المستخدم داخل الغرفة)
app.get('/api/rooms/:id/relation/:userId', async (req, res) => {
  try {
    const roomId = req.params.id;
    const room = await get('SELECT * FROM rooms WHERE id = ?', [roomId]);
    if (!room) return res.status(404).json({ error: 'الغرفة غير موجودة' });
    const uid = req.headers['x-user-id'];
    const viewer = uid ? await get('SELECT id, role FROM users WHERE id = ?', [uid]) : null;
    const target = req.params.userId;
    const q = async (sql) => !!(await get(sql, [roomId, target]));
    res.json({
      viewer_can_manage: await canManageRoom(room, viewer),
      viewer_is_owner: isRoomOwnerLevel(room, viewer),
      is_host: room.host_id === target,
      is_member: await q('SELECT 1 AS x FROM room_members WHERE room_id = ? AND user_id = ?'),
      is_moderator: await q('SELECT 1 AS x FROM room_moderators WHERE room_id = ? AND user_id = ?'),
      is_banned: await q("SELECT 1 AS x FROM room_restrictions WHERE room_id = ? AND user_id = ? AND type = 'ban'"),
      is_muted: await q("SELECT 1 AS x FROM room_restrictions WHERE room_id = ? AND user_id = ? AND type = 'mute'")
    });
  } catch (err) {
    res.status(500).json({ error: 'تعذر تحميل الحالة' });
  }
});

// دعوة عضو (إضافته لأعضاء الغرفة) / طرد عضو (إزالة عضويته)
app.post('/api/rooms/:id/members', async (req, res) => {
  try {
    const roomId = req.params.id;
    const room = await get('SELECT * FROM rooms WHERE id = ?', [roomId]);
    const viewer = req.headers['x-user-id'] ? await get('SELECT id, name, role FROM users WHERE id = ?', [req.headers['x-user-id']]) : null;
    if (!room || !(await canManageRoom(room, viewer))) return res.status(403).json({ error: 'ليس لديك صلاحية' });
    const { user_id, add } = req.body;
    const target = await get('SELECT id, name FROM users WHERE id = ?', [user_id]);
    if (!target) return res.status(404).json({ error: 'المستخدم غير موجود' });
    if (add) {
      await run(`INSERT INTO room_members (room_id, user_id) VALUES (?, ?)
        ON CONFLICT(room_id, user_id) DO NOTHING`, [roomId, user_id]);
    } else {
      await run('DELETE FROM room_members WHERE room_id = ? AND user_id = ?', [roomId, user_id]);
    }
    res.json({ success: true, is_member: !!add });
  } catch (err) {
    res.status(500).json({ error: 'تعذر تحديث الأعضاء' });
  }
});

// استدعاء المعجبين: إشعار لكل من حفظ الغرفة بدعوة للدخول (لصاحب الغرفة فقط، مرة كل دقتين)
const fanCallLast = new Map();
app.post('/api/rooms/:id/call-fans', async (req, res) => {
  try {
    const roomId = req.params.id;
    const room = await get('SELECT * FROM rooms WHERE id = ?', [roomId]);
    const viewer = req.headers['x-user-id'] ? await get('SELECT id, name, avatar, role FROM users WHERE id = ?', [req.headers['x-user-id']]) : null;
    if (!room || !isRoomOwnerLevel(room, viewer)) return res.status(403).json({ error: 'فقط صاحب الغرفة يمكنه استدعاء المعجبين' });
    const last = fanCallLast.get(roomId) || 0;
    if (Date.now() - last < 120000) return res.status(429).json({ error: 'انتظر قليلاً قبل استدعاء المعجبين مرة أخرى' });
    const fans = await all('SELECT user_id FROM favorite_rooms WHERE room_id = ?', [roomId]);
    if (!fans.length) return res.json({ success: true, count: 0 });
    fanCallLast.set(roomId, Date.now());
    const createdAt = new Date().toISOString();
    for (const f of fans) {
      if (f.user_id === viewer.id) continue;
      const notifId = `notif-${uuidv4()}`;
      const content = `يدعوك للانضمام إلى غرفة «${room.title}»`;
      await run('INSERT INTO notifications (id, user_id, type, actor_id, content, created_at) VALUES (?, ?, ?, ?, ?, ?)', [notifId, f.user_id, 'room_call', viewer.id, content, createdAt]);
      emitToUser(f.user_id, 'new_notification', {
        id: notifId, type: 'room_call', content, created_at: createdAt, is_read: 0,
        actor_id: viewer.id, actor_name: viewer.name, actor_avatar: viewer.avatar, room_id: roomId
      });
    }
    res.json({ success: true, count: fans.filter(f => f.user_id !== viewer.id).length });
  } catch (err) {
    res.status(500).json({ error: 'تعذر استدعاء المعجبين' });
  }
});

app.post('/api/rooms/:id/moderators', async (req, res) => {
  try {
    const roomId = req.params.id;
    const room = await get('SELECT * FROM rooms WHERE id = ?', [roomId]);
    const viewer = req.headers['x-user-id'] ? await get('SELECT id, name, role FROM users WHERE id = ?', [req.headers['x-user-id']]) : null;
    if (!room || !isRoomOwnerLevel(room, viewer)) return res.status(403).json({ error: 'فقط صاحب الغرفة يمكنه تعيين المشرفين' });
    const { user_id, add } = req.body;
    const target = await get('SELECT id, name FROM users WHERE id = ?', [user_id]);
    if (!target) return res.status(404).json({ error: 'المستخدم غير موجود' });
    if (add) {
      const already = await get('SELECT 1 AS x FROM room_moderators WHERE room_id = ? AND user_id = ?', [roomId, user_id]);
      const cnt = await get('SELECT COUNT(*) AS c FROM room_moderators WHERE room_id = ?', [roomId]);
      if (!already && cnt.c >= 3) return res.status(400).json({ error: 'وصلت للحد الأقصى: 3 مشرفين في الغرفة' });
    }
    if (add) await run('INSERT OR IGNORE INTO room_moderators (room_id, user_id) VALUES (?, ?)', [roomId, user_id]);
    else await run('DELETE FROM room_moderators WHERE room_id = ? AND user_id = ?', [roomId, user_id]);
    io.to(`room:${roomId}`).emit('room_message', {
      id: `sys-mod-${Date.now()}`, sender_id: 'system', sender_name: '🛡️ إدارة الغرفة', sender_avatar: viewer.avatar,
      sender_level: 99, message_type: 'system',
      content: add ? `تم تعيين ${target.name} مشرفاً في الغرفة 🛡️` : `تمت إزالة ${target.name} من المشرفين`,
      created_at: new Date().toISOString()
    });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'تعذر تحديث المشرفين' });
  }
});

app.post('/api/rooms/:id/restrictions/remove', async (req, res) => {
  try {
    const roomId = req.params.id;
    const room = await get('SELECT * FROM rooms WHERE id = ?', [roomId]);
    const viewer = req.headers['x-user-id'] ? await get('SELECT id, name, role FROM users WHERE id = ?', [req.headers['x-user-id']]) : null;
    if (!room || !(await canManageRoom(room, viewer))) return res.status(403).json({ error: 'ليس لديك صلاحية' });
    const { user_id, type } = req.body;
    if (!['ban', 'mute'].includes(type)) return res.status(400).json({ error: 'نوع غير صحيح' });
    await run('DELETE FROM room_restrictions WHERE room_id = ? AND user_id = ? AND type = ?', [roomId, user_id, type]);
    const st = activeRoomStates.get(roomId);
    if (st) (type === 'ban' ? st.bannedUsers : st.mutedChatUsers).delete(user_id);
    if (type === 'mute') {
      const t = await get('SELECT name FROM users WHERE id = ?', [user_id]);
      io.to(`room:${roomId}`).emit('user_chat_mute_changed', { roomId, targetUserId: user_id, targetUserName: t ? t.name : 'مستخدم', isMuted: false, adminName: viewer.name });
    }
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'تعذر فك القيد' });
  }
});

// Serve Admin Dashboard HTML
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

// 1. Admin Login (Username & Password)
app.post('/api/admin/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: 'يرجى إدخال اسم المستخدم وكلمة المرور' });
    }

    // A. Check in admin_credentials table
    const cred = await get('SELECT * FROM admin_credentials WHERE username = ? AND password = ?', [username, password]);
    if (cred) {
      if (cred.role === 'admin') {
        return res.status(403).json({
          error: 'صلاحية دخول لوحة الإدارة مخصصة فقط للسوبر ادمن والسوبر ماستر والمالك! رتبة الأدمن تمتلك صلاحيات الإشراف داخل الغرف الصوتية فقط.'
        });
      }
      const token = `adm_${Date.now()}_${Math.random().toString(36).substring(2, 12)}`;
      const role = cred.role || 'owner';
      adminSessions.set(token, { username: cred.username, role, loginTime: Date.now() });
      return res.json({
        success: true,
        token,
        admin: { username: cred.username, role }
      });
    }

    // Check if user has role 'admin' (strictly blocked from control panel)
    const adminRoleUser = await get("SELECT * FROM users WHERE (email = ? OR name = ? OR id = ?) AND role = 'admin'", [username, username, username]);
    if (adminRoleUser) {
      return res.status(403).json({
        error: 'صلاحية دخول لوحة الإدارة مخصصة فقط للسوبر ادمن والسوبر ماستر والمالك! رتبة الأدمن تمتلك صلاحيات الإشراف داخل الغرف الصوتية فقط.'
      });
    }

    // B. Check in users table for owner, super_master, or super_admin accounts ONLY
    const user = await get("SELECT * FROM users WHERE (email = ? OR name = ? OR id = ? OR (role = 'owner' AND ? IN ('owner', 'owner@gmail.com'))) AND (role IN ('owner', 'super_master', 'super_admin'))", [username, username, username, username]);
    if (user && (password === 'admin123456' || password === 'admin' || password === 'owner123' || password === 'owner123456' || password === 'owner')) {
      const token = `adm_${Date.now()}_${Math.random().toString(36).substring(2, 12)}`;
      adminSessions.set(token, { username: user.name, role: user.role, userId: user.id, loginTime: Date.now() });
      return res.json({
        success: true,
        token,
        admin: { username: user.name, role: user.role, userId: user.id }
      });
    }

    return res.status(401).json({ error: 'اسم المستخدم أو كلمة المرور غير صحيحة!' });
  } catch (err) {
    console.error('Admin login error:', err);
    res.status(500).json({ error: err.message });
  }
});

// دخول التطبيق بحساب السوبر الذي سجّل به الأدمن في لوحة الإدارة (لفتح الغرف مباشرة)
app.post('/api/admin/enter-as-user', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    let user = null;
    if (session.userId) {
      user = await get('SELECT * FROM users WHERE id = ?', [session.userId]);
    }
    if (!user && session.username) {
      user = await get(
        "SELECT * FROM users WHERE (name = ? OR email = ?) AND role IN ('owner','super_master','super_admin') LIMIT 1",
        [session.username, session.username]
      );
    }
    if (!user) {
      // حساب لوحة الإدارة غير مرتبط بمستخدم: نختار حساب الرتبة نفسها، ثم الأعلى رتبة
      const order = ['owner', 'super_master', 'super_admin'];
      const roles = session.role && order.includes(session.role)
        ? [session.role, ...order.filter(r => r !== session.role)]
        : order;
      for (const r of roles) {
        user = await get('SELECT * FROM users WHERE role = ? ORDER BY created_at ASC LIMIT 1', [r]);
        if (user) break;
      }
    }
    if (!user) return res.status(404).json({ error: 'لا يوجد حساب سوبر مرتبط بحساب الإدارة' });
    res.json({ success: true, user });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 2. Check Admin Session
app.get('/api/admin/check-session', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) {
    return res.status(401).json({ error: 'جلسة الإدارة غير صالحة أو انتهت مدتها' });
  }
  res.json({ success: true, admin: session });
});

// 3. Admin Logout
app.post('/api/admin/logout', (req, res) => {
  const token = req.headers['x-admin-token'] || (req.headers.authorization && req.headers.authorization.split(' ')[1]);
  if (token && adminSessions.has(token)) {
    adminSessions.delete(token);
  }
  res.json({ success: true });
});

// 4. Admin Overview & Platform Statistics
app.get('/api/admin/stats', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });

  try {
    const totalUsersRow = await get('SELECT COUNT(*) as count FROM users');
    const totalRoomsRow = await get('SELECT COUNT(*) as count FROM rooms');
    const totalModsRow = await get("SELECT COUNT(*) as count FROM users WHERE role = 'moderator'");
    const totalCoinsRow = await get('SELECT SUM(coins) as total_coins, SUM(diamonds) as total_diamonds FROM users');
    const totalGiftsRow = await get('SELECT COUNT(*) as count, SUM(cost) as total_value FROM gifts_history');

    // Build real live rooms list with real occupant numbers
    const allRooms = await all(`
      SELECT r.*, u.name as host_name, u.avatar as host_avatar
      FROM rooms r
      JOIN users u ON r.host_id = u.id
      ORDER BY r.created_at DESC
    `);

    const liveRooms = [];
    for (const r of allRooms) {
      const roomState = activeRoomStates.get(r.id);
      const realOccupants = roomState ? visibleAudienceCount(roomState) : 0;
      liveRooms.push({
        id: r.id,
        title: r.title,
        room_type: r.room_type,
        category: r.category,
        host_name: r.host_name,
        host_avatar: r.host_avatar,
        country_code: r.country_code,
        country_name: r.country_name,
        country_flag: r.country_flag,
        occupants_count: realOccupants,
        created_at: r.created_at
      });
    }

    res.json({
      success: true,
      stats: {
        totalUsers: totalUsersRow ? totalUsersRow.count : 0,
        totalRooms: totalRoomsRow ? totalRoomsRow.count : 0,
        onlineUsers: userSockets.size || onlineUsers.size,
        totalModerators: totalModsRow ? totalModsRow.count : 0,
        totalCoins: totalCoinsRow ? (totalCoinsRow.total_coins || 0) : 0,
        totalDiamonds: totalCoinsRow ? (totalCoinsRow.total_diamonds || 0) : 0,
        totalGiftsSent: totalGiftsRow ? (totalGiftsRow.count || 0) : 0,
        totalGiftsValue: totalGiftsRow ? (totalGiftsRow.total_value || 0) : 0,
        liveRooms
      }
    });
  } catch (err) {
    console.error('Admin stats error:', err);
    res.status(500).json({ error: err.message });
  }
});

// 5. Admin Users List with Search & Filter
app.get('/api/admin/users', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });

  try {
    const q = req.query.q ? req.query.q.trim() : '';
    const role = req.query.role;
    let query = 'SELECT id, name, email, avatar, bio, gender, age, soul_planet, role, coins, diamonds, level, is_banned, created_at FROM users WHERE 1=1';
    const params = [];

    if (q) {
      query += ' AND (name LIKE ? OR email LIKE ? OR id LIKE ?)';
      params.push(`%${q}%`, `%${q}%`, `%${q}%`);
    }
    if (role && role !== 'all') {
      if (role === 'staff') {
        query += ' AND role IN ("super_master", "super_admin", "admin", "moderator")';
      } else {
        query += ' AND role = ?';
        params.push(role);
      }
    }

    query += ' ORDER BY created_at DESC';
    const users = await all(query, params);

    const list = users.map(u => ({
      ...u,
      is_online: userSockets.has(u.id) && userSockets.get(u.id).size > 0
    }));

    res.json({ success: true, users: list });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 6. Appoint or Change User Role (Roles: 'super_master', 'super_admin', 'admin', 'user', 'owner')
app.post('/api/admin/users/:id/role', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });

  try {
    const { id } = req.params;
    const { role } = req.body; // 'super_master', 'super_admin', 'admin', 'user', 'owner', 'moderator'
    const allowed = ['super_master', 'super_admin', 'admin', 'moderator', 'owner', 'user'];
    if (!allowed.includes(role)) {
      return res.status(400).json({ error: 'الرتبة المحددة غير صحيحة' });
    }

    await run('UPDATE users SET role = ? WHERE id = ?', [role, id]);
    const updatedUser = await get('SELECT id, name, role, email, avatar FROM users WHERE id = ?', [id]);
    if (!updatedUser) {
      return res.status(404).json({ error: 'المستخدم غير موجود' });
    }

    const roleTitles = {
      super_master: 'سوبر ماستر 💎',
      super_admin: 'سوبر ادمن ⚡',
      admin: 'ادمن للدردشة 🛡️',
      moderator: 'مشرف عام 🛡️',
      owner: 'مالك المنصة 👑',
      user: 'عضو عادي'
    };

    // Send real-time socket event to the user
    const userSocketSet = userSockets.get(id);
    if (userSocketSet && userSocketSet.size > 0) {
      for (const sId of userSocketSet) {
        io.to(sId).emit('user_role_updated', {
          role,
          roleTitle: roleTitles[role] || role,
          message: ['super_master', 'super_admin', 'admin', 'moderator', 'owner'].includes(role)
            ? `تهانينا! تم تعيينك برتبة [${roleTitles[role] || role}] على منصة SoulChill! 🪐✨`
            : 'تم تعديل رتبتك إلى عضو عادي.'
        });
      }
    }

    // Broadcast announcement if promoted to staff
    if (['super_master', 'super_admin', 'admin', 'moderator'].includes(role)) {
      io.emit('room_message', {
        id: `sys-mod-${Date.now()}`,
        sender_id: 'system',
        sender_name: '🛡️ الإدارة العليا',
        sender_avatar: updatedUser.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
        sender_level: 99,
        message_type: 'system',
        content: `🎉 نبارك للعضو [${updatedUser.name}] تعيينه [${roleTitles[role] || role}] على المنصة! 🛡️✨`,
        created_at: new Date().toISOString()
      });
    }

    res.json({ success: true, user: updatedUser, roleTitle: roleTitles[role] || role });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 7. Update User Balance & Level
app.post('/api/admin/users/:id/balance', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });

  try {
    const { id } = req.params;
    const { coins, diamonds, level } = req.body;
    await run(`
      UPDATE users 
      SET coins = COALESCE(?, coins),
          diamonds = COALESCE(?, diamonds),
          level = COALESCE(?, level)
      WHERE id = ?
    `, [coins, diamonds, level, id]);

    const updatedUser = await get('SELECT id, name, coins, diamonds, level FROM users WHERE id = ?', [id]);
    if (!updatedUser) {
      return res.status(404).json({ error: 'المستخدم غير موجود' });
    }

    const userSocketSet = userSockets.get(id);
    if (userSocketSet) {
      for (const sId of userSocketSet) {
        io.to(sId).emit('balance_updated', {
          coins: updatedUser.coins,
          diamonds: updatedUser.diamonds,
          level: updatedUser.level
        });
      }
    }

    res.json({ success: true, user: updatedUser });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 7b. إضافة رصيد (يُجمع على الرصيد الحالي) — تعبئة الأرصدة من الإدارة
app.post('/api/admin/users/:id/add-balance', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const { id } = req.params;
    const coins = Math.floor(Number((req.body || {}).coins || 0));
    const diamonds = Math.floor(Number((req.body || {}).diamonds || 0));
    if (!Number.isFinite(coins) || !Number.isFinite(diamonds) || coins < 0 || diamonds < 0 || (coins === 0 && diamonds === 0)) {
      return res.status(400).json({ success: false, message: 'أدخل كمية صحيحة (أكبر من صفر)' });
    }
    if (coins > 1000000000 || diamonds > 1000000000) {
      return res.status(400).json({ success: false, message: 'الكمية كبيرة جداً' });
    }
    const exists = await get('SELECT id FROM users WHERE id = ?', [id]);
    if (!exists) return res.status(404).json({ success: false, message: 'المستخدم غير موجود' });
    await run('UPDATE users SET coins = coins + ?, diamonds = diamonds + ? WHERE id = ?', [coins, diamonds, id]);
    // تعبئة الرصيد من الإدارة تضيف نقاط الثروة حسب الألماس المضاف (والمستوى كنوع من الشراء)
    if (diamonds > 0) {
      try {
        const ps = await getPointSettings();
        const pts = memberLevels.pointsForAmount(diamonds, 'diamonds', ps);
        await addMemberPoints(id, 'wealth', pts);
        await addLevelPoints(id, pts);
        notifyMemberStats(id);
      } catch (e) {}
    }
    const updated = await get('SELECT id, name, coins, diamonds, level FROM users WHERE id = ?', [id]);
    const set = userSockets.get(id);
    if (set) {
      for (const sId of set) {
        io.to(sId).emit('balance_updated', {
          coins: updated.coins, diamonds: updated.diamonds, level: updated.level,
          added: { coins, diamonds }
        });
      }
    }
    res.json({ success: true, user: updated });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 8. Ban or Unban User
app.post('/api/admin/users/:id/ban', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });

  try {
    const { id } = req.params;
    const { is_banned } = req.body;
    await run('UPDATE users SET is_banned = ? WHERE id = ?', [is_banned ? 1 : 0, id]);

    if (is_banned) {
      // Disconnect all active sockets for this user immediately
      const userSocketSet = userSockets.get(id);
      if (userSocketSet) {
        for (const sId of userSocketSet) {
          const s = io.sockets.sockets.get(sId);
          if (s) {
            s.emit('account_banned_notice', { message: 'لقد تم حظر حسابك من قبل إدارة التطبيق! 🚫' });
            s.disconnect(true);
          }
        }
      }
    }

    res.json({ success: true, is_banned: !!is_banned });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 9. Delete User
app.delete('/api/admin/users/:id', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });

  try {
    const { id } = req.params;
    const u = await get('SELECT role FROM users WHERE id = ?', [id]);
    if (u && u.role === 'owner') {
      return res.status(403).json({ error: 'لا يمكن حذف حساب مالك التطبيق!' });
    }

    await run('DELETE FROM room_seats WHERE user_id = ?', [id]);
    const userRooms = await all('SELECT id FROM rooms WHERE host_id = ?', [id]);
    for (const r of userRooms) {
      await run('DELETE FROM room_seats WHERE room_id = ?', [r.id]);
      await run('DELETE FROM rooms WHERE id = ?', [r.id]);
      io.to(`room:${r.id}`).emit('room_closed_by_host', { roomId: r.id, adminName: 'إدارة المنصة' });
      io.emit('room_deleted', { roomId: r.id });
    }
    await run('DELETE FROM users WHERE id = ?', [id]);

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 10. Admin Rooms List with Real Occupants Count
app.get('/api/admin/rooms', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });

  try {
    const rooms = await all(`
      SELECT r.*, u.name as host_name, u.avatar as host_avatar, u.email as host_email
      FROM rooms r
      JOIN users u ON r.host_id = u.id
      ORDER BY r.created_at DESC
    `);

    for (const r of rooms) {
      const roomState = activeRoomStates.get(r.id);
      r.occupants_count = roomState ? visibleAudienceCount(roomState) : 0;
      const seats = await all('SELECT seat_index, user_id FROM room_seats WHERE room_id = ? AND user_id IS NOT NULL', [r.id]);
      r.occupied_seats = seats.length;
    }

    res.json({ success: true, rooms });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 11. Admin Force Close / Delete Room
app.delete('/api/admin/rooms/:id', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });

  try {
    const { id } = req.params;
    await run('DELETE FROM room_seats WHERE room_id = ?', [id]);
    await run('DELETE FROM rooms WHERE id = ?', [id]);

    io.to(`room:${id}`).emit('room_closed_by_host', { roomId: id, adminName: 'إدارة المنصة العليا' });
    io.emit('room_deleted', { roomId: id });

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 12. Broadcast Global Announcement Banner to All Users & Rooms
app.post('/api/admin/broadcast', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });

  try {
    const { message } = req.body;
    if (!message || !message.trim()) {
      return res.status(400).json({ error: 'نص الإعلان فارغ' });
    }

    io.emit('global_announcement', {
      message: message.trim(),
      sender: '👑 إدارة SoulChill العليا'
    });
    io.emit('global_system_broadcast', {
      title: 'إعلان من إدارة SoulChill',
      message: message.trim(),
      sender: '👑 إدارة SoulChill العليا'
    });
    io.emit('global_announcement_broadcast', {
      message: message.trim()
    });

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 13. Change Admin Credentials (Username and Password)
app.post('/api/admin/change-credentials', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });

  try {
    const { username, password } = req.body;
    if (!username || !password || password.length < 6) {
      return res.status(400).json({ error: 'يجب أن تتكون كلمة المرور من 6 أحرف أو أرقام على الأقل' });
    }

    const exists = await get('SELECT id FROM admin_credentials LIMIT 1');
    if (exists) {
      await run('UPDATE admin_credentials SET username = ?, password = ? WHERE id = ?', [username, password, exists.id]);
    } else {
      await run('INSERT INTO admin_credentials (username, password, role) VALUES (?, ?, "admin")', [username, password]);
    }

    res.json({ success: true, message: 'تم تحديث بيانات الدخول بنجاح!' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 14. Admin Create Room directly from Dashboard (Voice Room)
// ===================== إعدادات الغرفة (مطابقة لقائمة التحكم في الفيديو) =====================
const ROOM_SEAT_OPTIONS = [3, 5, 9, 15];
const SEAT_15_PRICE = 49990;      // كريستال لفتح 15 مقعد
const SEAT_9_MEMBERS_NEEDED = 10; // أعضاء الغرفة المطلوبون لفتح 9 مقاعد
const ROOM_STAFF_ROLES = ['owner', 'super_master', 'super_admin', 'admin', 'moderator'];
const jparse = (t, d) => { try { return t ? JSON.parse(t) : d; } catch (e) { return d; } };

async function requireRoomManager(req, res) {
  const room = await get('SELECT * FROM rooms WHERE id = ?', [req.params.id]);
  if (!room) { res.status(404).json({ error: 'الغرفة غير موجودة' }); return null; }
  const uid = req.headers['x-user-id'];
  const user = uid ? await get('SELECT * FROM users WHERE id = ?', [uid]) : null;
  if (!user || !(await canManageRoom(room, user))) { res.status(403).json({ error: 'غير مصرح لك بتعديل الغرفة' }); return null; }
  return { room, user };
}
async function ensureSeatRows(roomId, upTo) {
  const room = await get('SELECT seat_settings FROM rooms WHERE id = ?', [roomId]);
  const globalMute = !!jparse(room && room.seat_settings, {}).global_mute;
  for (let i = 0; i <= upTo; i++) {
    const isMuted = i > 0 && globalMute ? 1 : 0;
    await run('INSERT OR IGNORE INTO room_seats (room_id, seat_index, user_id, is_muted, is_locked, admin_muted) VALUES (?, ?, NULL, ?, 0, ?)', [roomId, i, isMuted, isMuted]);
  }
}
function publicRoomSettings(room) {
  return {
    roomId: room.id, title: room.title, category: room.category, announcement: room.announcement,
    cover_image: room.cover_image, bg_image: room.bg_image || '',
    chat_settings: jparse(room.chat_settings, {}), seat_settings: jparse(room.seat_settings, {}),
    seat_count: room.seat_count, max_seats: room.max_seats, seat_unlocks: jparse(room.seat_unlocks, {})
  };
}


// ==========================================
// كلمة مرور الغرفة (4 أرقام) — اختيارية، يضعها صاحب الغرفة عند الإنشاء أو بعده ويمكنه إلغاؤها
// ==========================================
const ROOM_CODE_RE = /^\d{4}$/;
const roomAccess = new Map();      // userId -> Set(roomId) : من أدخل الرمز الصحيح
const roomCodeFails = new Map();   // `${userId}|${roomId}` -> { count, until }

function stripRoomSecrets(r) {
  if (!r) return r;
  const o = { ...r };
  o.has_password = !!o.access_hash;
  delete o.access_hash; delete o.access_salt;
  return o;
}
async function setRoomCode(roomId, code) {
  if (!code) {
    await run("UPDATE rooms SET access_hash = '', access_salt = '' WHERE id = ?", [roomId]);
  } else {
    const { salt, hash } = await hashPassword(code);
    await run('UPDATE rooms SET access_hash = ?, access_salt = ? WHERE id = ?', [hash, salt, roomId]);
  }
  // تغيير/إلغاء الرمز يُسقط تصاريح الدخول السابقة
  for (const set of roomAccess.values()) set.delete(roomId);
}
// هل يحتاج هذا المستخدم لإدخال رمز قبل دخول الغرفة؟ (صاحب الغرفة والإدارة العليا معفيّون)
async function roomNeedsCode(room, userId) {
  if (!room || !room.access_hash) return false;
  if (userId && room.host_id === userId) return false;
  if (userId) {
    const set = roomAccess.get(userId);
    if (set && set.has(room.id)) return false;
    const u = await get('SELECT role FROM users WHERE id = ?', [userId]);
    if (u && ROOM_STAFF_ROLES.includes(u.role)) return false;
  }
  return true;
}

app.post('/api/rooms/:id/verify-password', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'];
    if (!userId) return res.status(401).json({ error: 'Unauthorized' });
    const room = await get('SELECT id, host_id, access_hash, access_salt FROM rooms WHERE id = ?', [req.params.id]);
    if (!room) return res.status(404).json({ error: 'الغرفة غير موجودة' });
    if (!room.access_hash) return res.json({ success: true });
    const key = `${userId}|${room.id}`;
    const f = roomCodeFails.get(key);
    if (f && f.until > Date.now()) return res.status(429).json({ error: 'محاولات خاطئة كثيرة، حاول بعد قليل' });
    const code = String((req.body && req.body.password) || '');
    const ok = ROOM_CODE_RE.test(code) && await checkPassword(code, room.access_salt, room.access_hash);
    if (!ok) {
      const now = Date.now();
      const nf = f && now - f.first < 5 * 60 * 1000 ? f : { count: 0, first: now, until: 0 };
      nf.count += 1;
      if (nf.count >= 5) nf.until = now + 5 * 60 * 1000;
      roomCodeFails.set(key, nf);
      return res.status(403).json({ error: 'كلمة مرور الغرفة غير صحيحة' });
    }
    roomCodeFails.delete(key);
    if (!roomAccess.has(userId)) roomAccess.set(userId, new Set());
    roomAccess.get(userId).add(room.id);
    res.json({ success: true });
  } catch (err) { res.status(500).json({ error: 'تعذر التحقق من كلمة المرور' }); }
});

// وضع / تغيير / إلغاء كلمة المرور (صاحب الغرفة أو الإدارة العليا فقط). password فارغة = إلغاء
app.put('/api/rooms/:id/password', async (req, res) => {
  try {
    const uid = req.headers['x-user-id'];
    const room = await get('SELECT * FROM rooms WHERE id = ?', [req.params.id]);
    if (!room) return res.status(404).json({ error: 'الغرفة غير موجودة' });
    const user = uid ? await get('SELECT id, role FROM users WHERE id = ?', [uid]) : null;
    if (!user || (room.host_id !== user.id && !ROOM_STAFF_ROLES.includes(user.role))) {
      return res.status(403).json({ error: 'صاحب الغرفة فقط يستطيع تعديل كلمة المرور' });
    }
    const code = String((req.body && req.body.password) || '').trim();
    if (code && !ROOM_CODE_RE.test(code)) return res.status(400).json({ error: 'كلمة المرور يجب أن تكون 4 أرقام بالضبط' });
    await setRoomCode(room.id, code);
    io.emit('room_meta_updated', { id: room.id, has_password: !!code });
    res.json({ success: true, has_password: !!code });
  } catch (err) { res.status(500).json({ error: 'تعذر حفظ كلمة المرور' }); }
});

// ==========================================
// مهام الأنثى اليومية + غرفتها الخاصة
//   • تواجد في الدردشة ساعتان باليوم (يجوز متفرقة) • ساعة على الأقل على مقعد المايك
//   • أرباح الهدايا تبقى معلّقة حتى تُكمل المهام، وتُصرف فور الإكمال؛ ما لم يُصرف قبل نهاية اليوم يسقط
// ==========================================
const FEMALE_PRESENCE_REQ = 2 * 3600;
const FEMALE_MIC_REQ = 1 * 3600;
const FEMALE_TICK_SEC = 30;
function ammanDay() { return new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Amman' }); }

async function getFemaleRow(userId, day) {
  await run('INSERT OR IGNORE INTO female_daily_tasks (user_id, day) VALUES (?, ?)', [userId, day || ammanDay()]);
  return get('SELECT * FROM female_daily_tasks WHERE user_id = ? AND day = ?', [userId, day || ammanDay()]);
}
function femaleStatusPayload(row, roomId) {
  return {
    isFemale: true, day: row.day, room_id: roomId || null, room_created: !!roomId,
    presence_sec: Math.min(row.presence_sec, FEMALE_PRESENCE_REQ), presence_required: FEMALE_PRESENCE_REQ,
    mic_sec: Math.min(row.mic_sec, FEMALE_MIC_REQ), mic_required: FEMALE_MIC_REQ,
    completed: !!row.completed, pending_coins: row.pending_coins || 0
  };
}
function notifyFemaleTasks(userId, payload) {
  const socks = userSockets.get(userId);
  if (socks) for (const sid of socks) io.to(sid).emit('female_tasks_update', payload);
}

// يُرسل حالة مهام الفتاة (ومنها «إنشاء غرفة») فور تغيّر وجود غرفتها
async function pushFemaleTasksStatus(userId) {
  try {
    const u = await get('SELECT id, gender FROM users WHERE id = ?', [userId]);
    if (!u || u.gender !== 'female') return;
    const room = await get('SELECT id FROM rooms WHERE host_id = ?', [userId]);
    const row = await getFemaleRow(userId);
    notifyFemaleTasks(userId, femaleStatusPayload(row, room && room.id));
  } catch (e) { console.error('pushFemaleTasksStatus:', e.message); }
}

// حذف الغرف التي لم يدخلها صاحبها خلال مدة معيّنة (يُفحص كل ساعة)
// المدة (بالأيام) وتفعيل/إيقاف الحذف التلقائي قابلان للتعديل من لوحة الإدارة (app_settings)
const ROOM_HOST_IDLE_DAYS_DEFAULT = 5;
async function getRoomPurgeSettings() {
  const out = { enabled: true, days: ROOM_HOST_IDLE_DAYS_DEFAULT };
  try {
    const rows = await all(`SELECT key, value FROM app_settings WHERE key IN ('room_auto_delete_enabled','room_auto_delete_days')`);
    rows.forEach(r => {
      if (r.key === 'room_auto_delete_enabled') out.enabled = String(r.value) !== '0';
      if (r.key === 'room_auto_delete_days') {
        const n = Math.floor(Number(r.value));
        if (Number.isFinite(n) && n >= 1) out.days = Math.min(3650, n);
      }
    });
  } catch (e) { console.error('getRoomPurgeSettings:', e.message); }
  return out;
}
async function purgeAbandonedRooms() {
  const cfg = await getRoomPurgeSettings();
  if (!cfg.enabled) return; // الحذف التلقائي موقوف من لوحة الإدارة
  const rows = await all(
    `SELECT id, host_id FROM rooms
     WHERE COALESCE(host_last_seen, created_at) < datetime('now', ?)`,
    [`-${cfg.days} days`]
  );
  for (const r of rows) {
    try {
      await run('DELETE FROM room_seats WHERE room_id = ?', [r.id]);
      await run('DELETE FROM messages WHERE room_id = ?', [r.id]);
      await run('DELETE FROM rooms WHERE id = ?', [r.id]);
      activeRoomStates.delete(r.id);
      io.to(`room:${r.id}`).emit('room_closed_by_host', { roomId: r.id, adminName: 'النظام' });
      io.emit('room_deleted', { roomId: r.id });
      pushFemaleTasksStatus(r.host_id);
      console.log('Abandoned room deleted:', r.id);
    } catch (e) { console.error('purge room error:', e.message); }
  }
}
app.get('/api/admin/settings/room-purge', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try { res.json({ success: true, settings: await getRoomPurgeSettings() }); }
  catch (err) { res.status(500).json({ error: err.message }); }
});
app.post('/api/admin/settings/room-purge', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const b = req.body || {};
    const enabled = (b.enabled === false || b.enabled === 'false' || b.enabled === 0 || b.enabled === '0') ? '0' : '1';
    const days = Math.min(3650, Math.max(1, Math.floor(Number(b.days)) || ROOM_HOST_IDLE_DAYS_DEFAULT));
    const upsert = (k, v) => run(`INSERT INTO app_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value`, [k, v]);
    await upsert('room_auto_delete_enabled', enabled);
    await upsert('room_auto_delete_days', String(days));
    res.json({ success: true, settings: await getRoomPurgeSettings() });
  } catch (err) { res.status(500).json({ error: err.message }); }
});
setInterval(() => { purgeAbandonedRooms().catch(e => console.error('purge rooms:', e.message)); }, 60 * 60 * 1000);
setTimeout(() => { purgeAbandonedRooms().catch(() => {}); }, 20000);

async function creditGiftReward(receiverId, reward) {
  if (!receiverId || reward <= 0) return;
  const r = await get('SELECT gender FROM users WHERE id = ?', [receiverId]);
  if (r && r.gender === 'female') {
    const row = await getFemaleRow(receiverId);
    if (!row.completed) {
      await run('UPDATE female_daily_tasks SET pending_coins = pending_coins + ? WHERE user_id = ? AND day = ?', [reward, receiverId, row.day]);
      const fresh = await getFemaleRow(receiverId, row.day);
      const room = await get('SELECT id FROM rooms WHERE host_id = ?', [receiverId]);
      notifyFemaleTasks(receiverId, femaleStatusPayload(fresh, room && room.id));
      return;
    }
  }
  await run('UPDATE users SET coins = coins + ? WHERE id = ?', [reward, receiverId]);
}
async function tickFemaleTasks() {
  const day = ammanDay();
  const seated = new Set((await all('SELECT DISTINCT user_id FROM room_seats WHERE user_id IS NOT NULL')).map(r => r.user_id));
  const present = new Set();
  for (const st of activeRoomStates.values()) {
    if (!st.activeAudience) continue;
    for (const [uid, u] of st.activeAudience) if (u && u.gender === 'female' && userSockets.has(uid)) present.add(uid);
  }
  for (const uid of present) {
    const row = await getFemaleRow(uid, day);
    if (row.completed) continue;
    const pres = row.presence_sec + FEMALE_TICK_SEC;
    const mic = row.mic_sec + (seated.has(uid) ? FEMALE_TICK_SEC : 0);
    const done = pres >= FEMALE_PRESENCE_REQ && mic >= FEMALE_MIC_REQ;
    await run('UPDATE female_daily_tasks SET presence_sec = ?, mic_sec = ?, completed = ? WHERE user_id = ? AND day = ?', [pres, mic, done ? 1 : 0, uid, day]);
    if (done && row.pending_coins > 0) {
      await run('UPDATE users SET coins = coins + ? WHERE id = ?', [row.pending_coins, uid]);
      await run('UPDATE female_daily_tasks SET pending_coins = 0 WHERE user_id = ? AND day = ?', [uid, day]);
    }
    const fresh = await getFemaleRow(uid, day);
    const room = await get('SELECT id FROM rooms WHERE host_id = ?', [uid]);
    const payload = femaleStatusPayload(fresh, room && room.id);
    payload.just_completed = done;
    payload.released_coins = done ? row.pending_coins : 0;
    notifyFemaleTasks(uid, payload);
  }
}
setInterval(() => { tickFemaleTasks().catch(e => console.error('female tasks tick:', e.message)); }, FEMALE_TICK_SEC * 1000);

app.get('/api/female/tasks', async (req, res) => {
  try {
    const uid = req.headers['x-user-id'];
    if (!uid) return res.status(401).json({ error: 'Unauthorized' });
    const u = await get('SELECT id, gender FROM users WHERE id = ?', [uid]);
    if (!u) return res.status(401).json({ error: 'الحساب غير مسجّل' });
    if (u.gender !== 'female') return res.json({ isFemale: false });
    const room = await get('SELECT id FROM rooms WHERE host_id = ?', [uid]);
    const row = await getFemaleRow(uid);
    res.json(femaleStatusPayload(row, room && room.id));
  } catch (err) { res.status(500).json({ error: 'تعذر جلب المهام' }); }
});

// حالة خيارات المقاعد (3 / 5 / 9 / 15) وما إذا كانت مفتوحة
app.get('/api/rooms/:id/seat-options', async (req, res) => {
  try {
    const room = await get('SELECT * FROM rooms WHERE id = ?', [req.params.id]);
    if (!room) return res.status(404).json({ error: 'الغرفة غير موجودة' });
    const members = (await get('SELECT COUNT(*) AS c FROM room_members WHERE room_id = ?', [room.id])).c;
    const unlocks = jparse(room.seat_unlocks, {});
    res.json({
      current: (room.seat_count || 8) + 1, members,   // الرقم الكلي يشمل مقعد المضيف
      options: [
        { count: 3, locked: false },
        { count: 5, locked: false },
        { count: 9, locked: !(unlocks['9'] || members >= SEAT_9_MEMBERS_NEEDED), need_members: SEAT_9_MEMBERS_NEEDED, members },
        { count: 15, locked: !unlocks['15'], price: SEAT_15_PRICE }
      ]
    });
  } catch (err) { res.status(500).json({ error: 'تعذر تحميل خيارات المقاعد' }); }
});

// تحديد عدد المقاعد النشطة (صاحب الغرفة أو الإدارة)
app.put('/api/rooms/:id/seat-count', async (req, res) => {
  try {
    const ctx = await requireRoomManager(req, res); if (!ctx) return;
    const { room, user } = ctx; const roomId = room.id;
    const count = parseInt(req.body.count, 10);
    const staff = ROOM_STAFF_ROLES.includes(user.role);
    if (!ROOM_SEAT_OPTIONS.includes(count) && !(staff && count >= 2 && count <= 16)) {
      return res.status(400).json({ error: 'اختر 3 أو 5 أو 9 أو 15 مقعداً' });
    }
    const unlocks = jparse(room.seat_unlocks, {});
    if (count === 9 && !staff && !unlocks['9']) {
      const members = (await get('SELECT COUNT(*) AS c FROM room_members WHERE room_id = ?', [roomId])).c;
      if (members < SEAT_9_MEMBERS_NEEDED) return res.status(403).json({ error: `يلزم ${SEAT_9_MEMBERS_NEEDED} من أعضاء الغرفة لفتح 9 مقاعد` });
      unlocks['9'] = true;
    }
    if (count === 15 && !staff && !unlocks['15']) {
      const bal = user.diamonds || 0;
      if (bal < SEAT_15_PRICE) return res.status(402).json({ error: `فتح 15 مقعداً يكلف ${SEAT_15_PRICE} كريستال` });
      await run('UPDATE users SET diamonds = diamonds - ? WHERE id = ?', [SEAT_15_PRICE, user.id]);
      unlocks['15'] = true;
    }
    // الرقم المختار (3/5/9/15) يشمل مقعد المضيف؛ مقاعد الضيوف = الرقم - 1
    const guests = count - 1;
    await ensureSeatRows(roomId, 15);
    const vacated = await all('SELECT seat_index, is_muted FROM room_seats WHERE room_id = ? AND seat_index > ? AND user_id IS NOT NULL', [roomId, guests]);
    const seatMuteSetting = jparse(room.seat_settings, {});
    const preserveMute = !!seatMuteSetting.global_mute;
    await run('UPDATE room_seats SET user_id = NULL WHERE room_id = ? AND seat_index > ?', [roomId, guests]);
    if (preserveMute) {
      await run('UPDATE room_seats SET is_muted = 1 WHERE room_id = ? AND seat_index > ?', [roomId, guests]);
    }
    await run('UPDATE rooms SET seat_count = ?, max_seats = 15, seat_unlocks = ? WHERE id = ?', [guests, JSON.stringify(unlocks), roomId]);
    io.to(`room:${roomId}`).emit('room_seat_count_changed', { roomId, seatCount: guests, maxSeats: 15 });
    vacated.forEach(v => io.to(`room:${roomId}`).emit('seat_updated', { seatIndex: v.seat_index, user: null, isMuted: preserveMute || !!v.is_muted }));
    res.json({ success: true, total_seats: count, seat_count: guests, max_seats: 15 });
  } catch (err) {
    console.error('seat-count error:', err);
    res.status(500).json({ error: 'تعذر تحديث عدد المقاعد' });
  }
});

// «صورة الغرفة»: الاسم + التصنيف + الإعلان الشامل + صورة الغرفة
app.put('/api/rooms/:id/profile', async (req, res) => {
  try {
    const ctx = await requireRoomManager(req, res); if (!ctx) return;
    const { room } = ctx;
    const title = String(req.body.title != null ? req.body.title : room.title).trim().slice(0, 40) || room.title;
    const category = String(req.body.category || room.category).slice(0, 30);
    const announcement = String(req.body.announcement != null ? req.body.announcement : (room.announcement || '')).slice(0, 100);
    const cover = req.body.cover_image ? String(req.body.cover_image).slice(0, 500) : room.cover_image;
    await run('UPDATE rooms SET title = ?, category = ?, announcement = ?, cover_image = ? WHERE id = ?', [title, category, announcement, cover, room.id]);
    const updated = await get('SELECT * FROM rooms WHERE id = ?', [room.id]);
    io.to(`room:${room.id}`).emit('room_settings_changed', publicRoomSettings(updated));
    // تحديث فوري لقائمة الغرف عند كل المتصلين (الصورة/الاسم/التصنيف)
    io.emit('room_meta_updated', { id: room.id, title: updated.title, category: updated.category, announcement: updated.announcement, cover_image: updated.cover_image });
    res.json({ success: true, room: publicRoomSettings(updated) });
  } catch (err) { console.error('room profile error:', err); res.status(500).json({ error: 'تعذر حفظ بيانات الغرفة' }); }
});

// رفع صورة الغرفة / خلفية مخصصة من الجهاز
app.post('/api/rooms/:id/image', upload.single('image'), async (req, res) => {
  try {
    const ctx = await requireRoomManager(req, res); if (!ctx) return;
    if (!req.file) return res.status(400).json({ error: 'لم يتم اختيار صورة' });
    if (!/^image\//.test(req.file.mimetype || '')) return res.status(400).json({ error: 'الملف ليس صورة' });
    res.json({ success: true, url: `/uploads/${req.file.filename}` });
  } catch (err) { res.status(500).json({ error: 'تعذر رفع الصورة' }); }
});

// ===== خلفيات الغرف الجاهزة (تُدار من الإدارة وتُباع بالكرستالات؛ السعر 0 = مجانية) =====
function safeDeleteRoomBgImage(imageUrl) {
  try {
    if (!imageUrl || !imageUrl.startsWith('/uploads/rbg-')) return;
    const uploadsDir = path.join(__dirname, 'public', 'uploads');
    const full = path.join(__dirname, 'public', imageUrl);
    if (path.dirname(full) === uploadsDir && fs.existsSync(full)) fs.unlinkSync(full);
  } catch (e) { console.error('delete room bg image error:', e.message); }
}
const roomBgUpload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      const uploadDir = path.join(__dirname, 'public', 'uploads');
      if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });
      cb(null, uploadDir);
    },
    filename: (req, file, cb) => cb(null, `rbg-${Date.now()}-${uuidv4().slice(0, 8)}${assetExt(file, '.jpg')}`)
  }),
  limits: { fileSize: Math.max(ASSET_HTML_MAX_BYTES, ADMIN_IMAGE_MAX_BYTES) },
  fileFilter: (req, file, cb) => {
    if (assetFileOk(file)) cb(null, true);
    else cb(new Error('يُسمح فقط بصور PNG أو JPG أو GIF أو WEBP أو ملف HTML'));
  }
});
async function adminRoomBgUpload(req, res, next) {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  roomBgUpload.single('image')(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.code === 'LIMIT_FILE_SIZE' ? `حجم الملف أكبر من الحد المسموح (الصور ${ADMIN_IMAGE_MAX_MB}MB، HTML 15MB)` : err.message });
    const bad = validateAssetUpload(req.file, ADMIN_IMAGE_MAX_BYTES);
    if (bad) { safeDeleteRoomBgImage(`/uploads/${req.file.filename}`); return res.status(400).json({ error: bad }); }
    next();
  });
}

// قائمة الخلفيات للمستخدم: مع owned (مجانية أو مشتراة)
app.get('/api/room-backgrounds', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'] || '';
    const rows = await all(`
      SELECT b.id, b.name, b.image_url, b.price,
             CASE WHEN b.price <= 0 OR i.id IS NOT NULL THEN 1 ELSE 0 END AS owned
      FROM room_backgrounds b
      LEFT JOIN user_inventory i ON i.item_id = b.id AND i.user_id = ? AND i.item_type = 'room_bg'
      WHERE b.is_active = 1
      ORDER BY b.price ASC, b.created_at DESC, b.rowid DESC
    `, [userId]);
    res.json({ backgrounds: rows.map(r => ({ id: r.id, name: r.name, image_url: r.image_url, price: r.price, owned: !!r.owned })) });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/room-backgrounds/:id/buy', async (req, res) => {
  const userId = req.headers['x-user-id'];
  if (!userId) return res.status(401).json({ error: 'سجّل الدخول أولاً' });
  try {
    const bg = await get('SELECT * FROM room_backgrounds WHERE id = ? AND is_active = 1', [req.params.id]);
    if (!bg) return res.status(404).json({ error: 'هذه الخلفية غير متاحة' });
    if (!(await get('SELECT id FROM users WHERE id = ?', [userId]))) return res.status(404).json({ error: 'المستخدم غير موجود' });
    if ((parseInt(bg.price, 10) || 0) > 0) {
      const bought = await buyInventoryItem(userId, 'room_bg', { id: bg.id, name: bg.name, price: bg.price, duration_days: 0 }, 'هذه الخلفية');
      if (!bought.ok) return res.status(bought.status).json({ error: bought.error });
    }
    const updatedUser = await get('SELECT * FROM users WHERE id = ?', [userId]);
    res.json({ success: true, user: updatedUser });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ---- إدارة خلفيات الغرف من لوحة الإدارة ----
app.get('/api/admin/room-backgrounds', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const rows = await all(`
      SELECT b.*, (SELECT COUNT(*) FROM user_inventory i WHERE i.item_type = 'room_bg' AND i.item_id = b.id) AS owners_count
      FROM room_backgrounds b ORDER BY b.created_at DESC, b.rowid DESC
    `);
    res.json({ backgrounds: rows });
  } catch (err) { res.status(500).json({ error: err.message }); }
});
app.post('/api/admin/room-backgrounds', adminRoomBgUpload, async (req, res) => {
  const drop = () => { if (req.file) safeDeleteRoomBgImage(`/uploads/${req.file.filename}`); };
  try {
    const name = String(req.body.name || '').trim();
    const price = parseInt(req.body.price, 10);
    if (!name) { drop(); return res.status(400).json({ error: 'يرجى كتابة اسم الخلفية' }); }
    if (!Number.isFinite(price) || price < 0) { drop(); return res.status(400).json({ error: 'يرجى إدخال سعر صحيح (0 = مجانية)' }); }
    if (!req.file) return res.status(400).json({ error: 'يرجى اختيار صورة أو ملف HTML للخلفية' });
    const id = `rbg-${uuidv4().slice(0, 8)}`;
    await run('INSERT INTO room_backgrounds (id, name, image_url, price, is_active) VALUES (?, ?, ?, ?, 1)', [id, name, `/uploads/${req.file.filename}`, price]);
    res.json({ success: true, id });
  } catch (err) { drop(); res.status(500).json({ error: err.message }); }
});
app.put('/api/admin/room-backgrounds/:id', adminRoomBgUpload, async (req, res) => {
  const drop = () => { if (req.file) safeDeleteRoomBgImage(`/uploads/${req.file.filename}`); };
  try {
    const bg = await get('SELECT * FROM room_backgrounds WHERE id = ?', [req.params.id]);
    if (!bg) { drop(); return res.status(404).json({ error: 'الخلفية غير موجودة' }); }
    const name = req.body.name !== undefined ? String(req.body.name).trim() : bg.name;
    const price = req.body.price !== undefined ? parseInt(req.body.price, 10) : bg.price;
    const isActive = req.body.is_active !== undefined ? (String(req.body.is_active) === '1' || req.body.is_active === 'true' ? 1 : 0) : bg.is_active;
    if (!name || !Number.isFinite(price) || price < 0) { drop(); return res.status(400).json({ error: 'يرجى التأكد من الاسم والسعر' }); }
    let imageUrl = bg.image_url;
    if (req.file) { imageUrl = `/uploads/${req.file.filename}`; safeDeleteRoomBgImage(bg.image_url); }
    await run('UPDATE room_backgrounds SET name = ?, price = ?, is_active = ?, image_url = ? WHERE id = ?', [name, price, isActive, imageUrl, bg.id]);
    if (imageUrl !== bg.image_url) await run('UPDATE rooms SET bg_image = ? WHERE bg_image = ?', [imageUrl, bg.image_url]);
    await run(`UPDATE user_inventory SET item_name = ? WHERE item_type = 'room_bg' AND item_id = ?`, [name, bg.id]);
    res.json({ success: true });
  } catch (err) { drop(); res.status(500).json({ error: err.message }); }
});
app.delete('/api/admin/room-backgrounds/:id', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });
  try {
    const bg = await get('SELECT * FROM room_backgrounds WHERE id = ?', [req.params.id]);
    if (!bg) return res.status(404).json({ error: 'الخلفية غير موجودة' });
    await run(`DELETE FROM user_inventory WHERE item_type = 'room_bg' AND item_id = ?`, [bg.id]);
    await run(`UPDATE rooms SET bg_image = '' WHERE bg_image = ?`, [bg.image_url]);
    await run('DELETE FROM room_backgrounds WHERE id = ?', [bg.id]);
    safeDeleteRoomBgImage(bg.image_url);
    res.json({ success: true });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// «الخلفية» — خلفيات جاهزة فقط (لا رفع من صاحب الغرفة)
const BUILTIN_BG_RE = /^(grad:[a-z0-9_-]+|anim:[a-z0-9_-]+|\/img\/bg\/bg-\d+\.(?:jpg|webp)|\/royal_eagle\.gif)$/i;
app.put('/api/rooms/:id/background', async (req, res) => {
  try {
    const ctx = await requireRoomManager(req, res); if (!ctx) return;
    const { room, user } = ctx;
    const bg = String(req.body.bg_image || '').slice(0, 600);
    if (bg && bg !== (room.bg_image || '') && !BUILTIN_BG_RE.test(bg)) {
      const adminBg = await get('SELECT * FROM room_backgrounds WHERE image_url = ? AND is_active = 1', [bg]);
      if (!adminBg) return res.status(400).json({ error: 'يمكن اختيار الخلفيات الجاهزة فقط' });
      if ((parseInt(adminBg.price, 10) || 0) > 0) {
        const owned = await get(`SELECT id FROM user_inventory WHERE user_id = ? AND item_type = 'room_bg' AND item_id = ?`, [user.id, adminBg.id]);
        if (!owned) return res.status(402).json({ error: `هذه الخلفية مدفوعة (${adminBg.price} 💎) — اشترِها أولاً` });
      }
    }
    await run('UPDATE rooms SET bg_image = ? WHERE id = ?', [bg, room.id]);
    const updated = await get('SELECT * FROM rooms WHERE id = ?', [room.id]);
    io.to(`room:${room.id}`).emit('room_settings_changed', Object.assign(publicRoomSettings(updated), { toast: 'تم تغيير الخلفية', by: user.name }));
    res.json({ success: true, bg_image: bg });
  } catch (err) { res.status(500).json({ error: 'تعذر تغيير الخلفية' }); }
});

// «منطقة الدردشة» / «إدارة الشات»
app.put('/api/rooms/:id/chat-settings', async (req, res) => {
  try {
    const ctx = await requireRoomManager(req, res); if (!ctx) return;
    const { room } = ctx;
    const keys = ['hide_system', 'hide_all', 'images_members_only', 'auto_welcome', 'close_emoji'];
    const cur = jparse(room.chat_settings, {});
    keys.forEach(k => { if (typeof req.body[k] === 'boolean') cur[k] = req.body[k]; });
    await run('UPDATE rooms SET chat_settings = ? WHERE id = ?', [JSON.stringify(cur), room.id]);
    const updated = await get('SELECT * FROM rooms WHERE id = ?', [room.id]);
    io.to(`room:${room.id}`).emit('room_settings_changed', publicRoomSettings(updated));
    res.json({ success: true, chat_settings: cur });
  } catch (err) { res.status(500).json({ error: 'تعذر حفظ إعدادات الشات' }); }
});

// «مقعد» → إعدادات المقاعد (من يستطيع الصعود / عرض النجوم / موسيقى الآخرين)
app.put('/api/rooms/:id/seat-settings', async (req, res) => {
  try {
    const ctx = await requireRoomManager(req, res); if (!ctx) return;
    const { room } = ctx;
    const cur = jparse(room.seat_settings, {});
    if (['all', 'members'].includes(req.body.who)) cur.who = req.body.who;
    if (['classic', 'neon', 'gold'].includes(req.body.theme)) cur.theme = req.body.theme;
    ['show_stars', 'allow_music'].forEach(k => { if (typeof req.body[k] === 'boolean') cur[k] = req.body[k]; });
    await run('UPDATE rooms SET seat_settings = ? WHERE id = ?', [JSON.stringify(cur), room.id]);
    const updated = await get('SELECT * FROM rooms WHERE id = ?', [room.id]);
    io.to(`room:${room.id}`).emit('room_settings_changed', publicRoomSettings(updated));
    res.json({ success: true, seat_settings: cur });
  } catch (err) { res.status(500).json({ error: 'تعذر حفظ إعدادات المقاعد' }); }
});

app.post('/api/admin/rooms', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });

  try {
    const { title, category, country_code, announcement, host_id, cover_image } = req.body;
    const maxSeats = Math.min(8, Math.max(1, parseInt(req.body.max_seats, 10) || 8));
    if (!title || !title.trim()) {
      return res.status(400).json({ error: 'عنوان الغرفة مطلوب' });
    }

    let finalHostId = host_id;
    if (!finalHostId) {
      const owner = await get("SELECT id FROM users WHERE role = 'owner' LIMIT 1");
      finalHostId = owner ? owner.id : 'sc-owner-001';
    }

    let host = await get('SELECT * FROM users WHERE id = ?', [finalHostId]);
    if (!host) {
      const anyUser = await get('SELECT * FROM users LIMIT 1');
      host = anyUser;
      finalHostId = host ? host.id : 'sc-owner-001';
    }

    const roomId = `room-${Date.now().toString().slice(-6)}`;
    const countryItem = SUPPORTED_COUNTRIES.find(c => c.code === country_code) || { code: 'JO', name: 'الأردن', flag: '🇯🇴' };

    await run(`
      INSERT INTO rooms (id, title, category, room_type, cover_image, likes_count, host_id, country_code, country_name, country_flag, theme, announcement)
      VALUES (?, ?, ?, 'voice', ?, 0, ?, ?, ?, ?, 'cosmic_purple', ?)
    `, [
      roomId,
      title.trim(),
      category || 'chill',
      cover_image || 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=600&q=80',
      finalHostId,
      countryItem.code,
      countryItem.name,
      countryItem.flag,
      announcement || 'غرفة صوتية رسمية من إدارة التطبيق 🌟'
    ]);

    // Setup seat 0 + 8 stage seats
    await run(`INSERT INTO room_seats (room_id, seat_index, user_id, is_muted, is_locked) VALUES (?, 0, NULL, 0, 0)`, [roomId]);
    for (let i = 1; i <= 8; i++) {
      await run(`INSERT INTO room_seats (room_id, seat_index, user_id, is_muted, is_locked) VALUES (?, ?, NULL, 0, 0)`, [roomId, i]);
    }

    await run('UPDATE rooms SET max_seats = ?, seat_count = ? WHERE id = ?', [maxSeats, maxSeats, roomId]);

    let newRoom = await get(`
      SELECT r.*, u.name as host_name, u.avatar as host_avatar, u.avatar_frame as host_frame, u.level as host_level
      FROM rooms r
      LEFT JOIN users u ON r.host_id = u.id
      WHERE r.id = ?
    `, [roomId]);

    newRoom.seats = await all('SELECT * FROM room_seats WHERE room_id = ? ORDER BY seat_index ASC', [roomId]);
    newRoom.mic_seat = await getEquippedMicSeatUrl(newRoom.host_id);
    newRoom.audience_count = 0;

    io.emit('room_created', { room: stripRoomSecrets(newRoom) });

    res.json({ success: true, room: stripRoomSecrets(newRoom) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 15. Get All Generated Moderator Accounts
app.get('/api/admin/moderators', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });

  try {
    const moderators = await all(`
      SELECT m.*, u.name as user_name, u.avatar as user_avatar, u.is_banned, u.role as user_role
      FROM moderator_accounts m
      LEFT JOIN users u ON m.user_id = u.id
      ORDER BY m.created_at DESC
    `);
    res.json({ success: true, moderators });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 16. Generate New Moderator Account (Username & Password to give to anyone)
app.post('/api/admin/moderators/generate', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });

  try {
    let { username, password, display_name, notes } = req.body;
    // نوع الحساب الجديد: مشرف عام (moderator) أو زائر عادي (user) — يحدده المدير من الاستمارة
    const role = String((req.body || {}).role || 'moderator') === 'user' ? 'user' : 'moderator';

    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    if (!username || !username.trim()) {
      username = `mod_${randomSuffix}`;
    } else {
      username = username.trim().toLowerCase().replace(/\s+/g, '_');
    }

    if (!password || !password.trim()) {
      password = `Mod@${Math.floor(100000 + Math.random() * 900000)}`;
    } else {
      password = password.trim();
    }

    if (!display_name || !display_name.trim()) {
      display_name = `مشرف عام | ${username}`;
    } else {
      display_name = display_name.trim();
    }

    // Check if username already exists in moderator_accounts
    const existing = await get('SELECT id FROM moderator_accounts WHERE username = ?', [username]);
    if (existing) {
      return res.status(400).json({ error: 'اسم المستخدم هذا مستخدم بالفعل، يرجى اختيار اسم آخر' });
    }
    // اسم الدخول يجب ألا يكون مستخدماً كاسم مستعار أو كاسم ظاهر لحساب آخر (قاعدة دخول الشات)
    const takenNick = await get(
      `SELECT user_id AS id FROM user_credentials WHERE LOWER(nickname) = LOWER(?)
       UNION SELECT id FROM users WHERE LOWER(name) = LOWER(?)`,
      [username, username]
    );
    if (takenNick) {
      return res.status(400).json({ error: 'اسم المستخدم هذا مستخدم بالفعل، يرجى اختيار اسم آخر' });
    }

    const modAccountId = `mod-acc-${Date.now()}`;
    const userId = `sc-mod-${randomSuffix}`;
    const modEmail = `${username}@soulchill.mod`;

    // إنشاء الحساب في جدول users: مشرف عام بصلاحيات كاملة، أو زائر عادي بدون صلاحيات
    const avatarPath = `/avatars/avatar-${Math.floor(1 + Math.random() * 6)}.png`;
    if (role === 'user') {
      await run(`
        INSERT INTO users (id, name, email, role, avatar, level, coins, diamonds, bio)
        VALUES (?, ?, ?, 'user', ?, 1, 2500, 600, 'عضو في دردشة SoulChill 🪐')
      `, [userId, display_name, modEmail, avatarPath]);
    } else {
      await run(`
        INSERT INTO users (id, name, email, role, avatar, avatar_frame, level, coins, diamonds, soul_planet, bio)
        VALUES (?, ?, ?, 'moderator', ?, 'galaxy', 50, 50000, 5000, 'كوكب القيادة والإشراف 🛡️', 'مشرف عام معتمد على دردشة SoulChill')
      `, [userId, display_name, modEmail, avatarPath]);
    }

    // بيانات الدخول بالاسم المستعار: بدونها لا يدخل الحساب من شاشة الدخول العادية في الشات
    const { salt: modSalt, hash: modHash } = await hashPassword(password);
    try {
      await run('INSERT INTO user_credentials (user_id, nickname, password_hash, password_salt) VALUES (?, ?, ?, ?)',
        [userId, username, modHash, modSalt]);
    } catch (credErr) {
      // اسم مستعار وُخذ بالتزامن: لا نترك حساباً يتيماً محجوزاً للاسم
      if (String(credErr.message || '').includes('UNIQUE')) {
        await run('DELETE FROM users WHERE id = ?', [userId]);
        return res.status(409).json({ error: 'هذا الاسم المستعار مستخدم، اختر اسماً آخر' });
      }
      throw credErr;
    }

    // Insert into moderator_accounts
    await run(`
      INSERT INTO moderator_accounts (id, username, password, display_name, user_id, notes)
      VALUES (?, ?, ?, ?, ?, ?)
    `, [modAccountId, username, password, display_name, userId, notes || '']);

    const createdMod = await get('SELECT * FROM moderator_accounts WHERE id = ?', [modAccountId]);

    // إعلان تعيين المشرف الجديد — يُنشر فقط عند توليد حساب مشرف (لا يُعلن عن الزائر العادي)
    if (role === 'moderator') io.emit('room_message', {
      id: `sys-mod-${Date.now()}`,
      sender_id: 'system',
      sender_name: '🛡️ الإدارة العليا',
      sender_avatar: '/avatars/avatar-1.png',
      sender_level: 99,
      message_type: 'system',
      content: `🎉 تم اعتماد حساب إشرافي جديد [${display_name}] كمشرف عام على الدردشة بالكامل! 🛡️✨`,
      created_at: new Date().toISOString()
    });

    res.json({
      success: true,
      moderator: createdMod,
      role,
      message: role === 'user'
        ? 'تم توليد الزائر العادي وبياناته! الاسم الظاهر بالشات هو ما اخترته، والدخول من زر «الدخول بالاسم المستعار»'
        : 'تم توليد حساب المشرف وبيانات الدخول بنجاح! الدخول من زر «الدخول بالاسم المستعار» باسم المستخدم وكلمة المرور'
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 17. Delete Moderator Account
app.delete('/api/admin/moderators/:id', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });

  try {
    const { id } = req.params;
    const mod = await get('SELECT * FROM moderator_accounts WHERE id = ?', [id]);
    if (!mod) {
      return res.status(404).json({ error: 'حساب المشرف غير موجود' });
    }

    // Downgrade user role
    await run("UPDATE users SET role = 'user' WHERE id = ?", [mod.user_id]);
    await run('DELETE FROM moderator_accounts WHERE id = ?', [id]);
    // حذف بيانات الدخول بالاسم المستعار أيضاً: يحرّر الاسم ويمنع الدخول بعد الحذف
    await run('DELETE FROM user_credentials WHERE user_id = ?', [mod.user_id]);

    res.json({ success: true, message: 'تم حذف حساب المشرف وإلغاء صلاحياته بنجاح' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ===== تهيئة أولية عند الإقلاع =====
// 1) الحسابات المولَّدة قبل هذا التحديث كانت تحفظ كلمة المرور نصاً في moderator_accounts —
//    نحوّلها إلى بيانات دخول مشفّرة تسمح بالدخول من شاشة «الدخول بالاسم المستعار» في الشات
async function backfillGeneratedCredentials() {
  try {
    const rows = await all(`
      SELECT m.username, m.password, m.user_id FROM moderator_accounts m
      LEFT JOIN user_credentials c ON c.user_id = m.user_id
      WHERE c.user_id IS NULL
    `);
    for (const r of rows) {
      const dup = await get('SELECT user_id FROM user_credentials WHERE LOWER(nickname) = LOWER(?)', [r.username]);
      if (dup && dup.user_id !== r.user_id) {
        console.warn('[backfill] تعذّر تحويل حساب (اسم مستعار محجوز):', r.username);
        continue;
      }
      const { salt, hash } = await hashPassword(String(r.password || ''));
      await run('INSERT INTO user_credentials (user_id, nickname, password_hash, password_salt) VALUES (?, ?, ?, ?)',
        [r.user_id, r.username, hash, salt]);
      console.log('[backfill] تم إنشاء بيانات دخول للحساب المولَّد:', r.username);
    }
  } catch (e) { console.error('backfillGeneratedCredentials error:', e.message); }
}

// 2) نقاط بداية للمستوى: كل حساب موجود تحصل نقاطاً تكافئ مستواه الحالي حتى يبدو التقدم مستمراً
async function backfillLevelPointsBaseline() {
  try {
    const rows = await all('SELECT id, level, level_points FROM users WHERE COALESCE(level_points, 0) = 0 AND level > 1 AND level <= 30');
    for (const r of rows) {
      const baseline = memberLevels.levelThreshold(r.level);
      if (baseline > 0) {
        await run('UPDATE users SET level_points = ? WHERE id = ? AND COALESCE(level_points, 0) = 0', [baseline, r.id]);
      }
    }
  } catch (e) { console.error('backfillLevelPointsBaseline error:', e.message); }
}
setTimeout(async () => { await backfillGeneratedCredentials(); await backfillLevelPointsBaseline(); }, 1500);

// 18. Get SMTP Settings
app.get('/api/admin/smtp', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });

  try {
    const smtp = await get('SELECT * FROM smtp_settings WHERE id = 1');
    res.json({ success: true, smtp });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 19. Update SMTP Settings
app.post('/api/admin/smtp', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });

  try {
    const { host, port, user, pass, from_email, subject_template, html_template, is_enabled } = req.body;
    await run(`
      UPDATE smtp_settings SET
        host = COALESCE(?, host),
        port = COALESCE(?, port),
        user = COALESCE(?, user),
        pass = COALESCE(?, pass),
        from_email = COALESCE(?, from_email),
        subject_template = COALESCE(?, subject_template),
        html_template = COALESCE(?, html_template),
        is_enabled = COALESCE(?, is_enabled),
        updated_at = CURRENT_TIMESTAMP
      WHERE id = 1
    `, [host, port ? parseInt(port) : null, user, pass, from_email, subject_template, html_template, is_enabled !== undefined ? (is_enabled ? 1 : 0) : null]);

    const updated = await get('SELECT * FROM smtp_settings WHERE id = 1');
    res.json({ success: true, smtp: updated, message: 'تم حفظ وتحديث إعدادات SMTP بنجاح!' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 20. Test SMTP Email Sending
app.post('/api/admin/smtp/test', async (req, res) => {
  const session = await verifyAdminToken(req);
  if (!session) return res.status(401).json({ error: 'غير مصرح بالدخول' });

  try {
    const { target_email } = req.body;
    if (!target_email || !target_email.includes('@')) {
      return res.status(400).json({ error: 'يرجى إدخال بريد إلكتروني صحيح لإرسال التجربة' });
    }

    const smtp = await get('SELECT * FROM smtp_settings WHERE id = 1');
    if (!smtp) return res.status(400).json({ error: 'إعدادات SMTP غير موجودة' });

    const transporter = nodemailer.createTransport({
      host: smtp.host || 'smtp.gmail.com',
      port: parseInt(smtp.port) || 587,
      secure: parseInt(smtp.port) === 465,
      auth: {
        user: smtp.user,
        pass: smtp.pass
      }
    });

    const testCode = '884920';
    let htmlContent = (smtp.html_template || '')
      .replace(/\{\{code\}\}/g, testCode)
      .replace(/\{\{email\}\}/g, target_email)
      .replace(/\{\{app_name\}\}/g, 'SoulChill');

    const subject = `[تجربة إرسال SMTP ناجحة] ` + (smtp.subject_template || 'رمز التحقق SoulChill');

    await transporter.sendMail({
      from: smtp.from_email || `chat<${smtp.user}>`,
      to: target_email,
      subject: subject,
      html: htmlContent
    });

    res.json({
      success: true,
      message: `تم إرسال بريد التجربة بنجاح إلى ${target_email} عبر خادم ${smtp.host}!`
    });
  } catch (err) {
    console.error('SMTP test error:', err);
    res.status(500).json({ error: 'فشل إرسال البريد عبر SMTP: ' + err.message });
  }
});

// 18. Moderator Login with Username & Password (for chat app or direct login)
app.post('/api/auth/moderator-login', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: 'اسم المستخدم وكلمة المرور مطلوبان' });
    }

    const cleanUser = username.trim().toLowerCase();
    const cleanPass = password.trim();

    // Check in moderator_accounts
    const modAcc = await get('SELECT * FROM moderator_accounts WHERE LOWER(username) = ? AND password = ?', [cleanUser, cleanPass]);
    if (!modAcc) {
      // Also check admin_credentials for super admin
      const adminAcc = await get('SELECT * FROM admin_credentials WHERE LOWER(username) = ? AND password = ?', [cleanUser, cleanPass]);
      if (adminAcc) {
        const owner = await get("SELECT * FROM users WHERE role = 'owner' LIMIT 1");
        const token = `mod-token-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
        return res.json({
          success: true,
          token,
          user: owner,
          isSuperAdmin: true,
          message: 'تم تسجيل الدخول بصلاحيات الإدارة العليا!'
        });
      }
      return res.status(401).json({ error: 'اسم المستخدم أو كلمة المرور غير صحيحة' });
    }

    let user = await get('SELECT * FROM users WHERE id = ?', [modAcc.user_id]);
    if (!user) {
      user = await get('SELECT * FROM users WHERE email = ?', [`${cleanUser}@soulchill.mod`]);
    }

    if (user && user.is_banned) {
      return res.status(403).json({ error: 'تم حظر هذا الحساب من قبل الإدارة' });
    }

    // Ensure role is moderator
    if (user && user.role !== 'moderator') {
      await run("UPDATE users SET role = 'moderator' WHERE id = ?", [user.id]);
      user.role = 'moderator';
    }

    const token = `mod-token-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

    res.json({
      success: true,
      token,
      user,
      moderator: {
        username: modAcc.username,
        display_name: modAcc.display_name
      },
      message: `مرحباً بك يا مشرفنا العزيز ${modAcc.display_name}! 🛡️`
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ==========================================
// SOCKET.IO REALTIME EVENTS
// ==========================================

// سجل المكالمات الصوتية الخاصة الجارية
const dmCalls = new Map(); // callId -> { callId, callerId, calleeId, callerSocket, calleeSocket, answered }
// يسجّل حدث المكالمة كرسالة نظام داخل المحادثة الخاصة بين الطرفين ويرسلها لهما فورًا
async function postCallLog(callerId, calleeId, event, meta) {
  try {
    const texts = { started: '📞 بدأت المكالمة', ended: '📞 انتهت المكالمة', missed: '📵 مكالمة فائتة', rejected: '📵 تم رفض المكالمة' };
    const msgId = `msg-${Date.now().toString()}-${uuidv4().slice(0, 4)}`;
    await run(`INSERT INTO messages (id, sender_id, receiver_id, message_type, content, metadata) VALUES (?, ?, ?, 'call', ?, ?)`,
      [msgId, callerId, calleeId, texts[event] || '📞 مكالمة', JSON.stringify(Object.assign({ event }, meta || {}))]);
    const createdMsg = await get(`
      SELECT m.*, u.name as sender_name, u.avatar as sender_avatar
      FROM messages m JOIN users u ON m.sender_id = u.id WHERE m.id = ?`, [msgId]);
    if (!createdMsg) return;
    emitToUser(callerId, 'private_message', createdMsg);
    emitToUser(calleeId, 'private_message', createdMsg);
  } catch (e) { console.error('postCallLog error:', e); }
}

function endDmCall(callId, reason) {
  const c = dmCalls.get(callId);
  if (!c) return;
  dmCalls.delete(callId);
  const payload = { callId, reason };
  io.to(c.callerSocket).emit('dm_call_ended', payload);
  if (c.calleeSocket) io.to(c.calleeSocket).emit('dm_call_ended', payload);
  else emitToUser(c.calleeId, 'dm_call_ended', payload);

  // رسالة في المحادثة: انتهت المكالمة (وقت الانتهاء + المدة) أو فائتة/مرفوضة إن لم يُرَدّ عليها
  const now = Date.now();
  if (c.answered && c.answeredAt) {
    postCallLog(c.callerId, c.calleeId, 'ended', {
      started_at: new Date(c.answeredAt).toISOString(),
      ended_at: new Date(now).toISOString(),
      duration: Math.max(0, Math.round((now - c.answeredAt) / 1000)),
      reason
    });
  } else {
    postCallLog(c.callerId, c.calleeId, reason === 'rejected' ? 'rejected' : 'missed', { at: new Date(now).toISOString(), reason });
  }
}

// ==========================================
// نظام التوافق الصوتي الحقيقي (مكالمة صوتية مجهولة بين شخصين حقيقيين)
// - 3 محاولات فقط لكل حساب خلال 24 ساعة
// - المطابقة بين شخصين حقيقيين متصلين: نفس التوافق (نفس الكوكب/الاهتمامات) أو نسبة توافق ≥ 70%
// - اتصال صوتي حقيقي (WebRTC) لمدة 5 دقائق فقط، بلا حدود عند كشف الهوية المتبادل
// ==========================================
const VOICE_MATCH_LIMIT = 3; // محاولات لكل 24 ساعة
const VOICE_MATCH_VIP_LIMIT = Math.max(VOICE_MATCH_LIMIT, parseInt(process.env.VOICE_MATCH_VIP_LIMIT, 10) || 10); // أصحاب ميزة «التوافق الصوتي» (VIP5+)
const VOICE_MATCH_WINDOW_MS = 24 * 60 * 60 * 1000;
const VOICE_MATCH_DURATION_MS = parseInt(process.env.VOICE_MATCH_DURATION_MS, 10) || 5 * 60 * 1000; // 5 دقائق (افتراضياً)
const VOICE_MATCH_QUEUE_TIMEOUT_MS = 90 * 1000; // مهلة الانتظار في طابور البحث
const VOICE_MATCH_MIN_COMPAT = 60; // حد التوافق الأدنى للمطابقة (60% فأكثر)
const VOICE_MATCH_REQUEST_TTL_MS = 30 * 1000; // مدة صلاحية طلب الاتصال المرسل للمتوافقين المتصلين
const VOICE_MATCH_MAX_INVITES = 30; // أقصى عدد متوافقين يصلهم الطلب دفعة واحدة
const voiceMatchQueue = []; // [{ userId, socketId, user, enqueuedAt, timeout }] — مشترك بين جميع السوكيتات
const activeVoiceMatchSessions = new Map(); // sessionId -> { id, userA, userB, startedAt, duration, isUnlimited, timer }

function parseSoulTags(tags) {
  return new Set(String(tags || '').split(',').map(t => t.trim()).filter(Boolean));
}

// نسبة التوافق الحقيقية بين شخصين (0-100): اهتمامات مشتركة 70% + نفس الكوكب 20% + نفس البلد 10%
function computeSoulCompatibility(a, b) {
  const tagsA = parseSoulTags(a && a.soul_tags);
  const tagsB = parseSoulTags(b && b.soul_tags);
  let shared = 0;
  tagsA.forEach(t => { if (tagsB.has(t)) shared++; });
  const union = new Set([...tagsA, ...tagsB]).size || 1;
  let score = Math.round((shared / union) * 70);
  if (a && b && a.soul_planet && b.soul_planet && a.soul_planet === b.soul_planet) score += 20;
  if (a && b && a.country_code && b.country_code && a.country_code === b.country_code) score += 10;
  return Math.min(100, score);
}

// قاعدة المطابقة: نسبة التوافق الحقيقية 60% فأكثر بين شخصين مختلفين
function isVoiceMatchCompatible(a, b) {
  if (!a || !b || !a.id || !b.id || a.id === b.id) return false;
  return computeSoulCompatibility(a, b) >= VOICE_MATCH_MIN_COMPAT;
}

// فلتر الجنس: pref = all | male | female (اختيار صاحب الطلب)، وgender = جنس الطرف الآخر من قاعدة البيانات
function normalizeVoiceMatchGenderPref(v) {
  v = String(v || 'all').toLowerCase();
  return (v === 'male' || v === 'female') ? v : 'all';
}
function vmGenderAccepts(pref, gender) {
  pref = normalizeVoiceMatchGenderPref(pref);
  if (pref === 'all') return true;
  return String(gender || '').toLowerCase() === pref;
}
// الشرط متبادل: اختيار كل طرف يجب أن يناسب جنس الطرف الآخر
function vmGenderMutuallyAccepted(a, b) {
  return vmGenderAccepts(a.prefGender, b.user && b.user.gender) && vmGenderAccepts(b.prefGender, a.user && a.user.gender);
}

// هل المستخدم داخل مكالمة توافق صوتي نشطة؟
function isUserInActiveVoiceMatch(userId) {
  for (const s of activeVoiceMatchSessions.values()) {
    if (s.userA.id === userId || s.userB.id === userId) return true;
  }
  return false;
}

// ===== جدول voice_calls: سجل دائم لكل مكالمة (يُحدَّث من الخادم فقط) =====
async function vmCallLog(sql, params) { try { await run(sql, params); } catch (e) { console.error('voice_calls log error:', e.message); } }

const VOICE_MATCH_CONNECT_TIMEOUT_MS = parseInt(process.env.VOICE_MATCH_CONNECT_TIMEOUT_MS, 10) || 45 * 1000; // مهلة اتصال الطرفين صوتياً (لا تُحسب ضمن الدقائق الخمس)

// هل بين المستخدمين حظر (من أي جهة)؟
async function isBlockedEitherWay(idA, idB) {
  try {
    const row = await get('SELECT 1 AS x FROM user_blocks WHERE (user_id = ? AND blocked_id = ?) OR (user_id = ? AND blocked_id = ?) LIMIT 1', [idA, idB, idB, idA]);
    return !!row;
  } catch (e) { return false; }
}

function vmPublicProfile(u) {
  return u ? { id: u.id, name: u.name, avatar: u.avatar, level: u.level || null, soul_planet: u.soul_planet || null, country_code: u.country_code || null } : null;
}

// بدء مؤقت الدقائق الخمس من الخادم — يُستدعى فقط عندما يبلّغ الطرفان باتصال الصوت
function startVoiceMatchClock(s) {
  if (!s || s.clockStarted || s.ended) return;
  s.clockStarted = true;
  if (s.connectTimer) { clearTimeout(s.connectTimer); s.connectTimer = null; }
  s.startedAt = Date.now();
  s.deadlineAt = s.startedAt + VOICE_MATCH_DURATION_MS;
  const unlimitedNow = s.userA.revealed && s.userB.revealed;
  if (unlimitedNow) { s.isUnlimited = true; s.deadlineAt = null; }
  else {
    s.timer = setTimeout(() => finalizeVoiceMatchDeadline(s.id), VOICE_MATCH_DURATION_MS);
  }
  vmCallLog('UPDATE voice_calls SET status = ?, started_at = ?, deadline_at = ? WHERE id = ?',
    [s.isUnlimited ? 'UNLIMITED' : 'ANONYMOUS_CALL', new Date(s.startedAt).toISOString(), s.deadlineAt ? new Date(s.deadlineAt).toISOString() : null, s.id]);
  const payload = { sessionId: s.id, startedAt: s.startedAt, deadlineAt: s.deadlineAt, serverNow: Date.now(), isUnlimited: s.isUnlimited };
  [s.userA, s.userB].forEach(p => { if (p.socketId) io.to(p.socketId).emit('voice_match_clock_started', payload); });
}

// عند انتهاء المهلة: الخادم وحده يقرر. كشف الطرفين = تستمر، غير ذلك = تنتهي.
function finalizeVoiceMatchDeadline(sessionId) {
  const s = activeVoiceMatchSessions.get(sessionId);
  if (!s) return;
  if (s.userA.revealed && s.userB.revealed) { markVoiceMatchUnlimited(s); return; }
  endVoiceMatchSession(sessionId, 'time_up');
}

function markVoiceMatchUnlimited(s) {
  s.isUnlimited = true;
  s.deadlineAt = null;
  if (s.timer) { clearTimeout(s.timer); s.timer = null; }
  vmCallLog('UPDATE voice_calls SET status = ?, unlimited_at = ? WHERE id = ?', ['UNLIMITED_CALL', new Date().toISOString(), s.id]);
}

// إنشاء مكالمة توافق صوتي بين طرفين خرجا من الطابور (كلاهما ضغط زر التوافق)
async function createVoiceMatchSession(waiting, accepterUser, accepterSocketId) {
  const partnerUser = waiting.user;
  const compatibility = computeSoulCompatibility(accepterUser, partnerUser);
  const sessionId = `vmatch-${Date.now()}-${uuidv4().slice(0, 6)}`;
  const sessionData = {
    id: sessionId,
    userA: { id: partnerUser.id, socketId: waiting.socketId, user: partnerUser, revealed: false, audioReady: false }, // A = كان ينتظر (offerer)
    userB: { id: accepterUser.id, socketId: accepterSocketId, user: accepterUser, revealed: false, audioReady: false }, // B = الواصل لاحقاً (answerer)
    createdAt: Date.now(),
    startedAt: null,
    deadlineAt: null,
    clockStarted: false,
    ended: false,
    duration: VOICE_MATCH_DURATION_MS / 1000,
    isUnlimited: false,
    timer: null,
    connectTimer: null
  };
  // الدقائق الخمس لا تبدأ الآن؛ إن لم يتصل الطرفان صوتياً خلال المهلة تُغلق الجلسة
  sessionData.connectTimer = setTimeout(() => {
    const s = activeVoiceMatchSessions.get(sessionId);
    if (s && !s.clockStarted) endVoiceMatchSession(sessionId, 'connect_timeout');
  }, VOICE_MATCH_CONNECT_TIMEOUT_MS);
  activeVoiceMatchSessions.set(sessionId, sessionData);

  await vmCallLog('INSERT INTO voice_calls (id, user_a_id, user_b_id, status) VALUES (?, ?, ?, ?)', [sessionId, partnerUser.id, accepterUser.id, 'ANONYMOUS_CALL']);
  await recordVoiceMatchUsage(accepterUser.id, sessionId);
  await recordVoiceMatchUsage(partnerUser.id, sessionId);

  const usedA = await getVoiceMatchUsageCount(partnerUser.id);
  const usedB = await getVoiceMatchUsageCount(accepterUser.id);
  const maskedPartner = {
    id: partnerUser.id,
    maskedName: `روح متوافقة #${String(partnerUser.id).slice(-4)}`,
    maskedAvatar: '/avatars/masked-avatar.png',
    soul_planet: partnerUser.soul_planet || 'كوكب السول 🪐',
    compatibility,
    level: partnerUser.level || 5
  };
  const maskedSelf = {
    id: accepterUser.id,
    maskedName: `روح غامضة #${String(accepterUser.id).slice(-4)}`,
    maskedAvatar: '/avatars/masked-avatar.png',
    soul_planet: accepterUser.soul_planet || 'كوكب السول 🪐',
    compatibility,
    level: accepterUser.level || 5
  };
  io.to(accepterSocketId).emit('voice_match_connected', {
    sessionId, isAnonymous: true, duration: VOICE_MATCH_DURATION_MS / 1000, compatibility, clockStarted: false,
    role: 'answerer', remaining: Math.max(0, (await getVoiceMatchLimit(accepterUser.id)) - usedB),
    partner: maskedPartner, selfMasked: maskedSelf
  });
  io.to(waiting.socketId).emit('voice_match_connected', {
    sessionId, isAnonymous: true, duration: VOICE_MATCH_DURATION_MS / 1000, compatibility, clockStarted: false,
    role: 'offerer', remaining: Math.max(0, (await getVoiceMatchLimit(partnerUser.id)) - usedA),
    partner: maskedSelf, selfMasked: maskedPartner
  });
  return sessionData;
}

// إلغاء الطلب عند المدعوين (انتهاء/إلغاء/قبول من شخص آخر)
function cancelVoiceMatchRequests(entry, reason) {
  if (!entry || !entry.invitedUserIds) return;
  for (const uid of entry.invitedUserIds) {
    const set = userSockets.get(uid);
    if (!set) continue;
    for (const sid of set) io.to(sid).emit('voice_match_request_cancelled', { requestId: entry.requestId, reason });
  }
  entry.invitedUserIds = [];
}

// عدد محاولات التوافق الصوتي خلال آخر 24 ساعة
// الحد اليومي للعضو: الأساسي، أو الأعلى إن كانت ميزة VIP «التوافق الصوتي» مفتوحة له
async function getVoiceMatchLimit(userId) {
  try {
    const u = await get('SELECT vip_level, vip_until FROM users WHERE id = ?', [userId]);
    return vipPerks.hasPerk(u, 'voice_match') ? VOICE_MATCH_VIP_LIMIT : VOICE_MATCH_LIMIT;
  } catch (e) { return VOICE_MATCH_LIMIT; }
}
async function getVoiceMatchUsageCount(userId) {
  try {
    const row = await get(`SELECT COUNT(*) AS c FROM voice_match_usage WHERE user_id = ? AND created_at > datetime('now', '-24 hours')`, [userId]);
    return row ? (row.c || 0) : 0;
  } catch (e) {
    return 0;
  }
}

async function recordVoiceMatchUsage(userId, sessionId) {
  try {
    await run(`INSERT INTO voice_match_usage (user_id, session_id) VALUES (?, ?)`, [userId, sessionId]);
  } catch (e) { console.error('voice_match_usage insert error:', e); }
}

// إنهاء جلسة التوافق الصوتي وإشعار الطرفين (الخادم هو المرجع الوحيد للإنهاء)
function endVoiceMatchSession(sessionId, reason) {
  const s = activeVoiceMatchSessions.get(sessionId);
  if (!s) return;
  s.ended = true;
  activeVoiceMatchSessions.delete(sessionId);
  if (s.timer) { clearTimeout(s.timer); s.timer = null; }
  if (s.connectTimer) { clearTimeout(s.connectTimer); s.connectTimer = null; }
  vmCallLog('UPDATE voice_calls SET status = ?, ended_at = ? WHERE id = ?', ['ENDED', new Date().toISOString(), sessionId]);
  const payload = { sessionId, reason };
  if (s.userA && s.userA.socketId) io.to(s.userA.socketId).emit('voice_match_ended', payload);
  if (s.userB && s.userB.socketId) io.to(s.userB.socketId).emit('voice_match_ended', payload);
}

// محرك المطابقة: يبحث عن أفضل شريك داخل الطابور فقط (كلاهما WAITING وضغط الزر).
// الحجز يتم بتغيير state إلى MATCHING بشكل متزامن قبل أي await لمنع تكرار المطابقة.
async function tryMatchVoiceQueue(entry) {
  if (!entry || entry.state !== 'WAITING') return false;
  const candidates = voiceMatchQueue.filter(q =>
    q !== entry && q.state === 'WAITING' && q.userId !== entry.userId && q.socketId !== entry.socketId
  );
  const scored = [];
  for (const q of candidates) {
    if (!vmGenderMutuallyAccepted(entry, q)) continue; // فلتر الجنس لكل طرف
    if (!isVoiceMatchCompatible(entry.user, q.user)) continue;
    if (await isBlockedEitherWay(entry.userId, q.userId)) continue;
    if ((await getVoiceMatchUsageCount(q.userId)) >= (await getVoiceMatchLimit(q.userId))) continue;
    scored.push({ q, score: computeSoulCompatibility(entry.user, q.user) });
  }
  scored.sort((x, y) => y.score - x.score);
  for (const { q } of scored) {
    // أعد فحص الحالة بعد الـ awaits: قد يكون أحدهما حُجز أو غادر
    if (entry.state !== 'WAITING' || q.state !== 'WAITING') continue;
    if (voiceMatchQueue.indexOf(entry) === -1 || voiceMatchQueue.indexOf(q) === -1) continue;
    if (isUserInActiveVoiceMatch(entry.userId) || isUserInActiveVoiceMatch(q.userId)) continue;
    entry.state = 'MATCHING'; q.state = 'MATCHING'; // حجز متزامن للطرفين
    voiceMatchQueue.splice(voiceMatchQueue.indexOf(entry), 1);
    voiceMatchQueue.splice(voiceMatchQueue.indexOf(q), 1);
    if (entry.timeout) clearTimeout(entry.timeout);
    if (q.timeout) clearTimeout(q.timeout);
    try {
      await createVoiceMatchSession(q, entry.user, entry.socketId); // q كان ينتظر أولاً
    } catch (e) {
      console.error('createVoiceMatchSession failed:', e);
      io.to(entry.socketId).emit('voice_match_error', { code: 'ERROR', message: 'تعذر إنشاء المكالمة، حاول مرة أخرى' });
      io.to(q.socketId).emit('voice_match_error', { code: 'ERROR', message: 'تعذر إنشاء المكالمة، حاول مرة أخرى' });
    }
    return true;
  }
  return false;
}

// إزالة مستخدم من طابور الانتظار (حسب السوكيت أو User ID)
function removeFromVoiceMatchQueue(socketId, userId) {
  const idx = voiceMatchQueue.findIndex(q => q.socketId === socketId || (userId && q.userId === userId));
  if (idx === -1) return null;
  const [q] = voiceMatchQueue.splice(idx, 1);
  if (q.timeout) clearTimeout(q.timeout);
  cancelVoiceMatchRequests(q, 'cancelled');
  return q;
}

// تنظيف طابور الانتظار من الإدخالات الميتة (سوكيت منقطع)
function pruneVoiceMatchQueue() {
  for (let i = voiceMatchQueue.length - 1; i >= 0; i--) {
    const q = voiceMatchQueue[i];
    const alive = io.sockets.sockets.has(q.socketId) && userSockets.has(q.userId) && userSockets.get(q.userId).has(q.socketId);
    if (!alive) {
      if (q.timeout) clearTimeout(q.timeout);
      cancelVoiceMatchRequests(q, 'cancelled');
      voiceMatchQueue.splice(i, 1);
    }
  }
}

// تحرير المستخدم من كل المقاعد وقوائم الحضور في كل الغرف وإبلاغ الجميع بخروجه
async function releaseUserFromAllRooms(uid) {
  if (!uid) return;
  try {
    const heldSeats = await all('SELECT room_id, seat_index, is_muted FROM room_seats WHERE user_id = ?', [uid]);
    if (heldSeats && heldSeats.length > 0) {
      for (const s of heldSeats) {
        clearRoomMusicState(s.room_id, uid, s.seat_index);
        await run('UPDATE room_seats SET user_id = NULL, is_muted = ? WHERE room_id = ? AND seat_index = ?', [s.is_muted ? 1 : 0, s.room_id, s.seat_index]);
        io.to(`room:${s.room_id}`).emit('seat_updated', { seatIndex: s.seat_index, user: null, isMuted: !!s.is_muted });
        io.to(`room:${s.room_id}`).emit('webrtc_stream_ended', { senderSocketId: null, streamType: 'voice_seat', userId: uid });
      }
    }
  } catch (e) {}
  for (const [rId, rState] of activeRoomStates.entries()) {
    if (rState.activeAudience && rState.activeAudience.has(uid)) {
      rState.activeAudience.delete(uid);
      rState.speakers.delete(uid);
      const audienceList = visibleAudienceList(rState);
      io.to(`room:${rId}`).emit('user_left_room', { userId: uid, audienceCount: audienceList.length, audience: audienceList });
      io.emit('room_occupants_updated', { roomId: rId, count: audienceList.length, preview: buildAudiencePreview(rId) });
    }
  }
}

// خروج فوري عند إغلاق الصفحة: socketId -> دالة الخروج الخاصة بهذا السوكت
const socketInstantLeave = new Map();
// مسار احتياطي (navigator.sendBeacon) لأن إرسال السوكت قد لا يصل أثناء إغلاق التبويب
app.post('/api/socket-leave', (req, res) => {
  try {
    const sid = req.body && req.body.socketId;
    const fn = sid && socketInstantLeave.get(String(sid));
    if (fn) fn();
  } catch (e) {}
  res.sendStatus(204);
});

io.on('connection', (socket) => {
  let currentUserId = null;
  let currentRoomId = null;

  // مهام يومية: دقائق المشاهدة والصعود على المايك (كل دقيقة والعضو داخل غرفة)
  const missionTicker = setInterval(async () => {
    try {
      if (!currentUserId || !currentRoomId) return;
      const st = activeRoomStates.get(currentRoomId);
      if (!st || !st.activeAudience.has(currentUserId)) return;
      recordMission(currentUserId, 'watch_minutes', 1);
      const seated = await get('SELECT 1 AS x FROM room_seats WHERE room_id = ? AND user_id = ?', [currentRoomId, currentUserId]);
      if (seated) recordMission(currentUserId, 'mic_minutes', 1);
    } catch (e) {}
  }, 60000);

  // 1. User Online Registration
  socket.on('user_connect', (userId) => {
    if (!userId) return;
    currentUserId = userId;
    instantLeaveDone = false;
    onlineUsers.set(socket.id, userId);
    recordMission(userId, 'app_open', 1);

    if (!userSockets.has(userId)) {
      userSockets.set(userId, new Set());
    }
    userSockets.get(userId).add(socket.id);
    setTimeout(() => syncLevelRewardsOnConnect(userId), 1500); // مكافآت المستويات المعلّقة + إشعارات فاتته

    // Broadcast online status
    io.emit('user_status_change', { userId, status: 'online' });
  });

  // خروج فوري عند إغلاق الصفحة/التطبيق (بدون مهلة السماح): يُنزل المستخدم ويُظهر خروجه للجميع.
  // انقطاع الشبكة العادي لا يمرّ من هنا بل يبقى على مهلة السماح ثم يعود تلقائياً.
  let instantLeaveDone = false;
  const instantLeave = async () => {
    const uid = currentUserId;
    if (!uid || instantLeaveDone) return;
    instantLeaveDone = true;
    const sockSet = userSockets.get(uid);
    if (sockSet) sockSet.delete(socket.id);
    if (currentRoomId) { try { socket.leave(`room:${currentRoomId}`); } catch (e) {} }
    if (!sockSet || sockSet.size === 0) {
      userSockets.delete(uid);
      io.emit('user_status_change', { userId: uid, status: 'offline' });
      await releaseUserFromAllRooms(uid);
    }
  };
  socketInstantLeave.set(socket.id, instantLeave);
  socket.on('page_closing', instantLeave);

  // 2. Joining a Voice Room
  socket.on('join_room', async ({ roomId, user, keepSeat, hiddenChoice }) => {
    if (!roomId) return;
    {
      const gateRoom = await get('SELECT id, host_id, access_hash FROM rooms WHERE id = ?', [roomId]);
      if (await roomNeedsCode(gateRoom, user && user.id)) {
        return socket.emit('room_password_required', { roomId });
      }
    }
    // الدخول المخفي: المستحق للميزة يُخيَّر بين «مخفي» و«ظاهر» قبل الدخول الفعلي
    let hiddenEntry = false;
    if (user && user.id) {
      try {
        const hRoom = await get('SELECT id, host_id FROM rooms WHERE id = ?', [roomId]);
        const hUser = await get('SELECT id, role, level, wealth_level, charm_level, vip_level, vip_until FROM users WHERE id = ?', [user.id]);
        if (hRoom && hRoom.host_id !== user.id && await canEnterHidden(hRoom, hUser)) {
          const prevState = activeRoomStates.get(roomId);
          const prevEntry = prevState && prevState.activeAudience.get(user.id);
          if (prevEntry) hiddenEntry = !!prevEntry.hidden_entry;            // إعادة اتصال: نحافظ على الاختيار السابق
          else if (hiddenChoice === 'hidden') hiddenEntry = true;
          else if (hiddenChoice === 'visible') hiddenEntry = false;
          else return socket.emit('hidden_entry_choice_required', { roomId });
        }
      } catch (e) { console.error('hidden entry check error:', e); }
    }
    currentRoomId = roomId;
    instantLeaveDone = false;
    socket.join(`room:${roomId}`);

    if (user && user.id) {
      currentUserId = user.id;
      onlineUsers.set(socket.id, user.id);
      if (!userSockets.has(user.id)) {
        userSockets.set(user.id, new Set());
      }
      userSockets.get(user.id).add(socket.id);
    }

    if (!activeRoomStates.has(roomId)) {
      activeRoomStates.set(roomId, {
        pkState: null,
        activeAudience: new Map(),
        speakers: new Set(),
        mutedChatUsers: new Set(),
        bannedUsers: new Set(),
        allSeatsMuted: false
      });
    }

    const roomState = activeRoomStates.get(roomId);
    if (roomState.allSeatsMuted === false) {
      try {
        const roomMuteRow = await get('SELECT seat_settings FROM rooms WHERE id = ?', [roomId]);
        const muteSettings = jparse(roomMuteRow && roomMuteRow.seat_settings, {});
        if (typeof muteSettings.global_mute === 'boolean') roomState.allSeatsMuted = muteSettings.global_mute;
        else {
          const guestSeats = await all('SELECT is_muted FROM room_seats WHERE room_id = ? AND seat_index > 0', [roomId]);
          roomState.allSeatsMuted = guestSeats.length > 0 && guestSeats.every(seat => !!seat.is_muted);
        }
      } catch (e) {}
    }

    // تحميل المطرودين والمكتومين المحفوظين
    try {
      const restr = await all(`SELECT r.user_id, r.type, COALESCE(r.by_owner, 0) AS by_owner, COALESCE(u.wealth_level, 1) AS wealth_level, u.vip_level, u.vip_until
        FROM room_restrictions r LEFT JOIN users u ON u.id = r.user_id WHERE r.room_id = ?`, [roomId]);
      restr.forEach(r => {
        const set = r.type === 'ban' ? roomState.bannedUsers : roomState.mutedChatUsers;
        // حصانة الثروة 26+: القيود القديمة التي لم يفرضها صاحب الغرفة/الإدارة لا تسري عليه
        if (vipPerks.hasPerk(r, 'kick_immunity')) set.delete(r.user_id);   // حصانة VIP: لا تسري عليه أي قيود قديمة
        else if ((Number(r.wealth_level) || 1) >= immuneLevel() && !r.by_owner) set.delete(r.user_id);
        else set.add(r.user_id);
      });
    } catch (e) { console.error('load restrictions error:', e); }

    // Check if user is banned from this room
    if (user && user.id && roomState.bannedUsers.has(user.id)) {
      return socket.emit('room_kicked_notice', { message: 'لقد تم طردك من هذه الغرفة بواسطة إدارة الروم!' });
    }

    // تسجيل آخر دخول لصاحب الغرفة (للحذف التلقائي بعد 5 أيام غياب)
    if (user && user.id) {
      try { await run('UPDATE rooms SET host_last_seen = CURRENT_TIMESTAMP WHERE id = ? AND host_id = ?', [roomId, user.id]); } catch (e) {}
    }
    // من هو داخل الغرفة بالفعل (إعادة انضمام/تبديل شاشة/مكالمة خاصة) لا يُنزَل عن مقعده
    const alreadyInThisRoom = !!(user && user.id && roomState.activeAudience.has(user.id));

    // الدخول إلى الغرفة لا يصعّد أحداً إلى المقعد أبداً (حتى المالك/الأدمن/المضيف):
    // أي مقعد عالق باسمه من جلسة سابقة يُحرَّر، والصعود يتم فقط بنقرة منه على المقعد.
    if (user && user.id && !keepSeat && !alreadyInThisRoom) {
      try {
        const staleSeats = await all('SELECT seat_index, is_muted FROM room_seats WHERE room_id = ? AND user_id = ?', [roomId, user.id]);
        for (const st of staleSeats) {
          clearRoomMusicState(roomId, user.id, st.seat_index);
          await run('UPDATE room_seats SET user_id = NULL, is_muted = ? WHERE room_id = ? AND seat_index = ?', [st.is_muted ? 1 : 0, roomId, st.seat_index]);
          io.to(`room:${roomId}`).emit('seat_updated', { seatIndex: st.seat_index, user: null, isMuted: !!st.is_muted });
        }
        roomState.speakers.delete(user.id);
      } catch (e) { console.error('stale seat cleanup on join error:', e); }
    }

    // حفظ كل من يدخل الغرفة في قائمة الأعضاء (المتخفّي لا يُسجَّل حتى لا يظهر اسمه)
    if (user && user.id && !hiddenEntry) {
      try {
        await run(`INSERT INTO room_members (room_id, user_id) VALUES (?, ?)
          ON CONFLICT(room_id, user_id) DO UPDATE SET last_joined = CURRENT_TIMESTAMP, visits = visits + 1`, [roomId, user.id]);
      } catch (e) { console.error('save member error:', e); }
    }
    if (user && user.id) {
      try {
        await run(`INSERT INTO room_visits (user_id, room_id) VALUES (?, ?)
          ON CONFLICT(user_id, room_id) DO UPDATE SET last_visited = CURRENT_TIMESTAMP`, [user.id, roomId]);
      } catch (e) { console.error('save visit error:', e); }
    }

    let joinedUserObj = user;
    if (user && user.id) {
      const dbUser = await get('SELECT id, name, avatar, avatar_frame, chat_frame, entry_effect, level, wealth_level, charm_level, soul_planet, bio, role, gender, age, vip_level, vip_until FROM users WHERE id = ?', [user.id]) || user;
      if (hiddenEntry) dbUser.hidden_entry = true;
      joinedUserObj = dbUser;
      roomState.activeAudience.set(user.id, dbUser);
    }

    const audienceList = visibleAudienceList(roomState);
    const isChatMuted = user && user.id ? roomState.mutedChatUsers.has(user.id) : false;

    // فقاعة الدخول المفعّلة من المتجر (تظهر في إشعار الدخول في منتصف الشاشة وفي سطر الدخول فقط)
    const joinBubbleUrl = (joinedUserObj && joinedUserObj.id) ? await getEquippedJoinBubbleUrl(joinedUserObj.id) : '';

    // Notify room occupants (المتخفّي: لا إشعار للآخرين)
    if (!hiddenEntry) {
      io.to(`room:${roomId}`).emit('user_joined_room', {
        user: joinedUserObj ? Object.assign({}, joinedUserObj, { chat_bubble: joinBubbleUrl }) : joinedUserObj,
        audienceCount: audienceList.length,
        audience: audienceList
      });
    } else {
      socket.emit('hidden_entry_status', { roomId, hidden: true });
    }

    const joinUserWithBubble = joinedUserObj ? Object.assign({}, joinedUserObj, { chat_bubble: joinBubbleUrl }) : joinedUserObj;
    let entryEffectShown = false;

    // تأثير الدخول يظهر فقط لمن يملك قالب دخول مفعّلاً
    if (!hiddenEntry && joinedUserObj && joinedUserObj.id && joinedUserObj.entry_effect) {
      try {
        const tpl = await getOwnedEntryTemplate(joinedUserObj.id, joinedUserObj.entry_effect);
        if (tpl) {
          entryEffectShown = true;
          io.to(`room:${roomId}`).emit('room_entry_effect', {
            user: joinUserWithBubble,
            effectId: tpl.id,
            imageUrl: tpl.image_url
          });
        }
      } catch (e) { console.error('entry effect error:', e); }
    }
    // فقاعة الدخول تظهر في شريط join-banner-host فقط (عبر user_joined_room) ولا تُضاف إلى دردشة الغرفة


    // ترحيب تلقائي باسم صاحب الغرفة: "أهلاً، @اسم_الداخل" (مرة كل دقيقة لكل شخص في كل غرفة لمنع التكرار عند إعادة الاتصال)
    if (!hiddenEntry && joinedUserObj && joinedUserObj.id) {
      try {
        const welcomeKey = `${roomId}:${joinedUserObj.id}`;
        const lastWelcome = recentRoomWelcomes.get(welcomeKey) || 0;
        if (Date.now() - lastWelcome > 60 * 1000) {
          recentRoomWelcomes.set(welcomeKey, Date.now());
          const roomRow = await get('SELECT host_id FROM rooms WHERE id = ?', [roomId]);
          if (roomRow && roomRow.host_id && roomRow.host_id !== joinedUserObj.id) {
            const host = await get('SELECT * FROM users WHERE id = ?', [roomRow.host_id]);
            if (host) {
              const hostBubble = await getEquippedBubbleUrl(host.id);
              const mention = joinedUserObj.name || 'ضيف';
              setTimeout(() => {
                io.to(`room:${roomId}`).emit('room_message', {
                  id: `welcome-${Date.now()}-${joinedUserObj.id}`,
                  sender_id: host.id,
                  sender_name: host.name,
                  sender_avatar: host.avatar,
                  sender_frame: host.avatar_frame,
                  sender_chat_frame: host.chat_frame || '',
                  sender_chat_bubble: hostBubble,
                  sender_level: host.level,
                  sender_wealth_level: host.wealth_level || 3,
                  sender_charm_level: host.charm_level || 4,
                  sender_role: host.role,
                  message_type: 'text',
                  auto_welcome: true,
                  welcome_mention: mention,
                  content: `أهلاً، @${mention}`,
                  created_at: new Date().toISOString()
                });
              }, 700);
            }
          }
        }
      } catch (e) { console.error('auto welcome error:', e); }
    }

    // Notify lobby of accurate real occupants count
    io.emit('room_occupants_updated', {
      roomId,
      count: audienceList.length,
      preview: buildAudiencePreview(roomId)
    });

    // Send initial room presence & full audience array to this user
    socket.emit('room_presence_sync', {
      audienceCount: audienceList.length,
      audience: hiddenEntry ? audienceList.concat([joinedUserObj]) : audienceList,
      pkState: roomState.pkState,
      isChatMuted,
      mutedChatUsers: Array.from(roomState.mutedChatUsers)
    });
  });

  // 3. Leaving Voice Room
  socket.on('leave_room', async ({ roomId, userId }) => {
    if (!roomId) return;
    const socketUserId = onlineUsers.get(socket.id) || currentUserId;
    if (socketUserId && userId && String(socketUserId) !== String(userId)) return;
    const leavingUserId = socketUserId || userId;
    clearRoomMusicState(roomId, leavingUserId);
    socket.leave(`room:${roomId}`);
    if (activeRoomStates.has(roomId)) {
      const roomState = activeRoomStates.get(roomId);
      if (leavingUserId) {
        roomState.activeAudience.delete(leavingUserId);
        roomState.speakers.delete(leavingUserId);
      }
      const audienceList = visibleAudienceList(roomState);
      socket.to(`room:${roomId}`).emit('user_left_room', {
        userId: leavingUserId,
        audienceCount: audienceList.length,
        audience: audienceList
      });

      // Notify lobby of accurate real occupants count
      io.emit('room_occupants_updated', {
        roomId,
        count: audienceList.length,
        preview: buildAudiencePreview(roomId)
      });
    }

    if (leavingUserId) {
      try {
        const seats = await all('SELECT seat_index, is_muted FROM room_seats WHERE room_id = ? AND user_id = ?', [roomId, leavingUserId]);
        if (seats && seats.length > 0) {
          for (const s of seats) {
            clearRoomMusicState(roomId, leavingUserId, s.seat_index);
            await run('UPDATE room_seats SET user_id = NULL, is_muted = ? WHERE room_id = ? AND seat_index = ?', [s.is_muted ? 1 : 0, roomId, s.seat_index]);
            io.to(`room:${roomId}`).emit('seat_updated', {
              seatIndex: s.seat_index,
              user: null,
              isMuted: !!s.is_muted
            });
          }
        }
      } catch (e) {
        console.error('Leave room seat cleanup error:', e);
      }
    }
  });

  // 4. Room Chat Message
  socket.on('send_room_message', async ({ roomId, userId, content }) => {
    if (!roomId || !userId || !content) return;
    if (await roomNeedsCode(await get('SELECT id, host_id, access_hash FROM rooms WHERE id = ?', [roomId]), userId)) {
      return socket.emit('room_password_required', { roomId });
    }

    // Check if user is muted from writing in public chat
    const roomState = activeRoomStates.get(roomId);
    if (roomState && roomState.mutedChatUsers && roomState.mutedChatUsers.has(userId)) {
      return socket.emit('chat_error', {
        message: 'تم كتمك من الكتابة في الدردشة العامة من قِبل إدارة الغرفة 🔇'
      });
    }

    try {
      const user = await get('SELECT * FROM users WHERE id = ?', [userId]);
      if (!user) return;
      recordMission(userId, 'room_comments', 1);

      const msgId = `msg-${Date.now()}`;
      await run(`
        INSERT INTO messages (id, sender_id, room_id, message_type, content)
        VALUES (?, ?, ?, 'text', ?)
      `, [msgId, userId, roomId, content]);

      // نقاط المستوى: التفاعل في الدردشة (مقيَّد زمنياً ضد السبام)
      addChatInteractionXp(userId, 5);

      const payload = {
        id: msgId,
        sender_id: user.id,
        sender_name: user.name,
        sender_avatar: user.avatar,
        sender_frame: user.avatar_frame,
        sender_chat_frame: user.chat_frame || '',
        sender_chat_bubble: await getEquippedBubbleUrl(user.id),
        sender_level: user.level,
        sender_wealth_level: user.wealth_level || 3,
        sender_charm_level: user.charm_level || 4,
        sender_role: user.role,
        message_type: 'text',
        content,
        created_at: new Date().toISOString()
      };

      io.to(`room:${roomId}`).emit('room_message', payload);
    } catch (err) {
      console.error('Room message error:', err);
    }
  });

  // إرسال إيموجي (مرفوع من الإدارة): فوق المقعد إن كان المرسل على مقعد، وإلا في الدردشة العامة
  socket.on('send_room_emoji', async ({ roomId, userId, emojiId }) => {
    if (!roomId || !userId || !emojiId) return;
    try {
      const roomState = activeRoomStates.get(roomId);
      if (roomState && roomState.mutedChatUsers && roomState.mutedChatUsers.has(userId)) {
        return socket.emit('chat_error', { message: 'تم كتمك من الكتابة في الدردشة العامة من قِبل إدارة الغرفة 🔇' });
      }
      const em = await get('SELECT id, name, image_url FROM room_emojis WHERE id = ? AND is_active = 1', [emojiId]);
      if (!em) return;
      const user = await get('SELECT * FROM users WHERE id = ?', [userId]);
      if (!user) return;

      // على المقعد: يظهر فوق المقعد فقط. خارج المقعد: يظهر في الدردشة العامة فقط.
      // (نتحقق من المقعد من قاعدة البيانات لا من العميل)
      const seat = await get('SELECT seat_index FROM room_seats WHERE room_id = ? AND user_id = ?', [roomId, userId]);
      if (seat) {
        io.to(`room:${roomId}`).emit('seat_emoji_broadcast', {
          roomId,
          seatIndex: seat.seat_index,
          emojiId: em.id,
          emojiSvg: `<img src="${em.image_url}" alt="" style="width:100%;height:100%;object-fit:contain;" />`,
          emojiName: em.name,
          user: { id: user.id, name: user.name }
        });
        return;
      }

      const msgId = `msg-${Date.now()}`;
      await run(`INSERT INTO messages (id, sender_id, room_id, message_type, content) VALUES (?, ?, ?, 'emoji', ?)`,
        [msgId, userId, roomId, em.image_url]);

      io.to(`room:${roomId}`).emit('room_message', {
        id: msgId,
        sender_id: user.id,
        sender_name: user.name,
        sender_avatar: user.avatar,
        sender_frame: user.avatar_frame,
        sender_chat_frame: user.chat_frame || '',
        sender_chat_bubble: await getEquippedBubbleUrl(user.id),
        sender_level: user.level,
        sender_wealth_level: user.wealth_level || 3,
        sender_charm_level: user.charm_level || 4,
        sender_role: user.role,
        message_type: 'emoji',
        content: em.image_url,
        created_at: new Date().toISOString()
      });
    } catch (err) {
      console.error('Room emoji error:', err);
    }
  });

  // 4b. Trigger Room Entry Effect (from Accessories Menu)
  socket.on('trigger_entry_effect', async ({ roomId, user, effectId }) => {
    if (!roomId || !effectId) return;
    try {
      const uid = onlineUsers.get(socket.id) || (user && user.id);
      const tpl = await getOwnedEntryTemplate(uid, effectId);
      if (!tpl) return; // لا يُعرض إلا قالب يملكه المستخدم فعلاً
      io.to(`room:${roomId}`).emit('room_entry_effect', {
        user,
        effectId: tpl.id,
        imageUrl: tpl.image_url
      });
    } catch (e) { console.error('trigger entry effect error:', e); }
  });

  // 5. Take Seat (Up to stage)
  socket.on('take_seat', async ({ roomId, seatIndex, userId }) => {
    if (!roomId || seatIndex === undefined || !userId) return;

    try {
      // Check if target seat is seat 0 (the Host Throne)
      if (seatIndex === 0) {
        const room = await get('SELECT host_id FROM rooms WHERE id = ?', [roomId]);
        const userObj = await get('SELECT role FROM users WHERE id = ?', [userId]);
        const isOwner = userObj && userObj.role === 'owner';
        if (room && room.host_id !== userId && !isOwner) {
          return socket.emit('seat_error', { message: 'هذا المقعد مخصص لصاحب الغرفة (المضيف) فقط 👑' });
        }
      }

      // Check if target seat is locked
      const roomRow = await get('SELECT seat_count FROM rooms WHERE id = ?', [roomId]);
      if (roomRow && seatIndex > (roomRow.seat_count || 8)) {
        return socket.emit('seat_error', { message: 'هذا المقعد غير متاح في هذه الغرفة!' });
      }
      {
        const sRow = await get('SELECT seat_settings, host_id FROM rooms WHERE id = ?', [roomId]);
        const ss = jparse(sRow && sRow.seat_settings, {});
        if (ss.who === 'members' && sRow && sRow.host_id !== userId) {
          const mem = await get('SELECT 1 AS x FROM room_members WHERE room_id = ? AND user_id = ?', [roomId, userId]);
          const mod = await get('SELECT 1 AS x FROM room_moderators WHERE room_id = ? AND user_id = ?', [roomId, userId]);
          const u2 = await get('SELECT role FROM users WHERE id = ?', [userId]);
          if (!mem && !mod && !(u2 && ROOM_STAFF_ROLES.includes(u2.role))) {
            return socket.emit('seat_error', { message: 'الصعود إلى المايك متاح لأعضاء الغرفة فقط' });
          }
        }
      }
      const targetSeat = await get('SELECT * FROM room_seats WHERE room_id = ? AND seat_index = ?', [roomId, seatIndex]);
      if (targetSeat && targetSeat.is_locked) {
        return socket.emit('seat_error', { message: 'هذا المقعد مقفل حالياً!' });
      }
      if (targetSeat && targetSeat.user_id && targetSeat.user_id !== userId) {
        return socket.emit('seat_error', { message: 'هذا الكرسي محجوز حالياً!' });
      }

      // Check if user is currently occupying ANY OTHER seat in this room
      const prevSeats = await all('SELECT seat_index, is_muted FROM room_seats WHERE room_id = ? AND user_id = ? AND seat_index != ?', [roomId, userId, seatIndex]);
      if (prevSeats && prevSeats.length > 0) {
        for (const prev of prevSeats) {
          await run('UPDATE room_seats SET user_id = ?, is_muted = ? WHERE room_id = ? AND seat_index = ?', [null, prev.is_muted ? 1 : 0, roomId, prev.seat_index]);
          io.to(`room:${roomId}`).emit('seat_updated', {
            seatIndex: prev.seat_index,
            user: null,
            isMuted: !!prev.is_muted,
            movedTo: seatIndex // انتقال بين مقعدين: المتحدث ما زال يبث فلا تُسكتوا صوته
          });
        }
      }

      // Assign requested seat while preserving the admin mute policy of that seat.
      // يرث الصاعد كتم الإدارة فقط (admin_muted) — لا كتم من سبقه لنفسه
      const seatMutePolicy = targetSeat && targetSeat.admin_muted ? 1 : 0;
      await run('UPDATE room_seats SET user_id = ?, is_muted = ? WHERE room_id = ? AND seat_index = ?', [userId, seatMutePolicy, roomId, seatIndex]);

      // انتقال المقعد لا يوقف أغنية المستخدم؛ حدّث الحالة المحفوظة فوراً حتى
      // لا يرى الداخلون الجدد رقم المقعد القديم أثناء نافذة الانتقال.
      const movingMusic = roomMusicState.get(roomId)?.get(String(userId));
      if (movingMusic) {
        movingMusic.seatIndex = seatIndex;
        io.to(`room:${roomId}`).emit('room_music_started', movingMusic);
      }

      const user = await get('SELECT id, name, avatar, avatar_frame, level, charm_level FROM users WHERE id = ?', [userId]);

      // نقاط المستوى: الصعود على المايك
      addLevelPoints(userId, 10);

      io.to(`room:${roomId}`).emit('seat_updated', {
        seatIndex,
        user,
        isMuted: !!seatMutePolicy,
        adminMuted: !!seatMutePolicy
      });
    } catch (err) {
      console.error('Take seat error:', err);
    }
  });

  // 6. Leave Seat (Down from stage)
  socket.on('leave_seat', async ({ roomId, seatIndex, userId }) => {
    if (!roomId) return;
    const socketUserId = onlineUsers.get(socket.id) || currentUserId;
    if (socketUserId && userId && String(socketUserId) !== String(userId)) return;
    const leavingUserId = socketUserId || userId;
    try {
      let seatsToLeave = [];
      if (leavingUserId) {
        seatsToLeave = await all('SELECT seat_index, is_muted FROM room_seats WHERE room_id = ? AND user_id = ?', [roomId, leavingUserId]);
      }
      if ((!seatsToLeave || seatsToLeave.length === 0) && seatIndex !== undefined) {
        const existingSeat = await get('SELECT is_muted FROM room_seats WHERE room_id = ? AND seat_index = ?', [roomId, seatIndex]);
        seatsToLeave = [{ seat_index: seatIndex, is_muted: existingSeat && existingSeat.is_muted ? 1 : 0 }];
      }

      // The server is authoritative: clear the song before broadcasting the
      // empty seat, even if the browser was closed before its stop event.
      if (leavingUserId) clearRoomMusicState(roomId, leavingUserId, seatsToLeave[0] && seatsToLeave[0].seat_index);
      for (const s of (seatsToLeave || [])) {
        await run('UPDATE room_seats SET user_id = NULL, is_muted = ? WHERE room_id = ? AND seat_index = ?', [s.is_muted ? 1 : 0, roomId, s.seat_index]);
        io.to(`room:${roomId}`).emit('seat_updated', {
          seatIndex: s.seat_index,
          user: null,
          isMuted: !!s.is_muted
        });
      }
      if (leavingUserId) {
        io.to(`room:${roomId}`).emit('webrtc_stream_ended', {
          roomId,
          streamType: 'voice_seat',
          userId: leavingUserId
        });
      }
    } catch (err) {
      console.error('Leave seat error:', err);
    }
  });

  // Seat Emoji / Animated Sticker Reaction (Over Mic Seat Avatar)
  socket.on('seat_emoji_reaction', async ({ roomId, seatIndex, emojiId, emojiSvg, emojiName, user }) => {
    if (!roomId || seatIndex === undefined || seatIndex === null) return;
    io.to(`room:${roomId}`).emit('seat_emoji_broadcast', {
      roomId,
      seatIndex,
      emojiId,
      emojiSvg,
      emojiName,
      user
    });
  });

  // 7. Toggle Mute
  socket.on('toggle_mute', async ({ roomId, seatIndex, isMuted }) => {
    if (!roomId || seatIndex === undefined) return;
    try {
      const seat = await get('SELECT user_id, is_muted, admin_muted FROM room_seats WHERE room_id = ? AND seat_index = ?', [roomId, seatIndex]);
      // الكتم/فك الكتم الذاتي مسموح لصاحب المقعد دائماً، إلا إن كان المقعد مكتوماً من الإدارة
      if (!seat || !seat.user_id) return;
      if (currentUserId && String(seat.user_id) !== String(currentUserId)) return;
      if (!isMuted && seat.admin_muted) {
        socket.emit('seat_mute_changed', { roomId, seatIndex, userId: seat.user_id, isMuted: true, adminMuted: true });
        return socket.emit('seat_error', { message: 'هذا المقعد مكتوم من الإدارة، ولا يمكن فك الكتم إلا بواسطة الأدمن 🔇' });
      }
      const targetUserId = seat.user_id;
      await run('UPDATE room_seats SET is_muted = ? WHERE room_id = ? AND seat_index = ?', [isMuted ? 1 : 0, roomId, seatIndex]);
      io.to(`room:${roomId}`).emit('seat_mute_changed', {
        roomId,
        seatIndex,
        userId: targetUserId,
        isMuted: !!isMuted,
        adminMuted: !!seat.admin_muted
      });
    } catch (err) {
      console.error('Mute toggle error:', err);
    }
  });

  // 8. Speaking / Sound Wave Indicator
  socket.on('mic_speaking', ({ roomId, userId, isSpeaking, volume }) => {
    if (!roomId || !userId) return;
    // Broadcast to room so avatars pulse with sound waves
    socket.to(`room:${roomId}`).emit('user_speaking_status', {
      userId,
      isSpeaking,
      volume: volume || 0.5
    });
  });

  // 9. Soundboard Effects (Claps, Laughter, Cheers, etc.)
  socket.on('play_sound_effect', ({ roomId, effect, soundName, senderName }) => {
    if (!roomId) return;
    io.to(`room:${roomId}`).emit('sound_effect_played', {
      effect,
      soundName,
      senderName
    });
  });

  // 9b. Music played from a microphone seat. The audio itself is sent through
  // the existing WebRTC voice stream; this event only synchronizes the small
  // now-playing indicator for the other participants.
  socket.on('room_music_started', async ({ roomId, userId, seatIndex, title, trackId, cover }) => {
    try {
      if (!roomId || !userId || seatIndex === undefined || seatIndex === null) return;
      const uid = onlineUsers.get(socket.id) || currentUserId;
      // لا نسمح لعميل أن يعلن موسيقى باسم مستخدم آخر، ولا لمقعد مكتوم
      // إدارياً. الكتم الذاتي لا يوقف الأغنية.
      if (!uid || String(uid) !== String(userId) || currentRoomId !== roomId) return;
      const seat = await get('SELECT seat_index, admin_muted FROM room_seats WHERE room_id = ? AND user_id = ?', [roomId, uid]);
      if (!seat || seat.admin_muted || Number(seat.seat_index) !== Number(seatIndex)) return;
      const payload = { roomId, userId: uid, seatIndex: seat.seat_index, title: title || 'موسيقى', trackId: trackId || '', cover: cover || '' };
      if (!roomMusicState.has(roomId)) roomMusicState.set(roomId, new Map());
      roomMusicState.get(roomId).set(String(uid), payload);   // حالة كل شخص مستقلة
      io.to(`room:${roomId}`).emit('room_music_started', payload);
    } catch (e) { /* حالة المؤشر اختيارية ولا تعطل الصوت */ }
  });

  socket.on('room_music_stopped', ({ roomId, userId, seatIndex }) => {
    if (!roomId || !userId || currentRoomId !== roomId) return;
    const uid = onlineUsers.get(socket.id) || currentUserId;
    if (!uid || String(uid) !== String(userId)) return;
    clearRoomMusicState(roomId, uid, seatIndex);
  });

  // زائر جديد يسأل: هل هناك موسيقى تعمل الآن؟ — نرسل الحالة له وحده (إن كان صاحبها ما زال على المقعد)
  socket.on('room_music_sync_request', async ({ roomId }) => {
    try {
      if (!roomId || currentRoomId !== roomId) return;
      const mm = roomMusicState.get(roomId);
      if (!mm || !mm.size) return;
      for (const [uid, cur] of Array.from(mm.entries())) {
        const seat = await get('SELECT user_id FROM room_seats WHERE room_id = ? AND seat_index = ?', [roomId, cur.seatIndex]);
        if (!seat || String(seat.user_id) !== String(cur.userId)) { mm.delete(uid); continue; }
        socket.emit('room_music_started', cur);
      }
      if (!mm.size) roomMusicState.delete(roomId);
    } catch (e) {}
  });

  // 9c. مزامنة تشغيل أغنية يوتيوب: صاحب المقعد يبثّ حالة المشغّل، والبقية يشغّلون نفس المقطع عندهم
  socket.on('room_yt_state', async (d) => {
    try {
      if (!d || !d.roomId || currentRoomId !== d.roomId) return;
      const uid = onlineUsers.get(socket.id);
      if (!uid) return;
      const state = ['play', 'pause', 'stop'].includes(d.state) ? d.state : null;
      if (!state) return;
      const seat = await get('SELECT seat_index, is_muted, admin_muted FROM room_seats WHERE room_id = ? AND user_id = ?', [d.roomId, uid]);
      // self-mute affects the microphone only; an admin mute blocks all
      // outbound room audio, including the YouTube fallback.
      if (!seat || seat.admin_muted) return;
      const videoId = String(d.videoId || '');
      if (state !== 'stop' && !/^[A-Za-z0-9_-]{11}$/.test(videoId)) return;
      // الوضع العادي: المستمعون يسمعون عبر ميكرفون المقعد (WebRTC) فلا حاجة للمزامنة.
      // الوضع الاحتياطي (fallback): عند فشل جلب الصوت عبر الخادم يشغّل صاحب المقعد مشغّل يوتيوب مخفياً
      // ويُبثّ حالته ليشغّل المستمعون نفس المقطع (صوتاً فقط) ويتزامنوا معه.
      if (!d.fallback) return;
      socket.to(`room:${d.roomId}`).emit('room_yt_state', {
        fallback: true,
        roomId: d.roomId, userId: uid, seatIndex: seat.seat_index, state, videoId,
        title: String(d.title || '').slice(0, 100), time: Math.max(0, Number(d.time) || 0), sentAt: Date.now()
      });
    } catch (e) { /* مزامنة اختيارية */ }
  });

  // 10. Room Games: Roll Dice 🎲
  socket.on('roll_dice', ({ roomId, user }) => {
    if (!roomId) return;
    const diceValue = Math.floor(Math.random() * 6) + 1;
    io.to(`room:${roomId}`).emit('dice_rolled', {
      user,
      value: diceValue,
      timestamp: Date.now()
    });
  });

  // 11. Room Games: Lucky Wheel 🎡
  socket.on('spin_wheel', ({ roomId, user }) => {
    if (!roomId) return;
    const prizes = [
      { label: '50 🪙 عملة', value: 50 },
      { label: '100 🪙 عملة', value: 100 },
      { label: 'تحدي غناء 🎤', value: 'dare' },
      { label: '10 💎 ألماسة', value: 10 },
      { label: 'ضحكة شريرة 😂', value: 'fun' },
      { label: '500 🪙 جاكبوت!', value: 500 }
    ];
    const prize = prizes[Math.floor(Math.random() * prizes.length)];
    io.to(`room:${roomId}`).emit('wheel_spun', {
      user,
      prize,
      timestamp: Date.now()
    });
  });

  // 12. Room Games: PK Battle Mode 🔥
  function startPkForRoom(roomId, hostUser, challengerUser, duration = 120) {
    if (pkIntervals.has(roomId)) {
      clearInterval(pkIntervals.get(roomId));
      pkIntervals.delete(roomId);
    }

    if (!activeRoomStates.has(roomId)) {
      activeRoomStates.set(roomId, {
        pkState: null,
        activeAudience: new Map(),
        speakers: new Set(),
        mutedChatUsers: new Set(),
        bannedUsers: new Set(),
        cohostRequests: new Map()
      });
    }

    const roomState = activeRoomStates.get(roomId);
    const pkState = {
      active: true,
      host: hostUser || { name: 'المضيف', avatar: '/avatars/avatar-1.png' },
      challenger: challengerUser || { name: 'المنافس', avatar: '/avatars/avatar-2.png' },
      hostScore: 100,
      challengerScore: 100,
      timeLeft: duration,
      startedAt: Date.now()
    };
    roomState.pkState = pkState;

    io.to(`room:${roomId}`).emit('pk_started', pkState);

    const intervalId = setInterval(() => {
      if (!roomState.pkState || !roomState.pkState.active) {
        clearInterval(intervalId);
        pkIntervals.delete(roomId);
        return;
      }

      roomState.pkState.timeLeft--;
      io.to(`room:${roomId}`).emit('pk_timer_tick', {
        timeLeft: roomState.pkState.timeLeft,
        hostScore: roomState.pkState.hostScore,
        challengerScore: roomState.pkState.challengerScore
      });

      if (roomState.pkState.timeLeft <= 0) {
        clearInterval(intervalId);
        pkIntervals.delete(roomId);
        roomState.pkState.active = false;

        let winner = 'draw';
        let loser = 'none';
        if (roomState.pkState.hostScore > roomState.pkState.challengerScore) {
          winner = 'host';
          loser = 'challenger';
        } else if (roomState.pkState.challengerScore > roomState.pkState.hostScore) {
          winner = 'challenger';
          loser = 'host';
        }

        const penalty = SOULCHILL_PK_PENALTIES[Math.floor(Math.random() * SOULCHILL_PK_PENALTIES.length)];

        io.to(`room:${roomId}`).emit('pk_ended', {
          winner,
          loser,
          hostScore: roomState.pkState.hostScore,
          challengerScore: roomState.pkState.challengerScore,
          host: roomState.pkState.host,
          challenger: roomState.pkState.challenger,
          penalty
        });
      }
    }, 1000);

    pkIntervals.set(roomId, intervalId);
  }

  socket.on('start_pk', ({ roomId, hostUser, challengerUser, duration = 120 }) => {
    if (!roomId) return;
    startPkForRoom(roomId, hostUser, challengerUser, duration);
  });

  socket.on('end_pk', ({ roomId }) => {
    if (!roomId) return;
    if (pkIntervals.has(roomId)) {
      clearInterval(pkIntervals.get(roomId));
      pkIntervals.delete(roomId);
    }
    const roomState = activeRoomStates.get(roomId);
    if (roomState && roomState.pkState && roomState.pkState.active) {
      roomState.pkState.active = false;
      let winner = 'draw';
      let loser = 'none';
      if (roomState.pkState.hostScore > roomState.pkState.challengerScore) {
        winner = 'host';
        loser = 'challenger';
      } else if (roomState.pkState.challengerScore > roomState.pkState.hostScore) {
        winner = 'challenger';
        loser = 'host';
      }
      const penalty = SOULCHILL_PK_PENALTIES[Math.floor(Math.random() * SOULCHILL_PK_PENALTIES.length)];
      io.to(`room:${roomId}`).emit('pk_ended', {
        winner,
        loser,
        hostScore: roomState.pkState.hostScore,
        challengerScore: roomState.pkState.challengerScore,
        host: roomState.pkState.host,
        challenger: roomState.pkState.challenger,
        penalty,
        endedByHost: true
      });
    } else {
      io.to(`room:${roomId}`).emit('pk_ended_manually');
    }
  });

  socket.on('pk_support', ({ roomId, team, points = 50, user }) => {
    if (!roomId) return;
    const roomState = activeRoomStates.get(roomId);
    if (!roomState || !roomState.pkState) return;

    if (team === 'host') {
      roomState.pkState.hostScore += points;
    } else {
      roomState.pkState.challengerScore += points;
    }

    io.to(`room:${roomId}`).emit('pk_score_updated', {
      hostScore: roomState.pkState.hostScore,
      challengerScore: roomState.pkState.challengerScore,
      user,
      team,
      points
    });
  });

  // 13. Live Video Stream Events
  socket.on('stream_video_toggle', ({ roomId, userId, isVideoOn }) => {
    if (!roomId) return;
    io.to(`room:${roomId}`).emit('host_video_state_changed', { userId, isVideoOn });
  });

  socket.on('stream_like', async ({ roomId, userId }) => {
    if (!roomId) return;
    try {
      await run('UPDATE rooms SET likes_count = likes_count + 1 WHERE id = ?', [roomId]);
      io.to(`room:${roomId}`).emit('stream_like_burst', {
        userId,
        timestamp: Date.now()
      });
    } catch (err) {}
  });

  socket.on('stream_bullet_chat', ({ roomId, user, text }) => {
    if (!roomId || !text) return;
    io.to(`room:${roomId}`).emit('stream_bullet_message', {
      user,
      text,
      timestamp: Date.now()
    });
  });

  // 14. Admin Moderation Privileges (Room Host & Supreme Owner)
  socket.on('admin_mute_seat', async ({ roomId, seatIndex, adminId, isMuted }) => {
    if (!roomId || seatIndex === undefined) return;
    try {
      const room = await get('SELECT * FROM rooms WHERE id = ?', [roomId]);
      const admin = await get('SELECT * FROM users WHERE id = ?', [adminId]);
      const seat = await get('SELECT user_id FROM room_seats WHERE room_id = ? AND seat_index = ?', [roomId, seatIndex]);
      const targetUserId = seat ? seat.user_id : null;
      const seatTarget = targetUserId ? await get('SELECT * FROM users WHERE id = ?', [targetUserId]) : null;
      if (!room || !admin) return;
      if (isMuted && seatTarget && isTargetImmune(room, admin, seatTarget)) {
        return emitModerationBlocked(socket, 'mute', seatTarget);
      }
      if (seatTarget ? !(await canActOnTarget(room, admin, seatTarget)) : !(await canManageRoom(room, admin))) {
        return socket.emit('error_message', { message: 'ليس لديك صلاحيات إدارة هذه الغرفة!' });
      }

      await run('UPDATE room_seats SET is_muted = ?, admin_muted = ? WHERE room_id = ? AND seat_index = ?', [isMuted ? 1 : 0, isMuted ? 1 : 0, roomId, seatIndex]);
      if (isMuted && targetUserId) clearRoomMusicState(roomId, targetUserId, seatIndex);
      
      const payload = {
        roomId,
        seatIndex,
        userId: targetUserId,
        isMuted: !!isMuted,
        adminMuted: !!isMuted,
        adminName: admin.name
      };

      io.to(`room:${roomId}`).emit('seat_mute_changed', payload);
      if (targetUserId) {
        io.to(`room:${roomId}`).emit('user_force_muted', payload);
      }
      emitModerationDone(socket, isMuted
        ? (seatTarget && seatTarget.name ? `تم كتم صوت «${seatTarget.name}» 🔇` : `تم كتم صوت المقعد ${seatIndex} 🔇`)
        : (seatTarget && seatTarget.name ? `تم إلغاء كتم «${seatTarget.name}» 🎙️` : `تم فتح صوت المقعد ${seatIndex} 🎙️`));
    } catch (e) {
      console.error('admin_mute_seat error:', e);
    }
  });

  socket.on('admin_kick_seat', async ({ roomId, seatIndex, adminId }) => {
    if (!roomId || seatIndex === undefined) return;
    try {
      const room = await get('SELECT * FROM rooms WHERE id = ?', [roomId]);
      const admin = await get('SELECT * FROM users WHERE id = ?', [adminId]);
      const seat = await get('SELECT user_id, is_muted FROM room_seats WHERE room_id = ? AND seat_index = ?', [roomId, seatIndex]);
      const kickedUserId = seat ? seat.user_id : null;
      const kickSeatTarget = kickedUserId ? await get('SELECT * FROM users WHERE id = ?', [kickedUserId]) : null;
      if (!room || !admin) return;
      if (kickSeatTarget && isSeatProtected(admin, kickSeatTarget)) return emitModerationBlocked(socket, 'seat', kickSeatTarget);
      if (kickSeatTarget ? !(await canActOnTarget(room, admin, kickSeatTarget)) : !(await canManageRoom(room, admin))) {
        return socket.emit('error_message', { message: 'ليس لديك صلاحيات إدارة هذه الغرفة!' });
      }
      const keepMuted = !!(seat && seat.is_muted);
      if (kickedUserId) clearRoomMusicState(roomId, kickedUserId, seatIndex);

      await run('UPDATE room_seats SET user_id = NULL, is_muted = ? WHERE room_id = ? AND seat_index = ?', [keepMuted ? 1 : 0, roomId, seatIndex]);
      io.to(`room:${roomId}`).emit('seat_updated', { seatIndex, user: null, isMuted: keepMuted });
      if (kickedUserId) {
        io.to(`room:${roomId}`).emit('user_kicked_from_seat', { seatIndex, userId: kickedUserId, adminName: admin.name });
        io.to(`room:${roomId}`).emit('webrtc_stream_ended', {
          roomId,
          streamType: 'voice_seat',
          userId: kickedUserId
        });
        emitModerationDone(socket, `تم إنزال «${(kickSeatTarget && kickSeatTarget.name) || 'العضو'}» من المقعد 🪑`);
      }
    } catch (e) {
      console.error('admin_kick_seat error:', e);
    }
  });

  socket.on('admin_lock_seat', async ({ roomId, seatIndex, adminId, isLocked }) => {
    if (!roomId || seatIndex === undefined) return;
    try {
      const room = await get('SELECT * FROM rooms WHERE id = ?', [roomId]);
      const admin = await get('SELECT * FROM users WHERE id = ?', [adminId]);
      if (!room || !admin || !(await canManageRoom(room, admin))) return;

      let vacatedUserId = null;
      if (isLocked) {
        const seat = await get('SELECT user_id, is_muted FROM room_seats WHERE room_id = ? AND seat_index = ?', [roomId, seatIndex]);
        if (seat && seat.user_id) {
          const occ = await get('SELECT id, role, wealth_level, vip_level, vip_until FROM users WHERE id = ?', [seat.user_id]);
          if (isSeatProtected(admin, occ)) return emitModerationBlocked(socket, 'seat', await get('SELECT id, name FROM users WHERE id = ?', [seat.user_id]));
        }
        if (seat && seat.user_id) {
          vacatedUserId = seat.user_id;
          clearRoomMusicState(roomId, vacatedUserId, seatIndex);
          const keepMuted = !!(seat.is_muted || activeRoomStates.get(roomId)?.allSeatsMuted);
          await run('UPDATE room_seats SET user_id = NULL, is_muted = ? WHERE room_id = ? AND seat_index = ?', [keepMuted ? 1 : 0, roomId, seatIndex]);
          io.to(`room:${roomId}`).emit('seat_updated', { seatIndex, user: null, isMuted: keepMuted });
          io.to(`room:${roomId}`).emit('user_kicked_from_seat', { seatIndex, userId: vacatedUserId, adminName: admin.name, reason: 'lock_seat' });
          io.to(`room:${roomId}`).emit('webrtc_stream_ended', {
            roomId,
            streamType: 'voice_seat',
            userId: vacatedUserId
          });
        }
      }

      await run('UPDATE room_seats SET is_locked = ? WHERE room_id = ? AND seat_index = ?', [isLocked ? 1 : 0, roomId, seatIndex]);
      io.to(`room:${roomId}`).emit('seat_lock_changed', { seatIndex, isLocked: !!isLocked, vacatedUserId });
      emitModerationDone(socket, isLocked ? (vacatedUserId ? 'تم إنزال العضو وقفل المقعد 🔒' : 'تم قفل المقعد 🔒') : 'تم فتح المقعد 🔓');
    } catch (e) {
      console.error('admin_lock_seat error:', e);
    }
  });

  // Admin Lock or Unlock ALL Seats
  // كتم صوت الكل / إلغاء كتم الكل (قائمة المقعد في الفيديو)
  socket.on('admin_mute_all_seats', async ({ roomId, adminId, isMuted }) => {
    if (!roomId || !adminId) return;
    try {
      const room = await get('SELECT * FROM rooms WHERE id = ?', [roomId]);
      const admin = await get('SELECT * FROM users WHERE id = ?', [adminId]);
      if (!room || !admin || !(await canManageRoom(room, admin))) return;
      const roomState = activeRoomStates.get(roomId);
      if (roomState) roomState.allSeatsMuted = !!isMuted;
      const seatSettings = jparse(room.seat_settings, {});
      seatSettings.global_mute = !!isMuted;
      await run('UPDATE rooms SET seat_settings = ? WHERE id = ?', [JSON.stringify(seatSettings), roomId]);
      const seats = await all('SELECT seat_index, user_id FROM room_seats WHERE room_id = ? AND seat_index > 0', [roomId]);
      const skippedMute = [];
      for (const st of seats) {
        // المحميّون بمستواهم العالي لا يُكتمون بكتم الكل
        if (isMuted && st.user_id) {
          const mu = await get('SELECT * FROM users WHERE id = ?', [st.user_id]);
          if (mu && isTargetImmune(room, admin, mu)) { skippedMute.push(mu.name || 'عضو'); continue; }
        }
        await run('UPDATE room_seats SET is_muted = ?, admin_muted = ? WHERE room_id = ? AND seat_index = ?', [isMuted ? 1 : 0, isMuted ? 1 : 0, roomId, st.seat_index]);
        if (isMuted && st.user_id) clearRoomMusicState(roomId, st.user_id, st.seat_index);
        const payload = { roomId, seatIndex: st.seat_index, userId: st.user_id, isMuted: !!isMuted, adminMuted: !!isMuted, adminName: admin.name };
        io.to(`room:${roomId}`).emit('seat_mute_changed', payload);
        io.to(`room:${roomId}`).emit('user_force_muted', payload);
      }
      io.to(`room:${roomId}`).emit('all_seats_mute_changed', { roomId, isMuted: !!isMuted, adminName: admin.name });
      if (skippedMute.length) {
        emitModerationBlocked(socket, 'mute', null, `لم يتم كتم ${skippedMute.map(n => '«' + n + '»').join('، ')} بسبب مستواهم العالي 👑`);
      }
    } catch (e) { console.error('admin_mute_all_seats error:', e); }
  });
  socket.on('admin_lock_all_seats', async ({ roomId, adminId, isLocked }) => {
    if (!roomId || !adminId) return;
    try {
      const room = await get('SELECT * FROM rooms WHERE id = ?', [roomId]);
      const admin = await get('SELECT * FROM users WHERE id = ?', [adminId]);
      if (!room || !admin || !(await canManageRoom(room, admin))) return;

      // المحميّون (ثروة 26+) يبقون على مقاعدهم ولا تُقفل مقاعدهم
      const protectedSeatIdx = [];
      if (isLocked) {
        const occ0 = await all('SELECT seat_index, user_id FROM room_seats WHERE room_id = ? AND seat_index > 0 AND user_id IS NOT NULL', [roomId]);
        for (const o of occ0) {
          const ou = await get('SELECT id, role, wealth_level, vip_level, vip_until FROM users WHERE id = ?', [o.user_id]);
          if (isSeatProtected(admin, ou)) protectedSeatIdx.push(o.seat_index);
        }
      }
      const protList = protectedSeatIdx.length ? protectedSeatIdx.join(',') : '-1';
      if (protectedSeatIdx.length) {
        const pn = [];
        for (const idx of protectedSeatIdx) {
          const row = await get('SELECT u.name FROM room_seats s JOIN users u ON u.id = s.user_id WHERE s.room_id = ? AND s.seat_index = ?', [roomId, idx]);
          pn.push('«' + ((row && row.name) || 'عضو') + '»');
        }
        emitModerationBlocked(socket, 'seat', null, `لم يتم إنزال ${pn.join('، ')} من المايك بسبب مستواهم العالي 👑`);
      }

      // Lock or unlock seats 1 to 8 in DB
      await run(`UPDATE room_seats SET is_locked = ? WHERE room_id = ? AND seat_index > 0 AND seat_index NOT IN (${protList})`, [isLocked ? 1 : 0, roomId]);

      // If locking, also vacate all users off guest seats 1-8 and force stop their streams
      const vacatedUserIds = [];
      if (isLocked) {
        const occupied = (await all('SELECT seat_index, user_id FROM room_seats WHERE room_id = ? AND seat_index > 0 AND user_id IS NOT NULL', [roomId])).filter(o => !protectedSeatIdx.includes(o.seat_index));
        for (const s of occupied) {
          vacatedUserIds.push(s.user_id);
          clearRoomMusicState(roomId, s.user_id, s.seat_index);
          await run('UPDATE room_seats SET user_id = NULL, is_muted = 1 WHERE room_id = ? AND seat_index = ?', [roomId, s.seat_index]);
          io.to(`room:${roomId}`).emit('seat_updated', {
            seatIndex: s.seat_index,
            user: null,
            isMuted: true
          });
          io.to(`room:${roomId}`).emit('user_kicked_from_seat', {
            seatIndex: s.seat_index,
            userId: s.user_id,
            adminName: admin.name,
            reason: 'lock_all_seats'
          });
          io.to(`room:${roomId}`).emit('webrtc_stream_ended', {
            roomId,
            streamType: 'voice_seat',
            userId: s.user_id
          });
        }
      }

      io.to(`room:${roomId}`).emit('all_seats_lock_changed', {
        roomId,
        isLocked: !!isLocked,
        adminName: admin.name,
        vacatedUserIds
      });

      if (vacatedUserIds.length > 0) {
        io.to(`room:${roomId}`).emit('webrtc_speakers_force_stopped', {
          roomId,
          userIds: vacatedUserIds
        });
      }

      // System message in chat
      io.to(`room:${roomId}`).emit('room_message', {
        id: `sys-${Date.now()}`,
        sender_id: 'system',
        sender_name: '🛡️ إدارة الغرفة',
        sender_avatar: admin.avatar,
        sender_level: 99,
        message_type: 'system',
        content: isLocked 
          ? `قام مدير الغرفة [${admin.name}] بقفل جميع مقاعد المايك 🔒` 
          : `قام مدير الغرفة [${admin.name}] بفتح جميع مقاعد المايك للجمهور 🔓`,
        created_at: new Date().toISOString()
      });
    } catch (e) {
      console.error('admin_lock_all_seats error:', e);
    }
  });

  // Admin Kick User from Room
  socket.on('admin_kick_user_from_room', async ({ roomId, targetUserId, adminId }) => {
    if (!roomId || !targetUserId || !adminId) return;
    try {
      const room = await get('SELECT * FROM rooms WHERE id = ?', [roomId]);
      const admin = await get('SELECT * FROM users WHERE id = ?', [adminId]);
      const kickTarget = await get('SELECT * FROM users WHERE id = ?', [targetUserId]);
      if (room && admin && kickTarget && isTargetImmune(room, admin, kickTarget)) {
        return emitModerationBlocked(socket, 'kick', kickTarget);
      }
      if (!room || !admin || !(await canActOnTarget(room, admin, kickTarget))) {
        return socket.emit('error_message', { message: actDeniedMessage(room, admin, kickTarget) });
      }

      const targetUser = await get('SELECT * FROM users WHERE id = ?', [targetUserId]);
      const byOwnerFlag = (isRoomOwnerLevel(room, admin) || admin.role === 'admin') ? 1 : 0;
      await run("INSERT INTO room_restrictions (room_id, user_id, type, by_owner) VALUES (?, ?, 'ban', ?) ON CONFLICT(room_id, user_id, type) DO UPDATE SET by_owner = excluded.by_owner", [roomId, targetUserId, byOwnerFlag]);
      const roomState = activeRoomStates.get(roomId);
      if (roomState) {
        roomState.bannedUsers.add(targetUserId);
        roomState.activeAudience.delete(targetUserId);
        roomState.speakers.delete(targetUserId);
      }

      // Vacate their seat if on stage
      const seats = await all('SELECT seat_index, is_muted FROM room_seats WHERE room_id = ? AND user_id = ?', [roomId, targetUserId]);
      for (const s of seats) {
        clearRoomMusicState(roomId, targetUserId, s.seat_index);
        await run('UPDATE room_seats SET user_id = NULL, is_muted = ? WHERE room_id = ? AND seat_index = ?', [s.is_muted ? 1 : 0, roomId, s.seat_index]);
        io.to(`room:${roomId}`).emit('seat_updated', {
          seatIndex: s.seat_index,
          user: null,
          isMuted: !!s.is_muted
        });
        io.to(`room:${roomId}`).emit('user_kicked_from_seat', {
          seatIndex: s.seat_index,
          userId: targetUserId,
          adminName: admin.name,
          reason: 'kick_room'
        });
        io.to(`room:${roomId}`).emit('webrtc_stream_ended', {
          roomId,
          streamType: 'voice_seat',
          userId: targetUserId
        });
      }

      const audienceList = roomState ? visibleAudienceList(roomState) : [];
      io.to(`room:${roomId}`).emit('user_kicked_from_room', {
        roomId,
        targetUserId,
        targetUserName: targetUser ? targetUser.name : 'مستخدم',
        adminName: admin.name,
        audienceCount: audienceList.length,
        audience: audienceList
      });

      // Update lobby occupants count
      io.emit('room_occupants_updated', {
        roomId,
        count: audienceList.length,
        preview: buildAudiencePreview(roomId)
      });

      // System notice in chat
      io.to(`room:${roomId}`).emit('room_message', {
        id: `sys-${Date.now()}`,
        sender_id: 'system',
        sender_name: '🛡️ إدارة الغرفة',
        sender_avatar: admin.avatar,
        sender_level: 99,
        message_type: 'system',
        content: `قام مدير الغرفة [${admin.name}] بطرد [${targetUser ? targetUser.name : 'المستخدم'}] من الغرفة 🚪🚫`,
        created_at: new Date().toISOString()
      });
    } catch (e) {
      console.error('admin_kick_user_from_room error:', e);
    }
  });

  // Admin Mute User from Writing in Public Chat
  socket.on('admin_mute_user_chat', async ({ roomId, targetUserId, adminId, isMuted }) => {
    if (!roomId || !targetUserId || !adminId) return;
    try {
      const room = await get('SELECT * FROM rooms WHERE id = ?', [roomId]);
      const admin = await get('SELECT * FROM users WHERE id = ?', [adminId]);
      const muteTarget = await get('SELECT * FROM users WHERE id = ?', [targetUserId]);
      // رفع الكتم مسموح لمن يملك صلاحية الكتم عليه أصلاً
      if (isMuted && room && admin && muteTarget && isTargetImmune(room, admin, muteTarget)) {
        return emitModerationBlocked(socket, 'mute', muteTarget);
      }
      if (!room || !admin || !(await canActOnTarget(room, admin, muteTarget))) {
        return socket.emit('error_message', { message: actDeniedMessage(room, admin, muteTarget) });
      }

      if (isMuted) {
        const byOwnerFlag = (isRoomOwnerLevel(room, admin) || admin.role === 'admin') ? 1 : 0;
        await run("INSERT INTO room_restrictions (room_id, user_id, type, by_owner) VALUES (?, ?, 'mute', ?) ON CONFLICT(room_id, user_id, type) DO UPDATE SET by_owner = excluded.by_owner", [roomId, targetUserId, byOwnerFlag]);
      } else {
        await run("DELETE FROM room_restrictions WHERE room_id = ? AND user_id = ? AND type = 'mute'", [roomId, targetUserId]);
      }
      const roomState = activeRoomStates.get(roomId);
      if (roomState) {
        if (isMuted) {
          roomState.mutedChatUsers.add(targetUserId);
        } else {
          roomState.mutedChatUsers.delete(targetUserId);
        }
      }

      const targetUser = await get('SELECT * FROM users WHERE id = ?', [targetUserId]);

      io.to(`room:${roomId}`).emit('user_chat_mute_changed', {
        roomId,
        targetUserId,
        targetUserName: targetUser ? targetUser.name : 'مستخدم',
        isMuted: !!isMuted,
        adminName: admin.name
      });
      emitModerationDone(socket, isMuted ? `تم كتم «${targetUser ? targetUser.name : 'العضو'}» من الكتابة 🔇` : `تم إلغاء كتم الكتابة عن «${targetUser ? targetUser.name : 'العضو'}» 🔊`);

      // System notice in chat
      io.to(`room:${roomId}`).emit('room_message', {
        id: `sys-${Date.now()}`,
        sender_id: 'system',
        sender_name: '🛡️ إدارة الغرفة',
        sender_avatar: admin.avatar,
        sender_level: 99,
        message_type: 'system',
        content: isMuted 
          ? `قام مدير الغرفة بكتم [${targetUser ? targetUser.name : 'المستخدم'}] من الكتابة العامة 🔇` 
          : `قام مدير الغرفة بإلغاء كتم الكتابة عن [${targetUser ? targetUser.name : 'المستخدم'}] 🔊`,
        created_at: new Date().toISOString()
      });
    } catch (e) {
      console.error('admin_mute_user_chat error:', e);
    }
  });

  socket.on('close_room', async ({ roomId, adminId }) => {
    if (!roomId) return;
    try {
      const room = await get('SELECT * FROM rooms WHERE id = ?', [roomId]);
      const admin = await get('SELECT * FROM users WHERE id = ?', [adminId]);
      if (!room || !admin || !(await canManageRoom(room, admin))) return;

      // Clean up room records in SQLite
      await run('DELETE FROM room_seats WHERE room_id = ?', [roomId]);
      await run('DELETE FROM messages WHERE room_id = ?', [roomId]);
      await run('DELETE FROM rooms WHERE id = ?', [roomId]);

      io.to(`room:${roomId}`).emit('room_closed_by_host', { roomId, adminName: admin.name });
      io.emit('room_deleted', { roomId });
    } catch (e) {
      console.error('close_room error:', e);
    }
  });

  // ============================================
  // 15b. المكالمات الصوتية الخاصة (تتطلب متابعة متبادلة)
  // ============================================
  socket.on('dm_call_invite', async ({ toUserId }) => {
    try {
      const callerId = currentUserId;
      if (!callerId || !toUserId || callerId === toUserId) return;
      if (!(await areMutualFollowers(callerId, toUserId))) {
        return socket.emit('dm_call_denied', { code: 'MUTUAL_FOLLOW_REQUIRED', message: MUTUAL_FOLLOW_MSG });
      }
      for (const c of dmCalls.values()) {
        if ([c.callerId, c.calleeId].includes(callerId) || [c.callerId, c.calleeId].includes(toUserId)) {
          return socket.emit('dm_call_denied', { code: 'BUSY', message: 'أحد الطرفين في مكالمة أخرى حالياً' });
        }
      }
      const targets = userSockets.get(toUserId);
      if (!targets || targets.size === 0) {
        return socket.emit('dm_call_denied', { code: 'OFFLINE', message: 'المستخدم غير متصل حالياً' });
      }
      const caller = await get('SELECT id, name, avatar FROM users WHERE id = ?', [callerId]);
      if (!caller) return;
      const callId = `call-${Date.now()}-${uuidv4().slice(0, 6)}`;
      dmCalls.set(callId, { callId, callerId, calleeId: toUserId, callerSocket: socket.id, calleeSocket: null, answered: false });
      socket.emit('dm_call_ringing', { callId });
      for (const sId of targets) io.to(sId).emit('dm_call_incoming', { callId, from: caller });
      // مهلة الرد 40 ثانية
      setTimeout(() => {
        const c = dmCalls.get(callId);
        if (c && !c.answered) endDmCall(callId, 'no_answer');
      }, 40000);
    } catch (e) { console.error('dm_call_invite error:', e); }
  });

  socket.on('dm_call_accept', ({ callId }) => {
    const c = dmCalls.get(callId);
    if (!c || c.calleeId !== currentUserId || c.answered) return;
    c.answered = true;
    c.answeredAt = Date.now();
    c.calleeSocket = socket.id;
    io.to(c.callerSocket).emit('dm_call_accepted', { callId, calleeSocketId: socket.id });
    // رسالة في المحادثة: بدأت المكالمة
    postCallLog(c.callerId, c.calleeId, 'started', { started_at: new Date(c.answeredAt).toISOString() });
    // أوقف الرنين على بقية أجهزة المستلم
    const targets = userSockets.get(c.calleeId);
    if (targets) for (const sId of targets) if (sId !== socket.id) io.to(sId).emit('dm_call_ended', { callId, reason: 'answered_elsewhere' });
  });

  socket.on('dm_call_reject', ({ callId }) => {
    const c = dmCalls.get(callId);
    if (!c || c.calleeId !== currentUserId) return;
    endDmCall(callId, 'rejected');
  });

  socket.on('dm_call_end', ({ callId }) => {
    const c = dmCalls.get(callId);
    if (!c || ![c.callerId, c.calleeId].includes(currentUserId)) return;
    endDmCall(callId, 'ended');
  });

  socket.on('dm_call_signal', ({ callId, data }) => {
    const c = dmCalls.get(callId);
    if (!c || !c.answered) return;
    let target = null;
    if (socket.id === c.callerSocket) target = c.calleeSocket;
    else if (socket.id === c.calleeSocket) target = c.callerSocket;
    if (target) io.to(target).emit('dm_call_signal', { callId, data });
  });

  socket.on('disconnect', () => {
    for (const c of Array.from(dmCalls.values())) {
      if (c.callerSocket === socket.id || c.calleeSocket === socket.id) endDmCall(c.callId, 'disconnected');
    }
    // تنظيف التوافق الصوتي: إزالة من طابور الانتظار + إنهاء أي جلسة نشطة لهذا السوكيت
    removeFromVoiceMatchQueue(socket.id);
    for (const s of Array.from(activeVoiceMatchSessions.values())) {
      if (s.userA.socketId === socket.id || s.userB.socketId === socket.id) {
        endVoiceMatchSession(s.id, 'disconnected');
      }
    }
  });

  // ============================================
  // 16. REAL WEBRTC AUDIO & VIDEO STREAMING SIGNALING
  // ============================================
  socket.on('webrtc_signal_offer', ({ targetSocketId, offer, streamType, user, roomId }) => {
    if (targetSocketId) {
      io.to(targetSocketId).emit('webrtc_signal_offer', {
        senderSocketId: socket.id,
        offer,
        streamType, // 'video_broadcast', 'cohost_video', or 'voice_seat'
        user,
        roomId
      });
    }
  });

  socket.on('webrtc_signal_answer', ({ targetSocketId, answer, streamType, role }) => {
    if (targetSocketId) {
      io.to(targetSocketId).emit('webrtc_signal_answer', {
        senderSocketId: socket.id,
        answer,
        streamType,
        role
      });
    }
  });

  socket.on('webrtc_signal_ice_candidate', ({ targetSocketId, candidate, streamType, role }) => {
    if (targetSocketId) {
      io.to(targetSocketId).emit('webrtc_signal_ice_candidate', {
        senderSocketId: socket.id,
        candidate,
        streamType,
        role
      });
    }
  });

  socket.on('webrtc_request_stream', ({ roomId, userId }) => {
    if (!roomId) return;
    socket.to(`room:${roomId}`).emit('webrtc_stream_requested', {
      viewerSocketId: socket.id,
      userId
    });
  });

  socket.on('webrtc_broadcaster_ready', ({ roomId, userId, mediaType }) => {
    if (!roomId) return;
    socket.to(`room:${roomId}`).emit('webrtc_broadcaster_ready', {
      broadcasterSocketId: socket.id,
      userId,
      mediaType
    });
  });

  socket.on('webrtc_stream_ended', ({ roomId, streamType, userId }) => {
    if (roomId) {
      socket.to(`room:${roomId}`).emit('webrtc_stream_ended', {
        senderSocketId: socket.id,
        streamType,
        userId
      });
    }
  });

  // 15. Live 2-Person Co-Host Video Broadcast & Split-Screen
  // 1) Viewer requests to join live stream with the host
  socket.on('request_cohost_join', async ({ roomId, requester }) => {
    if (!roomId || !requester) return;
    if (!activeRoomStates.has(roomId)) {
      activeRoomStates.set(roomId, {
        pkState: null,
        activeAudience: new Map(),
        speakers: new Set(),
        mutedChatUsers: new Set(),
        bannedUsers: new Set(),
        cohostRequests: new Map()
      });
    }
    const roomState = activeRoomStates.get(roomId);
    if (!roomState.cohostRequests) roomState.cohostRequests = new Map();
    roomState.cohostRequests.set(requester.id, requester);

    // Find host of this room
    const room = await get('SELECT host_id FROM rooms WHERE id = ?', [roomId]);
    const hostId = room ? room.host_id : null;
    let sentToHost = false;
    if (hostId && userSockets.has(hostId)) {
      for (const sockId of userSockets.get(hostId)) {
        io.to(sockId).emit('cohost_request_received', {
          roomId,
          requester,
          requestsCount: roomState.cohostRequests.size,
          requests: Array.from(roomState.cohostRequests.values())
        });
        sentToHost = true;
      }
    }
    if (!sentToHost) {
      // Broadcast to room so any connected host in the room receives it
      socket.to(`room:${roomId}`).emit('cohost_request_received', {
        roomId,
        requester,
        requestsCount: roomState.cohostRequests.size,
        requests: Array.from(roomState.cohostRequests.values())
      });
    }
    // Also notify room about updated requests count
    io.to(`room:${roomId}`).emit('cohost_requests_updated', {
      count: roomState.cohostRequests.size,
      requests: Array.from(roomState.cohostRequests.values())
    });
  });

  // 2) Host accepts cohost request (or invites directly)
  socket.on('accept_cohost_request', async ({ roomId, cohostUser }) => {
    if (!roomId || !cohostUser) return;
    try {
      await run('UPDATE rooms SET co_host_id = ? WHERE id = ?', [cohostUser.id, roomId]);
      const room = await get('SELECT * FROM rooms WHERE id = ?', [roomId]);
      const hostUser = await get('SELECT id, name, avatar, avatar_frame FROM users WHERE id = ?', [room ? room.host_id : '']);

      const roomState = activeRoomStates.get(roomId);
      if (roomState && roomState.cohostRequests) {
        roomState.cohostRequests.delete(cohostUser.id);
      }

      // Notify the cohostUser specifically
      const cohostSockets = userSockets.get(cohostUser.id);
      if (cohostSockets) {
        for (const sId of cohostSockets) {
          io.to(sId).emit('cohost_request_accepted', { roomId, hostUser });
        }
      }

      // Broadcast to all viewers in room that cohost joined (without auto-starting PK)
      io.to(`room:${roomId}`).emit('cohost_joined_stream', {
        cohostUser,
        hostUser
      });
    } catch (e) {
      console.error('accept_cohost_request error:', e);
    }
  });

  // 3) Host rejects cohost request
  socket.on('reject_cohost_request', ({ roomId, targetUserId }) => {
    if (!roomId || !targetUserId) return;
    const roomState = activeRoomStates.get(roomId);
    if (roomState && roomState.cohostRequests) {
      roomState.cohostRequests.delete(targetUserId);
    }
    const targetSockets = userSockets.get(targetUserId);
    if (targetSockets) {
      for (const sId of targetSockets) {
        io.to(sId).emit('cohost_request_rejected', { roomId });
      }
    }
    if (roomState && roomState.cohostRequests) {
      io.to(`room:${roomId}`).emit('cohost_requests_updated', {
        count: roomState.cohostRequests.size,
        requests: Array.from(roomState.cohostRequests.values())
      });
    }
  });

  // 4) Host requests list of pending cohost requests
  socket.on('get_cohost_requests', ({ roomId }) => {
    if (!roomId) return;
    const roomState = activeRoomStates.get(roomId);
    const requests = roomState && roomState.cohostRequests ? Array.from(roomState.cohostRequests.values()) : [];
    socket.emit('cohost_requests_updated', {
      count: requests.length,
      requests
    });
  });

  // 5) Two-Party Mutual PK Battle Request & Agreement
  socket.on('request_pk_battle', async ({ roomId, fromUser }) => {
    if (!roomId || !fromUser) return;
    try {
      const room = await get('SELECT host_id, co_host_id FROM rooms WHERE id = ?', [roomId]);
      if (!room || !room.co_host_id) return;

      const targetUserId = fromUser.id === room.host_id ? room.co_host_id : room.host_id;
      const targetSockets = userSockets.get(targetUserId);
      if (targetSockets) {
        for (const sId of targetSockets) {
          io.to(sId).emit('pk_battle_challenge_received', {
            roomId,
            challenger: fromUser
          });
        }
      }
    } catch (e) {}
  });

  socket.on('accept_pk_battle', async ({ roomId }) => {
    if (!roomId) return;
    try {
      const room = await get('SELECT * FROM rooms WHERE id = ?', [roomId]);
      if (!room || !room.co_host_id) return;

      const hostUser = await get('SELECT id, name, avatar, avatar_frame FROM users WHERE id = ?', [room.host_id]);
      const cohostUser = await get('SELECT id, name, avatar, avatar_frame FROM users WHERE id = ?', [room.co_host_id]);

      startPkForRoom(roomId, hostUser, cohostUser, 120);
    } catch (e) {}
  });

  socket.on('reject_pk_battle', async ({ roomId, fromUserId }) => {
    if (!fromUserId) return;
    const targetSockets = userSockets.get(fromUserId);
    if (targetSockets) {
      for (const sId of targetSockets) {
        io.to(sId).emit('pk_battle_challenge_rejected');
      }
    }
  });

  // دعوة مستخدم للصعود إلى المايك (قائمة المقعد ← ادعيه)
  socket.on('invite_to_seat', async ({ roomId, targetUserId, seatIndex, adminId }) => {
    if (!roomId || !targetUserId || !adminId) return;
    try {
      const room = await get('SELECT * FROM rooms WHERE id = ?', [roomId]);
      const admin = await get('SELECT * FROM users WHERE id = ?', [adminId]);
      if (!room || !admin || !(await canManageRoom(room, admin))) return;
      const targets = userSockets.get(targetUserId);
      if (!targets) return;
      for (const sockId of targets) {
        io.to(sockId).emit('seat_invite', { roomId, seatIndex, fromName: admin.name, fromId: admin.id, roomTitle: room.title });
      }
    } catch (e) { console.error('invite_to_seat error:', e); }
  });

  socket.on('invite_cohost', ({ roomId, targetUserId, hostUser }) => {
    if (!roomId || !targetUserId) return;
    const targetSockets = userSockets.get(targetUserId);
    if (targetSockets) {
      for (const sockId of targetSockets) {
        io.to(sockId).emit('cohost_invitation_received', { roomId, hostUser });
      }
    }
  });

  socket.on('accept_cohost', async ({ roomId, cohostUser }) => {
    if (!roomId || !cohostUser) return;
    try {
      await run('UPDATE rooms SET co_host_id = ? WHERE id = ?', [cohostUser.id, roomId]);
      const room = await get('SELECT * FROM rooms WHERE id = ?', [roomId]);
      const hostUser = await get('SELECT id, name, avatar, avatar_frame FROM users WHERE id = ?', [room ? room.host_id : '']);
      io.to(`room:${roomId}`).emit('cohost_joined_stream', { cohostUser, hostUser });
    } catch (e) {}
  });

  // 6) Co-host steps down / leaves live stage on their own
  socket.on('cohost_leave_stage', async ({ roomId, userId }) => {
    if (!roomId) return;
    if (pkIntervals.has(roomId)) {
      clearInterval(pkIntervals.get(roomId));
      pkIntervals.delete(roomId);
    }
    const roomState = activeRoomStates.get(roomId);
    if (roomState && roomState.pkState) {
      roomState.pkState.active = false;
    }
    try {
      await run('UPDATE rooms SET co_host_id = NULL WHERE id = ?', [roomId]);
      io.to(`room:${roomId}`).emit('cohost_left_stream', { userId });
    } catch (e) {}
  });

  socket.on('end_cohost', async ({ roomId }) => {
    if (!roomId) return;
    if (pkIntervals.has(roomId)) {
      clearInterval(pkIntervals.get(roomId));
      pkIntervals.delete(roomId);
    }
    const roomState = activeRoomStates.get(roomId);
    if (roomState && roomState.pkState) {
      roomState.pkState.active = false;
    }
    try {
      await run('UPDATE rooms SET co_host_id = NULL WHERE id = ?', [roomId]);
      io.to(`room:${roomId}`).emit('cohost_left_stream');
    } catch (e) {}
  });

  // ============================================
  // 16. التوافق الصوتي الحقيقي (مكالمة صوتية مجهولة WebRTC بين شخصين حقيقيين)
  // ============================================

  // يتحقق أن هذا السوكيت هو سوكيت المستخدم المسجَّل فعلاً (لا نثق بـ userId القادم من العميل وحده)
  const vmOwnsSocket = (userId) => {
    const set = userId && userSockets.get(userId);
    return !!(set && set.has(socket.id));
  };

  // دخول الطابور: لا يحدث إلا بضغط المستخدم زر التوافق الصوتي بنفسه
  socket.on('start_voice_match', async ({ userId, gender } = {}) => {
    if (!userId || !vmOwnsSocket(userId)) return;

    try {
      // بيانات المستخدم تُقرأ دائماً من قاعدة البيانات (لا يُؤخذ tags/planet من العميل)
      const currentUser = await get('SELECT * FROM users WHERE id = ?', [userId]);
      if (!currentUser) return;
      if (currentUser.is_banned || currentUser.status === 'banned') {
        return socket.emit('voice_match_error', { code: 'ACCOUNT', message: 'حسابك غير مفعّل للتوافق الصوتي' });
      }

      removeFromVoiceMatchQueue(socket.id, userId);
      pruneVoiceMatchQueue();

      if (isUserInActiveVoiceMatch(userId)) {
        return socket.emit('voice_match_error', { code: 'BUSY', message: 'أنت في مكالمة توافق صوتي حالياً 🎙️' });
      }

      // حد أقصى للمحاولات خلال 24 ساعة
      const used = await getVoiceMatchUsageCount(userId);
      const vmLimit = await getVoiceMatchLimit(userId);
      if (used >= vmLimit) {
        return socket.emit('voice_match_error', {
          code: 'LIMIT_REACHED',
          remaining: 0,
          message: `لقد استنفدت محاولاتك الـ ${vmLimit} للتوافق الصوتي خلال 24 ساعة. عد غداً 🌌`
        });
      }

      // ندخل الطابور أولاً (بحالة WAITING) ثم نبحث عن شريك داخل الطابور فقط
      const entry = {
        userId, socketId: socket.id, user: currentUser, enqueuedAt: Date.now(), timeout: null, state: 'WAITING',
        prefGender: normalizeVoiceMatchGenderPref(gender), // اختيار الجنس من نافذة التصفية (all = عشوائي)
        requestId: `vmreq-${Date.now()}-${uuidv4().slice(0, 6)}`
      };
      entry.timeout = setTimeout(() => {
        const q = removeFromVoiceMatchQueue(socket.id, userId);
        if (q) socket.emit('voice_match_error', { code: 'NO_MATCH', message: 'لم نجد شخصاً متوافقاً يناسب اختيارك الآن... حاول مرة أخرى لاحقاً 🪐' });
      }, VOICE_MATCH_QUEUE_TIMEOUT_MS);
      voiceMatchQueue.push(entry);
      socket.emit('voice_match_searching', { remaining: Math.max(0, vmLimit - used) });

      await tryMatchVoiceQueue(entry);
    } catch (err) {
      console.error('Voice match error:', err);
      socket.emit('voice_match_error', { code: 'ERROR', message: 'حدث خطأ أثناء البحث عن شريك متوافق' });
    }
  });

  // قبول الدعوات أُلغي: لا يُتصل بأي مستخدم لم يضغط زر التوافق بنفسه
  socket.on('accept_voice_match_request', () => {
    socket.emit('voice_match_request_cancelled', { reason: 'disabled' });
  });

  // الطرف يبلّغ أن صوته اتصل فعلاً؛ الدقائق الخمس تبدأ عندما يبلّغ الطرفان
  socket.on('voice_match_audio_connected', ({ sessionId } = {}) => {
    const s = sessionId && activeVoiceMatchSessions.get(sessionId);
    if (!s || s.ended) return;
    if (socket.id === s.userA.socketId) s.userA.audioReady = true;
    else if (socket.id === s.userB.socketId) s.userB.audioReady = true;
    else return;
    if (s.userA.audioReady && s.userB.audioReady) startVoiceMatchClock(s);
  });

  // كشف حساب المستخدم الحالي فقط — قرار كل طرف مستقل ويُسجَّل على الخادم
  socket.on('reveal_voice_match_identity', async ({ sessionId } = {}) => {
    const session = sessionId && activeVoiceMatchSessions.get(sessionId);
    if (!session || session.ended) return;

    let me, other;
    if (socket.id === session.userA.socketId) { me = session.userA; other = session.userB; }
    else if (socket.id === session.userB.socketId) { me = session.userB; other = session.userA; }
    else return;

    // لا يُقبل كشف بعد انتهاء المهلة
    if (session.deadlineAt && !session.isUnlimited && Date.now() >= session.deadlineAt) {
      return finalizeVoiceMatchDeadline(session.id);
    }
    if (me.revealed) return; // الكشف لا يُتراجع عنه ولا يُعاد

    me.revealed = true;
    const col = me === session.userA ? 'user_a_revealed_at' : 'user_b_revealed_at';
    vmCallLog(`UPDATE voice_calls SET ${col} = ?, status = CASE WHEN status = 'ANONYMOUS_CALL' THEN 'ONE_REVEALED' ELSE status END WHERE id = ?`, [new Date().toISOString(), session.id]);

    // معلومات صاحب الكشف تُرسل للطرف الآخر فقط الآن (بعد التحقق من قراره)
    const myProfile = vmPublicProfile(me.user);
    if (other.socketId) {
      io.to(other.socketId).emit('voice_match_reveal_updated', { sessionId, who: 'partner', partnerProfile: myProfile, bothRevealed: !!other.revealed });
      io.to(other.socketId).emit('partner_revealed_identity', { sessionId, partnerProfile: myProfile });
    }
    socket.emit('voice_match_reveal_updated', { sessionId, who: 'me', bothRevealed: !!other.revealed });

    if (me.revealed && other.revealed) {
      markVoiceMatchUnlimited(session);
      const base = { sessionId, isUnlimited: true };
      if (session.userA.socketId) io.to(session.userA.socketId).emit('voice_match_both_revealed', { ...base, realPartner: vmPublicProfile(session.userB.user), realSelf: vmPublicProfile(session.userA.user) });
      if (session.userB.socketId) io.to(session.userB.socketId).emit('voice_match_both_revealed', { ...base, realPartner: vmPublicProfile(session.userA.user), realSelf: vmPublicProfile(session.userB.user) });
    }
  });

  // حظر الشريك: يُسجَّل الحظر وتُغلق الجلسة فوراً
  socket.on('voice_match_block', async ({ sessionId } = {}) => {
    try {
      const s = sessionId && activeVoiceMatchSessions.get(sessionId);
      if (!s) return;
      let me, other;
      if (socket.id === s.userA.socketId) { me = s.userA; other = s.userB; }
      else if (socket.id === s.userB.socketId) { me = s.userB; other = s.userA; }
      else return;
      await run('INSERT OR IGNORE INTO user_blocks (user_id, blocked_id) VALUES (?, ?)', [me.id, other.id]);
      endVoiceMatchSession(sessionId, 'blocked');
    } catch (e) { console.error('voice_match_block error:', e.message); }
  });

  // الإبلاغ عن إساءة: يُسجَّل البلاغ ويُحظر الشريك ويُنهى الاتصال
  socket.on('voice_match_report', async ({ sessionId, reason } = {}) => {
    try {
      const s = sessionId && activeVoiceMatchSessions.get(sessionId);
      if (!s) return;
      let me, other;
      if (socket.id === s.userA.socketId) { me = s.userA; other = s.userB; }
      else if (socket.id === s.userB.socketId) { me = s.userB; other = s.userA; }
      else return;
      await run('INSERT INTO user_reports (reporter_id, reported_id, room_id, reason) VALUES (?, ?, ?, ?)',
        [me.id, other.id, null, String(reason || 'voice_match_abuse').slice(0, 300)]);
      await run('INSERT OR IGNORE INTO user_blocks (user_id, blocked_id) VALUES (?, ?)', [me.id, other.id]);
      endVoiceMatchSession(sessionId, 'reported');
    } catch (e) { console.error('voice_match_report error:', e.message); }
  });

  socket.on('voice_match_reaction', ({ sessionId, emoji, senderName }) => {
    if (!sessionId) return;
    const session = activeVoiceMatchSessions.get(sessionId);
    if (!session) return;
    if (session.userA.socketId) io.to(session.userA.socketId).emit('voice_match_reaction_burst', { emoji, senderName });
    if (session.userB.socketId) io.to(session.userB.socketId).emit('voice_match_reaction_burst', { emoji, senderName });
  });

  socket.on('voice_match_speaking', ({ sessionId, userId, isSpeaking }) => {
    if (!sessionId) return;
    const session = activeVoiceMatchSessions.get(sessionId);
    if (!session) return;
    const otherSockId = session.userA.id === userId ? session.userB.socketId : session.userA.socketId;
    if (otherSockId) {
      io.to(otherSockId).emit('partner_speaking_status', { isSpeaking });
    }
  });

  // إرسال إشارات WebRTC (صوت فقط) بين طرفي الجلسة — اتصال صوتي حقيقي بين شخصين
  socket.on('voice_match_signal', ({ sessionId, data }) => {
    if (!sessionId || !data) return;
    const session = activeVoiceMatchSessions.get(sessionId);
    if (!session) return;
    let target = null;
    if (socket.id === session.userA.socketId) target = session.userB.socketId;
    else if (socket.id === session.userB.socketId) target = session.userA.socketId;
    if (target) io.to(target).emit('voice_match_signal', { sessionId, data });
  });

  socket.on('end_voice_match', ({ sessionId } = {}) => {
    if (!sessionId) {
      // إلغاء البحث: إزالة المستخدم من طابور الانتظار
      removeFromVoiceMatchQueue(socket.id);
      return;
    }
    const session = activeVoiceMatchSessions.get(sessionId);
    if (!session) return;
    if (socket.id !== session.userA.socketId && socket.id !== session.userB.socketId) return;
    endVoiceMatchSession(sessionId, 'ended');
  });

  // 17. Supreme Owner Global Broadcast to All Rooms
  // الإعلان العام: إدارة المنصة دائماً، وأصحاب امتياز «إعلان عالمي» حسب مستواهم (مع فاصل زمني)
  socket.on('global_owner_announcement', async ({ message } = {}) => {
    try {
      message = String(message || '').trim().slice(0, 200);
      if (!message || !currentUserId) return;
      const au = await get('SELECT id, role, wealth_level, vip_level, vip_until FROM users WHERE id = ?', [currentUserId]);
      if (!au) return;
      if (!PLATFORM_ADMIN_ROLES.includes(au.role)) {
        if (!userHasPerkSync(au, 'global_announce', 165) && !vipPerks.hasPerk(au, 'global_announce')) {
          socket.emit('perk_denied', { key: 'global_announce', level: perkLevelSync('global_announce', 165), message: 'الإعلان العالمي يفتح عند مستوى ثروة أعلى أو VIP أعلى' });
          return;
        }
        const last = globalAnnounceLast.get(au.id) || 0;
        if (Date.now() - last < 60 * 1000) { socket.emit('perk_denied', { key: 'global_announce', message: 'انتظر دقيقة بين كل إعلان وآخر' }); return; }
        globalAnnounceLast.set(au.id, Date.now());
      }
      io.emit('global_announcement_broadcast', { message });
    } catch (e) { console.error('global announcement error:', e.message); }
  });

  // 17. User Sign-Out / Disconnect Event
  socket.on('user_disconnect', async () => {
    if (currentUserId) {
      const sockSet = userSockets.get(currentUserId);
      if (sockSet) {
        sockSet.delete(socket.id);
        if (sockSet.size === 0) {
          userSockets.delete(currentUserId);
          io.emit('user_status_change', { userId: currentUserId, status: 'offline' });
        }
      }
      try {
        const heldSeats = await all('SELECT room_id, seat_index, is_muted FROM room_seats WHERE user_id = ?', [currentUserId]);
        if (heldSeats && heldSeats.length > 0) {
          for (const s of heldSeats) {
            clearRoomMusicState(s.room_id, currentUserId, s.seat_index);
            await run('UPDATE room_seats SET user_id = NULL, is_muted = ? WHERE room_id = ? AND seat_index = ?', [s.is_muted ? 1 : 0, s.room_id, s.seat_index]);
            io.to(`room:${s.room_id}`).emit('seat_updated', {
              seatIndex: s.seat_index,
              user: null,
              isMuted: !!s.is_muted
            });
          }
        }
      } catch (e) {}

      // Remove from audience strip across rooms
      for (const [rId, rState] of activeRoomStates.entries()) {
        if (rState.activeAudience && rState.activeAudience.has(currentUserId)) {
          rState.activeAudience.delete(currentUserId);
          rState.speakers.delete(currentUserId);
          const audienceList = visibleAudienceList(rState);
          io.to(`room:${rId}`).emit('user_left_room', {
            userId: currentUserId,
            audienceCount: audienceList.length,
            audience: audienceList
          });
          // تحديث عدد الزوار لدى الجميع (القائمة، مركز الاهتمامات، المقترحين...)
          io.emit('room_occupants_updated', { roomId: rId, count: audienceList.length, preview: buildAudiencePreview(rId) });
        }
      }

      currentUserId = null;
    }
  });

  // User avatar changed broadcast
  socket.on('user_avatar_changed', ({ userId, avatar }) => {
    if (!userId || !avatar) return;
    io.emit('user_avatar_changed', { userId, avatar });
  });

  // 18. Socket Disconnect
  socket.on('disconnect', async () => {
    clearInterval(missionTicker);
    socketInstantLeave.delete(socket.id);
    if (currentUserId) {
      const uid = currentUserId;
      const sockSet = userSockets.get(uid);
      if (sockSet) {
        sockSet.delete(socket.id);
        if (sockSet.size === 0) {
          userSockets.delete(uid);
          io.emit('user_status_change', { userId: uid, status: 'offline' });
        }
      }

      // مهلة سماح (15 ثانية): انقطاع الشبكة اللحظي لا يُنزل أحداً عن مقعده ولا يُخرجه من الغرفة.
      // إن عاد المستخدم (سوكت جديد) خلال المهلة نتجاهل التحرير ويبقى على مقعده.
      const releaseUser = async () => {
        if (userSockets.has(uid) && userSockets.get(uid).size > 0) return;
        try {
          const heldSeats = await all('SELECT room_id, seat_index, is_muted FROM room_seats WHERE user_id = ?', [uid]);
          if (heldSeats && heldSeats.length > 0) {
            for (const s of heldSeats) {
              clearRoomMusicState(s.room_id, uid, s.seat_index);
              await run('UPDATE room_seats SET user_id = NULL, is_muted = ? WHERE room_id = ? AND seat_index = ?', [s.is_muted ? 1 : 0, s.room_id, s.seat_index]);
              io.to(`room:${s.room_id}`).emit('seat_updated', {
                seatIndex: s.seat_index,
                user: null,
                isMuted: !!s.is_muted
              });
              io.to(`room:${s.room_id}`).emit('webrtc_stream_ended', { senderSocketId: null, streamType: 'voice_seat', userId: uid });
            }
          }
        } catch (e) {}

        // Remove from audience strip across rooms
        for (const [rId, rState] of activeRoomStates.entries()) {
          if (rState.activeAudience && rState.activeAudience.has(uid)) {
            rState.activeAudience.delete(uid);
            rState.speakers.delete(uid);
            const audienceList = visibleAudienceList(rState);
            io.to(`room:${rId}`).emit('user_left_room', {
              userId: uid,
              audienceCount: audienceList.length,
              audience: audienceList
            });
            // تحديث عدد الزوار لدى الجميع (القائمة، مركز الاهتمامات، المقترحين...)
            io.emit('room_occupants_updated', { roomId: rId, count: audienceList.length, preview: buildAudiencePreview(rId) });
          }
        }
      };
      setTimeout(releaseUser, 15000);
    }
    onlineUsers.delete(socket.id);
  });
});

// Fallback to SPA index.html
app.use((req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start Server & Initialize Database
const HTTPS_PORT = process.env.HTTPS_PORT || 2083;

// أخطاء الطلبات: قطع العميل لطلبه (إغلاق التبويب/انقطاع الشبكة) ليس خللاً في الخادم، فلا نطبع تتبّعاً طويلاً
app.use((err, req, res, next) => {
  if (err && (err.type === 'request.aborted' || err.code === 'ECONNABORTED' || /request aborted/i.test(err.message || ''))) {
    return; // العميل أغلق الاتصال، لا يوجد من يستقبل الرد
  }
  if (res.headersSent) return next(err);
  console.error('Unhandled request error:', err && err.message);
  res.status((err && (err.status || err.statusCode)) || 500).json({ error: 'خطأ في الخادم' });
});

server.listen(PORT, '0.0.0.0', async () => {
  console.log(`===============================================`);
  console.log(`✨ SoulChill HTTP Server running on http://0.0.0.0:${PORT}`);
  console.log(`🪐 SQLite Database: soulchill.sqlite`);
  console.log(`===============================================`);
  await initDB();
  await seedGiftsCatalog();
  // لا يوجد أي متصل عند بدء الخادم: نحرّر كل المقاعد العالقة حتى لا يُصعَّد أحد تلقائياً عند الدخول
  try { await run('UPDATE room_seats SET user_id = NULL WHERE user_id IS NOT NULL'); } catch (e) { console.error('stale seats cleanup error:', e); }
  // أغانٍ يوتيوب كانت قيد التحميل عند إيقاف الخادم: نعيد تشغيل مهامها
  try {
    // الفاشلة تُعاد عند الإقلاع (مثلاً بعد إضافة كوكيز أو تثبيت ffmpeg) ما عدا الأخطاء الدائمة
    await run(`UPDATE user_music_tracks SET audio_status = 'processing', audio_attempts = 0
      WHERE audio_status = 'failed' AND source = 'youtube' AND yt_id != ''
        AND COALESCE(audio_error, '') NOT LIKE '%غير متاح%'
        AND COALESCE(audio_error, '') NOT LIKE '%ffmpeg%'`);
    const pend = await all(`SELECT DISTINCT yt_id FROM user_music_tracks WHERE audio_status = 'processing' AND yt_id != ''`);
    pend.forEach(r => startYtAudioJob(r.yt_id));
  } catch (e) { console.error('yt audio resume error:', e); }
});

if (httpsServer) {
  httpsServer.listen(HTTPS_PORT, '0.0.0.0', () => {
    console.log(`===============================================`);
    console.log(`🔒 SoulChill Secure HTTPS Server running on https://0.0.0.0:${HTTPS_PORT}`);
    console.log(`📜 Loaded SSL Certificate: cert.pem & key.pem`);
    console.log(`===============================================`);
  });
} else {
  console.warn('⚠️ cert.pem or key.pem not found; HTTPS on port 2083 was not started.');
}
